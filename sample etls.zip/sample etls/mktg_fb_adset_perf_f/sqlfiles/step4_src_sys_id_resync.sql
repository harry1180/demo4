
update dw_report.mktg_fb_adset_perf_f
set
src_sys_id = coalesce(xref.src_sys_id,-1)
from
dw_report.mktg_src_sys_campaign_domain_xref xref
where
dw_report.mktg_fb_adset_perf_f.ext_customer_id = xref.campaign_domain_ext_acct_id
and ( dw_report.mktg_fb_adset_perf_f.src_sys_id is null or dw_report.mktg_fb_adset_perf_f.src_sys_id = -1 )
and xref.referrer_nm = 'facebook' ;
