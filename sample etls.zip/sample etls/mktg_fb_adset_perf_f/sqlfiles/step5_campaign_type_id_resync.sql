update dw_report.mktg_fb_adset_perf_f
set
campaign_type_id = coalesce(d.campaign_type_id,'-1')
from
dw_report.mktg_campaign_type_d d
where
dw_report.mktg_fb_adset_perf_f.campaign_domain_id = d.campaign_domain_id
and lower(d.campaign_type_nm) = 'native' 
and ( dw_report.mktg_fb_adset_perf_f.campaign_type_id is null or dw_report.mktg_fb_adset_perf_f.campaign_type_id = -1 )
;
