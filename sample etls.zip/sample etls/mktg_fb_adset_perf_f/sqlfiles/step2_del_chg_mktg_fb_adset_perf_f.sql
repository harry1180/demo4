delete from dw_report.mktg_fb_adset_perf_f
where
dw_eff_dt > current_date - 15 ;
