DROP TABLE "dw_report"."mktg_fb_multi_step_offline_conv_upload_f" ;

CREATE TABLE "dw_report"."mktg_fb_multi_step_offline_conv_upload_f"
(
    "dw_snapshot_dt" DATE   ENCODE lzo
    ,"dw_eff_dt" DATE   ENCODE lzo
    ,"site_uv_id" VARCHAR(45)   ENCODE lzo
    ,"src_sys_id" INTEGER   ENCODE lzo
    ,"dw_site_prod_sk" VARCHAR(256)   ENCODE lzo
    ,"commission_am" VARCHAR(22)   ENCODE lzo
    ,"src_prod_id" VARCHAR(256)   ENCODE lzo
    ,"page_vertical_tx" VARCHAR(6000)   ENCODE lzo
    ,"page_topic_tx" VARCHAR(6000)   ENCODE lzo
    ,"trfc_src_tx" VARCHAR(120)   ENCODE lzo
    ,"utm_source_tx" VARCHAR(6000)   ENCODE lzo
    ,"utm_campaign_id" VARCHAR(6000)   ENCODE lzo
    ,"utm_medium_cd" VARCHAR(6000)   ENCODE lzo
    ,"page_function_tx" VARCHAR(45)   ENCODE lzo
    ,"page_hier_lvl1_nm" VARCHAR(200)   ENCODE lzo
    ,"page_hier_lvl2_nm" VARCHAR(200)   ENCODE lzo
    ,"conf_page_path_tx" VARCHAR(3000)   ENCODE lzo
    ,"row_unique_id" VARCHAR(1000)   ENCODE lzo
    ,"dw_load_ts" TIMESTAMP WITHOUT TIME ZONE   ENCODE lzo
)
distkey(row_unique_id)
sortkey(dw_snapshot_dt) ;
GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_report.mktg_fb_multi_step_offline_conv_upload_f TO group grp_etl;
GRANT SELECT ON dw_report.mktg_fb_multi_step_offline_conv_upload_f TO group grp_data_users;
GRANT ALL ON dw_report.mktg_fb_multi_step_offline_conv_upload_f TO nw_dwh_etl;

