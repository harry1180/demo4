delete from dw_report.mktg_fb_multi_step_offline_conv_upload_f where 
dw_snapshot_dt = (select max(dw_snapshot_dt) from dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn) ;

insert into dw_report.mktg_fb_multi_step_offline_conv_upload_f
select
trans.dw_snapshot_dt
, trans.dw_eff_dt
, sv.site_uv_id
, trans.src_sys_id
, trans.dw_site_prod_sk
, trans.commission_am as commission_am
-- cc.credit_card_id, cc.issuer_nm, cc.network_nm, cc.card_seo_nm, cc.card_user, cc.min_fico, cc.max_fico, cc.rating_stars,
, CASE WHEN trans.src_sys_id = '8' THEN aflt_issue_partner_nm || '-' || prod_nm ELSE cc.src_prod_id END src_prod_id
, trans.page_vertical_tx, trans.page_topic_tx
-- sess.*
, sess.trfc_src_tx,sess.utm_source_tx, sess.utm_campaign_id, utm_medium_cd
--sess.first_dw_page_sk, sess.last_dw_page_sk,
, first_pg.page_function_tx, first_pg.page_hier_lvl1_nm, first_pg.page_hier_lvl2_nm, first_pg.conf_page_path_tx
, trans.row_unique_id
, trans.src_clicks_utc_ts
, getdate() dw_load_ts
from
(select
  amp.dw_snapshot_dt
, amp.dw_eff_dt
, amp.src_sys_id
, amp.dw_site_prod_sk
, amp.commission_am
, amp.page_vertical_tx
, amp.page_topic_tx
, amp.revenue_tran_in
, amp.dw_suspected_bot_in
, amp.dw_session_id
, amp.aflt_network_tran_id||'-'||amp.aflt_network_id||'-'||amp.prog_nm as row_unique_id
, case
  when amp.src_clicks_utc_ts is not null then amp.src_clicks_utc_ts
  when amp.tran_click_ts is not null then amp.tran_click_ts
  else dw_load_ts
  end src_clicks_utc_ts
, amp.event_type_nm
from dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn amp
where dw_snapshot_dt = (select max(dw_snapshot_dt) from dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn)) trans

left join dw_report.dw_prod_d cc on trans.dw_site_prod_sk = cc.dw_site_prod_sk and cc.curr_in = 1
left join dw_report.dw_session_event_f sess on trans.dw_session_id = sess.dw_session_id
left join dw_report.site_visitor_d sv on sess.dw_site_visitor_id = sv.dw_site_visitor_id
left join dw_report.dw_page_detail_d first_pg on first_pg.curr_in = 1 and sess.first_dw_page_sk = first_pg.dw_page_sk
--left join dw_report.dw_page_detail_d last_pg  on  last_pg.curr_in = 1 and sess.last_dw_page_sk  = last_pg.dw_page_sk

where
sv.site_uv_id is not null and
--trans.dw_eff_dt > trunc(getdate() - 30) and
-- trans.src_sys_id = 1
trans.revenue_tran_in = 'True'
and trans.commission_am > 0
and trans.dw_suspected_bot_in = 'False'
and trans.event_type_nm = 'TRANSACTION_EVENT'
and not exists
(select 1 from dw_report.mktg_fb_multi_step_offline_conv_upload_f tgt where trans.row_unique_id = tgt.row_unique_id and trans.dw_snapshot_dt = tgt.dw_snapshot_dt)
;

