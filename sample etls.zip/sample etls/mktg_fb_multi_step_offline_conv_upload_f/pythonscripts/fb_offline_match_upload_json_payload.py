import sys, pprint
from datetime import date, timedelta
import base64
import pandas as pd
import pandas.io.sql as psql
#import seaborn as sns
import psycopg2
#from pandas import ExcelWriter
#from pandas.io.parsers import ExcelWriter
from openpyxl.writer.excel import ExcelWriter

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders
import json
import re
from email.mime.text import MIMEText
from subprocess import Popen, PIPE
sys.path.append('/home/ssundara/dwh/Common/nw_python_modules')
from redshift_modules import exec_query
from pprint import *
import hashlib
import urllib2
import requests

####################################       methods        ####################################

sql_qry="select site_uv_id, src_sys_id, commission_am as value, src_prod_id, conf_page_path_tx from dw_report.mktg_fb_multi_step_offline_conv_upload_f where dw_snapshot_dt = (select max(dw_snapshot_dt) from dw_report.mktg_fb_multi_step_offline_conv_upload_f) ;"

sql_output_dict = exec_query(sql_qry)
#print sql_output_dict
FB_PIXEL_ID="612184065591075"
#EVENT_NAME="MultistepTestEvent-Daily-All-Verticals_Prod_id"
EVENT_NAME="Purchase"

def upload_uvs_to_fb(sql_output_dict):

    total_counter=0
    success_counter=0
    exception_counter=0
    
    for uv in sql_output_dict:

        hash_object = hashlib.sha256(uv['site_uv_id'])
        hex_dig = hash_object.hexdigest()
        #print(hex_dig)
        fb_url='https://www.facebook.com/tr/?id='+str(FB_PIXEL_ID)+'&ev='+str(EVENT_NAME)+'&ud[external_id]='+str(hex_dig)+'&cd[src_sys_id]='+str(uv['src_sys_id'])+'&cd[value]='+str(uv['value'])+'&cd[src_prod_id]='+str(uv['src_prod_id'])+'&cd[conf_page_path_tx]='+str(uv['conf_page_path_tx'])+'&cd[currency]=USD'
        #print fb_url
        #urllib2.urlopen(fb_url)

        try:
            r = requests.get(fb_url)
            success_counter +=1
        except:
            exception_counter += 1
 
        total_counter += 1
    print "Done"
    print "EVENT_NAME :",EVENT_NAME
    print "total_counter :",total_counter

#print sql_output_dict
print "Row count from dw_report.mktg_fb_multi_step_offline_conv_upload_f :"+str(len(sql_output_dict))

print "FB_PIXEL_ID :",FB_PIXEL_ID
print "EVENT_NAME :",EVENT_NAME
print "FB Offline upload started..."
upload_uvs_to_fb(sql_output_dict)
print "FB Offline upload completed..."
