INSERT INTO dw_report.mktg_fb_post_perf_f
(
  post_id
, dw_eff_dt
, campaign_domain_id
, campaign_type_id
, vertical_id
, src_sys_id
, post_imprsn_ct
, post_imprsn_unique_ct
, post_imprsn_paid_ct
, post_imprsn_paid_unique_ct
, post_imprsn_fan_ct
, post_imprsn_fan_unique_ct
, post_imprsn_fan_paid_ct
, post_imprsn_fan_paid_unique_ct
, post_imprsn_organic_ct
, post_imprsn_organic_unique_ct
, post_imprsn_viral_ct
, post_imprsn_viral_unique_ct
, post_click_ct
, post_click_unique_ct
, link_click_ct
, other_click_ct
, video_click_ct
, link_click_unique_ct
, other_click_unique_ct
, video_click_unique_ct
, post_engaged_users_ct
, post_neg_fdbk_ct
, post_neg_fdbk_unique_ct
, post_engaged_fan_ct
, post_fan_reach_ct
, post_like_ct
, post_love_ct
, post_wow_ct
, post_haha_ct
, post_sorry_ct
, post_anger_ct
, post_shares_ct
, comments_ct
, post_video_avg_time_watched
, post_video_cmplt_views_organic_ct
, post_video_cmplt_views_organic_unique_ct
, post_video_cmplt_views_paid_ct
, post_video_cmplt_views_paid_unique_ct
, post_video_views_organic_ct
, post_video_views_organic_unique_ct
, post_video_views_paid_ct
, post_video_views_paid_unique_ct
, post_video_len
, post_video_views_ct
, post_video_views_unique_ct
, post_video_views_autoplayed_ct
, post_video_views_clkd_to_play_ct
, post_video_views_10s_ct
, post_video_views_10s_unique_ct
, post_video_views_10s_autoplayed_ct
, post_video_views_10s_clkd_to_play_ct
, post_video_views_10s_organic_ct
, post_video_views_10s_paid_ct
, post_video_views_10s_sound_on_ct
, post_video_views_sound_on_ct
, post_video_view_time_ct
, post_video_view_time_organic_ct
, dw_load_ts
) SELECT
  distinct
  post_id
, trunc(d.created_time) as dw_eff_dt
, dom.campaign_domain_id AS campaign_domain_id
, camp_type.campaign_type_id AS campaign_type_id
, v.vertical_id AS  vertical_id
, '-1' src_sys_id
, post_impressions
, post_impressions_unique
, post_impressions_paid
, post_impressions_paid_unique
, post_impressions_fan
, post_impressions_fan_unique
, post_impressions_fan_paid
, post_impressions_fan_paid_unique
, post_impressions_organic
, post_impressions_organic_unique
, post_impressions_viral
, post_impressions_viral_unique
, post_consumptions
, post_consumptions_unique
, link_clicks
, other_clicks
, video_clicks
, link_clicks_unique
, other_clicks_unique
, video_clicks_unique
, post_engaged_users
, post_negative_feedback
, post_negative_feedback_unique
, post_engaged_fan
, post_fan_reach
, post_reactions_like_total
, post_reactions_love_total
, post_reactions_wow_total
, post_reactions_haha_total
, post_reactions_sorry_total
, post_reactions_anger_total
, post_shares
, comments
, (post_video_avg_time_watched::BIGINT)/1000
, post_video_complete_views_organic
, post_video_complete_views_organic_unique
, post_video_complete_views_paid
, post_video_complete_views_paid_unique
, post_video_views_organic
, post_video_views_organic_unique
, post_video_views_paid
, post_video_views_paid_unique
, (post_video_length::BIGINT)/1000
, post_video_views
, post_video_views_unique
, post_video_views_autoplayed
, post_video_views_clicked_to_play
, post_video_views_10s
, post_video_views_10s_unique
, post_video_views_10s_autoplayed
, post_video_views_10s_clicked_to_play
, post_video_views_10s_organic
, post_video_views_10s_paid
, post_video_views_10s_sound_on
, post_video_views_sound_on
, (post_video_view_time::BIGINT)/1000
, (post_video_view_time_organic::BIGINT)/1000
, getdate() as dw_load_ts
  FROM dw_stage.mktg_fb_post_perf_s s
  LEFT JOIN dw_report.mktg_fb_post_d d ON (s.post_id = d.id)
  LEFT JOIN dw_report.mktg_vertical_d v ON SPLIT_PART(d.utm_campaign_id,'_',1) = SPLIT_PART(v.vertical_short_nm,'_',1)
  LEFT JOIN dw_report.mktg_campaign_domain_d dom ON dom.referrer_nm = 'facebook_social'
  LEFT JOIN dw_report.mktg_campaign_type_d camp_type on camp_type.campaign_domain_id = dom.campaign_domain_id and 'native' =   lower(camp_type.campaign_type_nm);
