DELETE FROM dw_report.mktg_fb_post_perf_f
WHERE post_id IN (SELECT DISTINCT post_id
                  FROM dw_stage.mktg_fb_post_perf_s);
