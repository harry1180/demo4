INSERT INTO dw_report.mktg_fb_ad_social_perf_f
(
    acct_id
  , acct_nm
  , campaign_id
  , campaign_nm
  , campaign_domain_id
  , campaign_type_id
  , vertical_id
  , adset_id
  , adset_nm
  , ad_id
  , ad_nm
  , click_ct
  , cpm
  , cpp
  , ctr
  , dw_eff_dt
  , freq_ct
  , imprsn_ct
  , inline_link_click_ct
  , reach_ct
  , social_click_ct
  , social_imprsn_ct
  , social_reach_ct
  , spend_am
  , src_sys_id
  , total_actn_val_am
  , total_unique_actn_ct
  , unique_click_ct
  , unique_ctr
  , unique_inline_link_click_ct
  , unique_social_click_ct
  , dev_type_cd
  , comment_ct
  , share_ct
  , post_like_ct
  , post_love_ct
  , post_sad_ct
  , post_wow_ct
  , post_haha_ct
  , post_sorry_ct
  , post_anger_ct
  , page_egmt_ct
  , post_egmt_ct
  , video_view_ct
  , video_10_sec_view_ct
  , video_30_sec_view_ct
  , acct_curr_cd
  , acct_tz_nm
  , dw_load_ts
)
SELECT
   s.account_id AS acct_id
  ,s.account_name	AS acct_nm
  ,s.campaign_id::BIGINT	AS campaign_id
  ,s.campaign_name	AS campaign_nm
  ,dom.campaign_domain_id AS campaign_domain_id
  ,camp_type.campaign_type_id AS campaign_type_id
  ,v.vertical_id AS  vertical_id
  ,s.adset_id::BIGINT	AS adset_id
  ,s.adset_name	AS adset_nm
  ,s.ad_id
  ,s.ad_nm
  ,s.clicks::INTEGER	AS click_ct
  ,s.cpm::DECIMAL(10,3)	AS cpm
  ,s.cpp::DECIMAL(10,3)	AS cpp
  ,s.ctr::DECIMAL(10,3)	AS ctr
  ,s.date_start::DATE	AS dw_eff_dt
  ,s.frequency::NUMERIC(23,13)		AS freq_ct
  ,s.impressions::INTEGER	AS imprsn_ct
  ,s.inline_link_clicks::INTEGER	AS inline_link_clicks_ct
  ,s.reach::INTEGER	AS reach_ct
  ,s.social_clicks::INTEGER	AS social_clicks_ct
  ,s.social_impressions::INTEGER	AS social_imprsn_ct
  ,s.social_reach::INTEGER	AS social_reach_ct
  ,s.spend::DECIMAL(10,3)	AS spend_am
  ,COALESCE(xref.src_sys_id,-1)  AS  src_sys_id
  ,s.total_action_value::DECIMAL(10,3)	AS total_actn_value_am
  ,s.total_unique_actions::INTEGER	AS total_unique_actns_ct
  ,s.unique_clicks::INTEGER	AS unique_clicks_ct
  ,s.unique_ctr::DECIMAL(10,3)	 AS unique_ctr
  ,s.unique_inline_link_clicks::INTEGER	AS unique_inline_link_clicks_ct
  ,s.unique_social_clicks::INTEGER	AS unique_social_clicks_ct
  ,s.device_platform AS dev_type_cd
  ,s.comment::INTEGER as comment
  ,s.shares::INTEGER as share
  ,s.post_reaction_like::INTEGER as post_like_ct
  ,s.post_reaction_love::INTEGER as post_love_ct
  ,s.post_reaction_sad::INTEGER as post_sad_ct
  ,s.post_reaction_wow::INTEGER as post_wow_ct
  ,s.post_reaction_haha::INTEGER as post_haha_ct
  ,s.post_reaction_sorry::INTEGER as post_sorry_ct
  ,s.post_reaction_anger::INTEGER as post_anger_ct
  ,s.page_engagement::INTEGER as page_egmt_ct
  ,s.post_engagement::INTEGER as post_egmt_ct
  ,s.video_views::INTEGER as video_views_ct
  ,s.video_10_sec_watched_views::INTEGER as video_10_sec_views_ct
  ,s.video_30_sec_watched_views::INTEGER as video_30_sec_views_ct
  ,s.currency AS acct_currency_cd
  ,s.timezone_name AS acct_tz_nm
  ,getdate() dw_load_ts
FROM
dw_stage.mktg_fb_ad_social_perf_s s
LEFT JOIN dw_report.mktg_src_sys_campaign_domain_xref xref ON COALESCE(s.account_id::VARCHAR(100),'N/A') = COALESCE(xref.campaign_domain_ext_acct_id,'N/A') AND xref.referrer_nm = 'facebook_social'
LEFT JOIN dw_report.mktg_vertical_d v ON SPLIT_PART(COALESCE(s.adset_name,'N/A'),'_',1) = SPLIT_PART(COALESCE(v.vertical_short_nm,'N/A'),'_',1)
LEFT JOIN dw_report.mktg_campaign_domain_d dom ON dom.referrer_nm = 'facebook_social'
LEFT JOIN dw_report.mktg_campaign_type_d camp_type on COALESCE(camp_type.campaign_domain_id,'N/A') = COALESCE(dom.campaign_domain_id,'N/A') and 'native' =   lower(camp_type.campaign_type_nm);

