DELETE FROM dw_report.mktg_fb_ad_social_perf_f
WHERE EXISTS(SELECT 1
FROM dw_stage.mktg_fb_ad_social_perf_s stg
WHERE stg.ad_id = dw_report.mktg_fb_ad_social_perf_f.ad_id AND
stg.date_start = dw_report.mktg_fb_ad_social_perf_f.dw_eff_dt);
