#/usr/bin/python
"""Getting Facebook performance data through API call and convert results to json file.

Input file is .json file contains query string, output file name based on the group of attributes,
query string to call Facebook API and input/output directories.
run example:
  python fb_to_json.py -c config.json -i /Users/uname/tmp/ -o /Users/uname/tmp/
         --fb_app_id=xxx --fb_app_secret=xxx --fb_access_token=xxx
"""
import argparse
import json
import os
import sys
import pprint
from datetime import datetime
import time

from facebookads import FacebookAdsApi
from facebookads.adobjects.adaccountuser import AdAccountUser 

import fb_modules
from nw_generic_utils_modules import export_to_json_redshift


def main():
    """Do work"""
    # Get FB API
    api = fb_modules.get_api(
        app_id=fb_app_id,
        app_secret=fb_app_secret,
        access_token=fb_access_token)
    FacebookAdsApi.set_default_api(api)

    # Setup user and read the object from the server
    me = AdAccountUser(fbid='me')

    # Read user permissionsa
    print('>>> Reading permissions field of user:')
    pp.pprint(me.remote_read(fields=[AdAccountUser.Field.permissions]))

    # Get all accounts connected to the user
    accounts = fb_modules.get_accounts(me)

    fields = CONFIG['params']['fields']
    data = []
    print '>>> Reading accounts associated with user'
    for account in accounts:
        print "Getting Campaign Stats..."
        campaigns_data = fb_modules.to_dict(
            fb_api_data=account.get_campaigns(params=CONFIG['params']),
            fields=fields)
        data.extend(campaigns_data)
        time.sleep(3)
    # Create Redshift json file
    export_to_json_redshift(data, os.path.join(
        output_file_dir, CONFIG['dwh_file_name'] + '.json'))


if __name__ == '__main__':
    desc = (
        "Getting Facebook campaign dimenssion data through API call and convert results to json file."
    )
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument(
        '-c',
        '--config_file',
        required=True,
        action='store',
        dest='config_file',
        help='Config json file with "fields":[field1...]')
    parser.add_argument(
        '-i',
        '--input_dir',
        required=True,
        action='store',
        dest='input_dir',
        help='Input directory')
    parser.add_argument(
        '-o',
        '--output_dir',
        required=True,
        action='store',
        dest='output_dir',
        help='Output directory')
    parser.add_argument(
        '--fb_app_id',
        required=True,
        action='store',
        dest='fb_app_id',
        help='FB App ID')
    parser.add_argument(
        '--fb_app_secret',
        required=True,
        action='store',
        dest='fb_app_secret',
        help='FB App Secret')
    parser.add_argument(
        '--fb_access_token',
        required=True,
        action='store',
        dest='fb_access_token',
        help='FB App Access Token')

    args = parser.parse_args()

    # input file name e.g. config.json
    input_config_file_nm = args.config_file

    # input file location
    input_file_dir = args.input_dir

    # output file location
    output_file_dir = args.output_dir

    # get FB credentials
    fb_app_id = args.fb_app_id
    fb_app_secret = args.fb_app_secret
    fb_access_token = args.fb_access_token

    pp = pprint.PrettyPrinter(indent=4)
    this_dir = os.path.dirname(__file__)
    config_filename = os.path.join(this_dir, input_config_file_nm)

    # Read config file
    try:
        with open(config_filename) as config_file:
            CONFIG = json.load(config_file)
    except Exception, e:
        print "Error: can not open config file {}".format(config_filename)
        print str(e)
        sys.exit(1)

    # Do work
    main()
