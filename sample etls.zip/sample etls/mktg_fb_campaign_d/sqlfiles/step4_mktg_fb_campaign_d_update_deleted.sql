UPDATE dw_report.mktg_fb_campaign_d
SET dw_expr_dt      = trunc(SYSDATE)-1,
    curr_in         = 0,
    dw_last_updt_ts = SYSDATE,
    dw_last_updt_tx = 'Update expire deleted'
FROM
(
  SELECT temp_prod.*,
  s.campaign_id AS record_exists
  FROM
  (
    SELECT MAX(dw_load_ts) AS dw_load_ts,
           campaign_id
    FROM dw_report.mktg_fb_campaign_d
    GROUP BY 2
  ) temp_prod
LEFT OUTER JOIN dw_stage.mktg_fb_campaign_w s ON s.campaign_id = temp_prod.campaign_id
) filtered_records
WHERE filtered_records.record_exists IS NULL
AND   dw_report.mktg_fb_campaign_d.campaign_id  =  filtered_records.campaign_id
AND   dw_report.mktg_fb_campaign_d.dw_load_ts =  filtered_records.dw_load_ts
AND   dw_report.mktg_fb_campaign_d.CURR_IN    =  1
AND   dw_report.mktg_fb_campaign_d.DEL_IN     <> 1
;
