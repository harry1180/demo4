DELETE FROM dw_stage.mktg_fb_campaign_w ;

INSERT INTO dw_stage.mktg_fb_campaign_w(
ext_customer_id
,campaign_id
,campaign_nm
,buying_type_cd
,configured_status_cd
,effective_status_cd
,objective_cd
,src_start_ts
,src_stop_ts
,src_updated_ts
,dw_eff_dt
,dw_expr_dt
,curr_in
,del_in
,campaign_domain_id
,campaign_type_id
,vertical_id
,src_sys_id
,dw_last_updt_ts
,dw_last_updt_tx
,dw_load_ts
)
SELECT
s.account_id::BIGINT AS ext_customer_id
,s.id::BIGINT	AS campaign_id
,s.name	AS campaign_nm
,s.buying_type AS buying_type_cd
,s.configured_status AS configured_status_cd
,s.effective_status AS effective_status_cd
,s.objective AS objective_cd
,s.start_time::TIMESTAMP AS src_start_ts
,s.stop_time::TIMESTAMP AS src_stop_ts
,s.updated_time::TIMESTAMP AS src_updated_ts
,s.updated_time::DATE dw_eff_dt
,TO_DATE('9999-01-01','YYYY-MM-DD') AS dw_expr_dt
,1 AS curr_in
,0 AS del_in
,dom.campaign_domain_id AS campaign_domain_id
,camp_type.campaign_type_id AS campaign_type_id
,v.vertical_id AS  vertical_id
,COALESCE(xref.src_sys_id,-1)  AS  src_sys_id
,getdate() dw_load_ts
,'INSERT_NEW'
,getdate() dw_load_ts

FROM
dw_stage.mktg_fb_campaign_s s
LEFT JOIN dw_report.mktg_src_sys_campaign_domain_xref xref ON s.account_id::VARCHAR(100)=xref.campaign_domain_ext_acct_id AND xref.referrer_nm = 'facebook'
LEFT JOIN dw_report.mktg_vertical_d v ON SPLIT_PART(s.name,'_',1) = SPLIT_PART(v.vertical_short_nm,'_',1)
LEFT JOIN dw_report.mktg_campaign_domain_d dom ON dom.referrer_nm = 'facebook'
LEFT JOIN dw_report.mktg_campaign_type_d camp_type ON camp_type.campaign_domain_id = dom.campaign_domain_id AND 'native' = LOWER(camp_type.campaign_type_nm)
;
