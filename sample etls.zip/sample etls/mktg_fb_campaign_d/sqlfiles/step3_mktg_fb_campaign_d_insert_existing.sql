INSERT INTO dw_report.mktg_fb_campaign_d (
  ext_customer_id
  ,campaign_id
  ,campaign_nm
  ,buying_type_cd
  ,configured_status_cd
  ,effective_status_cd
  ,objective_cd
  ,src_start_ts
  ,src_stop_ts
  ,src_updated_ts
  ,dw_eff_dt
  ,dw_expr_dt
  ,curr_in
  ,del_in
  ,campaign_domain_id
  ,campaign_type_id
  ,vertical_id
  ,src_sys_id
  ,dw_last_updt_ts
  ,dw_last_updt_tx
  ,dw_load_ts
)
SELECT
  w.ext_customer_id
  ,w.campaign_id
  ,w.campaign_nm
  ,w.buying_type_cd
  ,w.configured_status_cd
  ,w.effective_status_cd
  ,w.objective_cd
  ,w.src_start_ts
  ,w.src_stop_ts
  ,w.src_updated_ts
  ,w.dw_eff_dt
  ,TO_DATE('9999-01-01','YYYY-MM-DD')
  ,1
  ,0
  ,w.campaign_domain_id
  ,w.campaign_type_id
  ,w.vertical_id
  ,w.src_sys_id
  ,w.dw_last_updt_ts
  ,w.dw_last_updt_tx
  ,w.dw_load_ts
FROM dw_stage.mktg_fb_campaign_w w
INNER JOIN
(
  SELECT *
  FROM
  (
    SELECT *
      , row_number() over(partition BY campaign_id ORDER BY dw_load_ts DESC) AS dedup_flag
      FROM dw_report.mktg_fb_campaign_d d
  ) sub
  WHERE dedup_flag = 1
) tgt
ON
    w.campaign_id = tgt.campaign_id
WHERE (
        --inserting changed record
       (
       COALESCE(tgt.campaign_nm,'NA')              <>  COALESCE(w.campaign_nm,'NA')
       OR COALESCE(tgt.ext_customer_id,0)       <>  COALESCE(w.ext_customer_id,0)
       OR COALESCE(tgt.buying_type_cd ,'NA')       <>  COALESCE(w.buying_type_cd,'NA')
       OR COALESCE(tgt.configured_status_cd,'NA')       <>  COALESCE(w.configured_status_cd,'NA')
       OR COALESCE(tgt.effective_status_cd,'NA')       <>  COALESCE(w.effective_status_cd,'NA')
       OR COALESCE(tgt.objective_cd,'NA')       <>  COALESCE(w.objective_cd,'NA')

        )
        -- inserting deleted record
        OR tgt.curr_in = 0
    );
