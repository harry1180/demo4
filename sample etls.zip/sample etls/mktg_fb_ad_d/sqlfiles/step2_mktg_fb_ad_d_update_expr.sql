UPDATE dw_report.mktg_fb_ad_d
SET dw_expr_dt      = trunc(SYSDATE) - 1,
    curr_in         = 0,
    dw_last_updt_ts = SYSDATE,
    dw_last_updt_tx = 'Update expire existing'
FROM dw_stage.mktg_fb_ad_w w
WHERE w.ad_id = dw_report.mktg_fb_ad_d.ad_id
AND dw_report.mktg_fb_ad_d.curr_in = 1
AND (
COALESCE(dw_report.mktg_fb_ad_d.ad_nm,'NA')              <>  COALESCE(w.ad_nm,'NA')
OR COALESCE(dw_report.mktg_fb_ad_d.ext_customer_id,0)       <>  COALESCE(w.ext_customer_id,0)
OR COALESCE(dw_report.mktg_fb_ad_d.effective_status_cd,'NA')       <>  COALESCE(w.effective_status_cd,'NA')
OR COALESCE(dw_report.mktg_fb_ad_d.configured_status_cd,'NA')       <>  COALESCE(w.configured_status_cd,'NA')
OR COALESCE(dw_report.mktg_fb_ad_d.src_updated_ts,SYSDATE)       <>  COALESCE(w.src_updated_ts,SYSDATE)
OR COALESCE(dw_report.mktg_fb_ad_d.del_in, 0)                  =   1
)
;
