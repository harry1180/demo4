UPDATE dw_report.mktg_fb_ad_d
SET dw_expr_dt      = trunc(SYSDATE)-1,
    curr_in         = 0,
    dw_last_updt_ts = SYSDATE,
    dw_last_updt_tx = 'Update expire deleted'
FROM
(
  SELECT temp_prod.*,
  s.ad_id AS record_exists
  FROM
  (
    SELECT MAX(dw_load_ts) AS dw_load_ts,
           ad_id
    FROM dw_report.mktg_fb_ad_d
    GROUP BY 2
  ) temp_prod
LEFT OUTER JOIN dw_stage.mktg_fb_ad_w s ON s.ad_id = temp_prod.ad_id
) filtered_records
WHERE filtered_records.record_exists IS NULL
AND   dw_report.mktg_fb_ad_d.ad_id  =  filtered_records.ad_id
AND   dw_report.mktg_fb_ad_d.dw_load_ts =  filtered_records.dw_load_ts
AND   dw_report.mktg_fb_ad_d.CURR_IN    =  1
AND   dw_report.mktg_fb_ad_d.DEL_IN     <> 1
;
