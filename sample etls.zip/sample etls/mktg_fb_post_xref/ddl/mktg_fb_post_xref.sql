DROP TABLE dw_report.mktg_fb_post_xref;

CREATE TABLE "dw_report"."mktg_fb_post_xref"
(

     "creative_id"    VARCHAR(500)   ENCODE lzo
    ,"dw_eff_dt" DATE
    ,"ad_id"    VARCHAR(500)   ENCODE lzo
    ,"adset_id"    VARCHAR(500)   ENCODE lzo
    ,"post_id"    VARCHAR(500)   ENCODE lzo
    ,"dw_load_ts" TIMESTAMP
)
DISTSTYLE KEY
DISTKEY ("ad_id")
SORTKEY (
    "dw_eff_dt"
    ) ;

GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON "dw_report"."mktg_fb_post_xref" TO group grp_etl;
GRANT SELECT ON "dw_report"."mktg_fb_post_xref" TO group grp_data_users;
GRANT ALL ON "dw_report"."mktg_fb_post_xref" to nw_dwh_etl;
