DROP TABLE dw_stage.mktg_fb_post_xref_s;

CREATE TABLE "dw_stage"."mktg_fb_post_xref_s"
(

     "creative_id"    VARCHAR(500)   ENCODE lzo
    ,"ad_id"    VARCHAR(500)   ENCODE lzo
    ,"post_id"    VARCHAR(500)   ENCODE lzo
)
DISTSTYLE KEY
DISTKEY ("ad_id")
SORTKEY (
    "ad_id"
    ) ;

GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON "dw_stage"."mktg_fb_post_xref_s" TO group grp_etl;
GRANT SELECT ON "dw_stage"."mktg_fb_post_xref_s" TO group grp_data_users;
GRANT ALL ON "dw_stage"."mktg_fb_post_xref_s" to nw_dwh_etl;