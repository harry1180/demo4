#/usr/bin/python
"""Getting Facebook performance data through API call and convert results to json file.

Input file is .json file contains query string, output file name based on the group of attributes,
query string to call Facebook API and input/output directories.
run example:
  python fb_to_json.py -c config.json -i /Users/uname/tmp/ -o /Users/uname/tmp/ -s 2016-08-30
                       -e 2016-08-300 --fb_app_id=xxx --fb_app_secret=xxx --fb_access_token=xxx
"""
import argparse
import json
import os
import sys
import pprint
from datetime import datetime
import time

from facebook_business import FacebookAdsApi
from facebook_business.adobjects.adaccountuser import AdAccountUser
from facebook_business.adobjects.adcreative import AdCreative

import fb_modules
from nw_generic_utils_modules import export_to_json_redshift

# Social
SOCIAL_ACCT = 'act_10155375447713502'

def valid_date(s):
    try:
        dt = datetime.strptime(s, "%Y-%m-%d")
        return s
    except ValueError:
        msg = "Not a valid date format('yyyy-mm-dd): '{0}'.".format(s)
        raise argparse.ArgumentTypeError(msg)


def get_creative_id(ad):

    creative_id = None
    try:
        creative_id = ad['creative']['id']
    except KeyError:
        print 'creative Id not found'

    return creative_id


def convert_to_json(creative):
    creative_json = {}

    creative_json['creative_id'] = creative.get('creative_id')
    creative_json['ad_id'] = creative.get('ad_id')
    creative_json['object_story_id'] = creative.get('effective_object_story_id')

    return creative_json


def main(start_dt, end_dt):
    """Do work"""
    # Get FB API
    api = fb_modules.get_api(
        app_id=fb_app_id,
        app_secret=fb_app_secret,
        access_token=fb_access_token)
    FacebookAdsApi.set_default_api(api)

    # Setup user and read the object from the server
    me = AdAccountUser(fbid='me')

    # Read user permissionsa
    print '>>> Reading permissions field of user:'
    #pp.pprint(me.remote_read(fields=[AdAccountUser.Field.permissions]))

    params = CONFIG['params']

    # Add date range to params
    params['time_range'] = {'since':start_dt, 'until':end_dt}

    # Get all accounts connected to the user
    accounts = fb_modules.get_accounts(me)

    fields = CONFIG['params']['fields']
    print '>>> Reading accounts associated with user'
    ads_crtv_data = []
    for account in accounts:

        # download only for social account
        if account['id'] == SOCIAL_ACCT:

            print "Getting ads ..."
            ads_data = fb_modules.to_dict(
                fb_api_data=account.get_ads(params=CONFIG['params']),
                fields=fields)

            # Fetch creative id from add and get object story id
            for ad in ads_data:
                creative_id = get_creative_id(ad)

                if creative_id is not None:
                    creative = AdCreative(creative_id)
                    creative_data = creative.remote_read(fields=[AdCreative.Field.name,
                                                                 AdCreative.Field.effective_object_story_id])

                    creative_data['ad_id'] = ad['id']
                    creative_json = convert_to_json(creative_data)
                    print creative_json
                    ads_crtv_data.append(creative_json)

    # Create Redshift json file
    export_to_json_redshift(ads_crtv_data, os.path.join(
        output_file_dir, CONFIG['dwh_file_name'] + '.json'))


if __name__ == '__main__':
    desc = (
        "Getting Facebook performance data through API call and convert results to json file."
    )
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument(
        '-c',
        '--config_file',
        required=True,
        action='store',
        dest='config_file',
        help='Config json file with "fields":[field1...] and/or "breakdowns":[field1...]')
    parser.add_argument(
        '-i',
        '--input_dir',
        required=True,
        action='store',
        dest='input_dir',
        help='Input directory')
    parser.add_argument(
        '-o',
        '--output_dir',
        required=True,
        action='store',
        dest='output_dir',
        help='Output directory')
    parser.add_argument(
        '-s',
        '--start_date',
        required=True,
        action='store',
        type=valid_date,
        dest='start_date',
        help='Start date in "yyyy-mm-dd" format')
    parser.add_argument(
        '-e',
        '--end_date',
        required=True,
        action='store',
        type=valid_date,
        dest='end_date',
        help='End date in "yyyy-mm-dd" format')
    parser.add_argument(
        '--fb_app_id',
        required=True,
        action='store',
        dest='fb_app_id',
        help='FB App ID')
    parser.add_argument(
        '--fb_app_secret',
        required=True,
        action='store',
        dest='fb_app_secret',
        help='FB App Secret')
    parser.add_argument(
        '--fb_access_token',
        required=True,
        action='store',
        dest='fb_access_token',
        help='FB App Access Token')

    args = parser.parse_args()

    # input file name e.g. config.json
    input_config_file_nm = args.config_file

    # input file location
    input_file_dir = args.input_dir

    # output file location
    output_file_dir = args.output_dir

    # dates
    start_date, end_date = args.start_date, args.end_date
    print "date_range: " + start_date + ',' + end_date

    # get FB credentials
    fb_app_id = args.fb_app_id
    fb_app_secret = args.fb_app_secret
    fb_access_token = args.fb_access_token

    pp = pprint.PrettyPrinter(indent=4)
    this_dir = os.path.dirname(__file__)
    config_filename = os.path.join(this_dir, input_config_file_nm)

    # Read config file
    try:
        with open(config_filename) as config_file:
            CONFIG = json.load(config_file)
    except Exception, e:
        print "Error: can not open config file {}".format(config_filename)
        print str(e)
        sys.exit(1)

    # Do work
    main(start_date, end_date)
