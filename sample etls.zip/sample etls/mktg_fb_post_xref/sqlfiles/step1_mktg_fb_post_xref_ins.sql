INSERT INTO dw_report.mktg_fb_post_xref (
    creative_id,
    dw_eff_dt,
    ad_id,
    adset_id,
    post_id,
    dw_load_ts
)
  SELECT
  distinct
    creative_id,
    trunc(sysdate),
    stg.ad_id,
    fct.adset_id,
    post_id,
    sysdate
  FROM dw_stage.mktg_fb_post_xref_s stg
        LEFT OUTER JOIN (SELECT DISTINCT
          ad_id,
          adset_id
        FROM dw_report.mktg_fb_ad_perf_f) fct ON stg.ad_id = fct.ad_id ;

