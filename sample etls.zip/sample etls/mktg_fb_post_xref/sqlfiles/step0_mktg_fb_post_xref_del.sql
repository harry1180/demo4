DELETE FROM dw_report.mktg_fb_post_xref
WHERE creative_id IN (SELECT DISTINCT creative_id
                      FROM dw_stage.mktg_fb_post_xref_s);
