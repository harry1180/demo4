INSERT INTO dw_report.mktg_fb_adset_d(
ext_customer_id
,adset_id
,adset_nm
,configured_status_cd
,src_created_ts
,effective_status_cd
,src_start_ts
,src_updated_ts
,dw_eff_dt
,dw_expr_dt
,curr_in
,del_in
,campaign_domain_id
,campaign_type_id
,vertical_id
,src_sys_id
,dw_last_updt_ts
,dw_last_updt_tx
,dw_load_ts
)
SELECT
w.ext_customer_id
,w.adset_id
,w.adset_nm
,w.configured_status_cd
,w.src_created_ts
,w.effective_status_cd
,w.src_start_ts
,w.src_updated_ts
,w.dw_eff_dt
,w.dw_expr_dt
,w.curr_in
,w.del_in
,w.campaign_domain_id
,w.campaign_type_id
,w.vertical_id
,w.src_sys_id
,w.dw_last_updt_ts
,w.dw_last_updt_tx
,w.dw_load_ts

FROM dw_stage.mktg_fb_adset_w w
WHERE NOT EXISTS
(SELECT 1 FROM dw_report.mktg_fb_adset_d d WHERE w.adset_id = d.adset_id)
;
