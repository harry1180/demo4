INSERT INTO dw_report.mktg_fb_adset_d(
  ext_customer_id
  ,adset_id
  ,adset_nm
  ,configured_status_cd
  ,src_created_ts
  ,effective_status_cd
  ,src_start_ts
  ,src_updated_ts
  ,dw_eff_dt
  ,dw_expr_dt
  ,curr_in
  ,del_in
  ,campaign_domain_id
  ,campaign_type_id
  ,vertical_id
  ,src_sys_id
  ,dw_last_updt_ts
  ,dw_last_updt_tx
  ,dw_load_ts
)
SELECT
  ext_customer_id
  ,adset_id
  ,adset_nm
  ,configured_status_cd
  ,src_created_ts
  ,effective_status_cd
  ,src_start_ts
  ,src_updated_ts
  ,dw_eff_dt
  ,TO_DATE('9999-01-01','YYYY-MM-DD') AS dw_expr_dt
  ,1 AS curr_in
  ,0 AS del_in
  ,campaign_domain_id
  ,campaign_type_id
  ,vertical_id
  ,src_sys_id
  ,dw_last_updt_ts
  ,dw_last_updt_tx
  ,SYSDATE AS dw_load_ts
FROM
(
  SELECT t.*
  FROM dw_report.mktg_fb_adset_d t,
  (
    SELECT temp_prod.*,
           s.adset_id AS record_exists
    FROM
    (
      SELECT MAX(dw_load_ts) AS dw_load_ts,
             adset_id
      FROM dw_report.mktg_fb_adset_d
      GROUP BY 2
  ) temp_prod
  LEFT OUTER JOIN dw_stage.mktg_fb_adset_w s ON s.adset_id = TEMP_PROD.adset_id
) filtered_records
WHERE filtered_records.record_exists IS NULL
AND   t.adset_id  = filtered_records.adset_id
AND   t.dw_load_ts = filtered_records.dw_load_ts
AND   t.curr_in    = 0
AND   t.del_in     = 0
)
;
