DROP TABLE dw_report.mktg_fb_adset_d;

CREATE TABLE dw_report.mktg_fb_adset_d
(
ext_customer_id          BIGINT          ENCODE LZO
,adset_id                BIGINT          ENCODE LZO
,adset_nm                VARCHAR(2000)   ENCODE LZO
,configured_status_cd    VARCHAR(100)    ENCODE LZO
,src_created_ts      TIMESTAMP       ENCODE lzo
,effective_status_cd     VARCHAR(100)    ENCODE LZO
,src_start_ts            TIMESTAMP       ENCODE lzo
,src_updated_ts          TIMESTAMP       ENCODE lzo
,dw_eff_dt               DATE            ENCODE lzo
,dw_expr_dt              DATE            ENCODE lzo
,curr_in		             INTEGER         ENCODE LZO
,del_in				           INTEGER         ENCODE LZO
,campaign_domain_id      VARCHAR(100)    ENCODE LZO
,campaign_type_id        VARCHAR(100)    ENCODE LZO
,vertical_id             VARCHAR(100)    ENCODE LZO
,src_sys_id		       INTEGER         ENCODE LZO
,dw_last_updt_ts	       TIMESTAMP       ENCODE LZO
,dw_last_updt_tx	       VARCHAR(1000)   ENCODE LZO
,dw_load_ts			         TIMESTAMP       ENCODE LZO
)
          DISTSTYLE KEY
          DISTKEY (adset_id)
          SORTKEY (
          dw_eff_dt
              ) ;
          GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON
               dw_report.mktg_fb_adset_d TO group grp_etl;
          GRANT SELECT ON dw_report.mktg_fb_adset_d TO group grp_data_users;
          GRANT ALL ON dw_report.mktg_fb_adset_d to nw_dwh_etl;
