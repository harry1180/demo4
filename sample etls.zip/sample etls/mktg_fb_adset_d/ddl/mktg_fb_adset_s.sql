
          DROP TABLE "dw_stage"."mktg_fb_adset_s";

          CREATE TABLE "dw_stage"."mktg_fb_adset_s"
          (

             "account_id"    VARCHAR(2000)   ENCODE lzo
,    "configured_status"    VARCHAR(2000)   ENCODE lzo
,    "created_time"    VARCHAR(2000)   ENCODE lzo
,    "effective_status"    VARCHAR(2000)   ENCODE lzo
,    "id"    VARCHAR(2000)   ENCODE lzo
,    "name"    VARCHAR(2000)   ENCODE lzo
,    "start_time"    VARCHAR(2000)   ENCODE lzo
,    "updated_time"    VARCHAR(2000)   ENCODE lzo
          )
          DISTSTYLE KEY
          DISTKEY ("id")
          SORTKEY (
              "created_time"
              ) ;
          GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON
               dw_stage.mktg_fb_adset_s TO group grp_etl;
          GRANT SELECT ON dw_stage.mktg_fb_adset_s TO group grp_data_users;
          GRANT ALL ON dw_stage.mktg_fb_adset_s to nw_dwh_etl;
          