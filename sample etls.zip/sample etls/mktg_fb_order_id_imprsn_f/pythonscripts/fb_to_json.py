'''
    Connect with Facebook's graph api and fetch Nerdwallet page post data!
'''

import argparse
import calendar
from datetime import datetime
import json
import requests
import pprint
import os
import sys
import time

from fb_graph_api import GraphAPI
from facebook_business import FacebookAdsApi
from facebook_business.adobjects.adaccountuser import AdAccountUser

import fb_modules
from nw_generic_utils_modules import export_to_json_redshift

API_ATTEMPTS = 5
TIMEOUT = 1 * 60


def valid_date(s):
    try:
        dt = datetime.strptime(s, "%Y-%m-%d")
        return s
    except ValueError:
        msg = "Not a valid date format('yyyy-mm-dd): '{0}'.".format(s)
        raise argparse.ArgumentTypeError(msg)


def get_api_data(graph_api, end_point, params):
    """Get impression data via API with pagination"""
    data = []
    raw_data, next_url = graph_api.request(
        end_points=[end_point], params=params, paginate=None)
    data.extend(raw_data.get("data"))

    count = 1
    while next_url:
        print "Calling next url {0}".format(count)
        raw_data, next_url = graph_api.request(
            params=params, paginate=next_url)
        data.extend(raw_data.get("data"))
        time.sleep(1)
        count += 1
    return data


def mk_flat_data(nested_data):
    """Convert nested data to flatten"""
    flat_data = list()
    for data in nested_data:
        if data["attributions"]:
            non_attr = {key: item
                        for key, item in data.items() if key != 'attributions'}
            for abbr in data["attributions"]:
                flat_item = dict()
                flat_item.update(abbr)
                flat_item.update(non_attr)
                flat_data.append(flat_item)
    return flat_data


def main(start_date, end_date):
    """Do work"""
    order_id_data = []
    attempt = 1
    while attempt <= API_ATTEMPTS:
        try:

            # Get graph api
            graph_api = GraphAPI(
                access_token=fb_access_token,
                app_secret=fb_app_secret)

            # Create params
            params = {}
            params['since'] = calendar.timegm(time.strptime(start_date, '%Y-%m-%d'))
            params['until'] = calendar.timegm(time.strptime(end_date, '%Y-%m-%d'))
            params['pixel_id'] = CONFIG['pixel_id']
            #params['app_id'] = CONFIG['app_id']
            params['limit'] = 100

            print "Getting data..."
            #import pdb; pdb.set_trace()
            flat_data = mk_flat_data(
                get_api_data(
                    graph_api,
                    CONFIG['end_point'].format(biz_id=CONFIG['biz_id']),
                    params))
            order_id_data.extend(flat_data)
            break
        except Exception, e:
            print "Error: can not get the data via Facebook API."
            print str(e)
            if attempt == API_ATTEMPTS:
                print "Error: can't get the data via Facebook API after {} attempts".format(
                    attempt)
                sys.exit(1)
            attempt += 1
            time.sleep(TIMEOUT)

    # Create Redshift json file
    export_to_json_redshift(order_id_data, os.path.join(
        output_file_dir, CONFIG['dwh_file_name'] + '.json'))


if __name__ == '__main__':
    desc = (
        "Getting Facebook performance data through API call and convert results to json file."
    )
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument(
        '-c',
        '--config_file',
        required=True,
        action='store',
        dest='config_file',
        help='Config json file with "fields":[field1...] and/or "breakdowns":[field1...]')
    parser.add_argument(
        '-i',
        '--input_dir',
        required=True,
        action='store',
        dest='input_dir',
        help='Input directory')
    parser.add_argument(
        '-o',
        '--output_dir',
        required=True,
        action='store',
        dest='output_dir',
        help='Output directory')
    parser.add_argument(
        '-s',
        '--start_date',
        required=True,
        action='store',
        type=valid_date,
        dest='start_date',
        help='Start date in "yyyy-mm-dd" format')
    parser.add_argument(
        '-e',
        '--end_date',
        required=True,
        action='store',
        type=valid_date,
        dest='end_date',
        help='End date in "yyyy-mm-dd" format')
    parser.add_argument(
        '--fb_app_id',
        required=True,
        action='store',
        dest='fb_app_id',
        help='FB App ID')
    parser.add_argument(
        '--fb_app_secret',
        required=True,
        action='store',
        dest='fb_app_secret',
        help='FB App Secret')
    parser.add_argument(
        '--fb_access_token',
        required=True,
        action='store',
        dest='fb_access_token',
        help='FB App Access Token')

    args = parser.parse_args()

    start_date, end_date = args.start_date, args.end_date
    print "date_range: " + start_date + ',' + end_date

    # input file name e.g. config.json
    input_config_file_nm = args.config_file

    # output file location
    output_file_dir = args.output_dir

    # get FB credentials
    fb_app_id = args.fb_app_id
    fb_app_secret = args.fb_app_secret
    fb_access_token = args.fb_access_token

    pp = pprint.PrettyPrinter(indent=4)
    this_dir = os.path.dirname(__file__)
    config_filename = os.path.join(this_dir, input_config_file_nm)

    # Read config file
    try:
        with open(config_filename) as config_file:
            CONFIG = json.load(config_file)
    except Exception, e:
        print "Error: can not open config file {}".format(config_filename)
        print str(e)
        sys.exit(1)

    # Do work
    main(start_date, end_date)
