DELETE FROM dw_report.mktg_fb_order_id_imprsn_f
WHERE
dw_eff_dt >= current_date - 28;
