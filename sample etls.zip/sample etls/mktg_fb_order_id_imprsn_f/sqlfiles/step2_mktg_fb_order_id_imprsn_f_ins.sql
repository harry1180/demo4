INSERT INTO dw_report.mktg_fb_order_id_imprsn_f
(
dw_eff_dt
, ext_customer_id
, actn_type_cd
, ad_id
, adset_id
, attr_type_cd
, campaign_id
, click_cost_am
, click_ts
, conv_dvc_tx
, dvc_nm
, imprsn_cost_am
, imprsn_ts
, order_id
, order_ts
, pixel_id
, plcmt_nm
, dw_load_ts
)
SELECT
 distinct
 impression_timestamp::DATE AS dw_eff_dt
 , account_id::BIGINT AS ext_customer_id
 , action_type  AS actn_type_cd
 , ad_id::BIGINT AS ad_id
 , adset_id::BIGINT AS adset_id
 , attribution_type  AS attr_type_cd
 , campaign_id::BIGINT AS campaign_id
 , click_cost  AS click_cost_am
 , click_timestamp::TIMESTAMP AS click_ts
 , conversion_device  AS conv_dvc_tx
 , device  AS dvc_nm
 , impression_cost  AS imprsn_cost_am
 , impression_timestamp::TIMESTAMP AS imprsn_ts
 , order_id  AS order_id
 , order_timestamp::TIMESTAMP AS order_ts
 , pixel_id  AS pixel_id
 , placement  AS plcmt_nm
 , getdate() AS dw_load_ts
 FROM  dw_stage.mktg_fb_order_id_imprsn_s s
 where not exists (
  select 1
  from dw_report.mktg_fb_order_id_imprsn_f tgt
  where tgt.actn_type_cd = s.action_type
  and tgt.order_id = s.order_id
  and tgt.pixel_id = s.pixel_id
  and tgt.ad_id = s.ad_id
  and tgt.adset_id = s.adset_id
  and coalesce(tgt.imprsn_ts, sysdate) = coalesce(s.impression_timestamp::TIMESTAMP, sysdate)
  and coalesce(tgt.order_ts, sysdate) = coalesce(s.order_timestamp::TIMESTAMP, sysdate)
  and coalesce(tgt.click_ts, sysdate) = coalesce(s.click_timestamp::TIMESTAMP, sysdate)
  and tgt.plcmt_nm = s.placement
 )
;
