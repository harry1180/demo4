
DROP TABLE dw_stage.mktg_fb_order_id_imprsn_s;

CREATE TABLE dw_stage.mktg_fb_order_id_imprsn_s
(
account_id VARCHAR(100) ENCODE lzo
, action_type VARCHAR(100) ENCODE lzo
, ad_id VARCHAR(100) ENCODE lzo
, adset_id VARCHAR(100) ENCODE lzo
, attribution_type VARCHAR(100) ENCODE lzo
, campaign_id VARCHAR(100) ENCODE lzo
, click_cost VARCHAR(100) ENCODE lzo
, click_timestamp VARCHAR(100) ENCODE lzo
, conversion_device VARCHAR(100) ENCODE lzo
, device VARCHAR(100) ENCODE lzo
, impression_cost VARCHAR(100) ENCODE lzo
, impression_timestamp VARCHAR(100) ENCODE lzo
, order_id VARCHAR(100) ENCODE lzo
, order_timestamp VARCHAR(100) ENCODE lzo
, pixel_id VARCHAR(100) ENCODE lzo
, placement VARCHAR(100) ENCODE lzo
)
DISTKEY (ad_id)
SORTKEY (impression_timestamp);

GRANT REFERENCES, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_stage.mktg_fb_order_id_imprsn_s TO group grp_etl;
GRANT TRIGGER, REFERENCES, RULE, UPDATE, INSERT, DELETE, SELECT ON dw_stage.mktg_fb_order_id_imprsn_s TO nw_dwh_etl;
GRANT SELECT ON dw_stage.mktg_fb_order_id_imprsn_s TO group grp_data_users;
