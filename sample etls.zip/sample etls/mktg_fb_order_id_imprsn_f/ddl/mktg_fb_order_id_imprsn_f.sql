CREATE TABLE dw_report.mktg_fb_order_id_imprsn_f
(
dw_eff_dt DATE
, ext_customer_id BIGINT ENCODE lzo
, actn_type_cd VARCHAR(100) ENCODE lzo
, ad_id BIGINT ENCODE lzo
, adset_id BIGINT ENCODE lzo
, attr_type_cd VARCHAR(100) ENCODE lzo
, campaign_id BIGINT ENCODE lzo
, click_cost_am VARCHAR(100) ENCODE lzo
, click_ts TIMESTAMP ENCODE lzo
, conv_dvc_tx VARCHAR(100) ENCODE lzo
, dvc_nm VARCHAR(100) ENCODE lzo
, imprsn_cost_am VARCHAR(100) ENCODE lzo
, imprsn_ts TIMESTAMP ENCODE lzo
, order_id VARCHAR(100) ENCODE lzo
, order_ts TIMESTAMP ENCODE lzo
, pixel_id VARCHAR(100) ENCODE lzo
, plcmt_nm VARCHAR(100) ENCODE lzo
, dw_load_ts TIMESTAMP ENCODE lzo
)
DISTKEY (ad_id)
SORTKEY (dw_eff_dt);

GRANT REFERENCES, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_report.mktg_fb_order_id_imprsn_f TO group grp_etl;
GRANT TRIGGER, REFERENCES, RULE, UPDATE, INSERT, DELETE, SELECT ON dw_report.mktg_fb_order_id_imprsn_f TO nw_dwh_etl;
GRANT SELECT ON dw_report.mktg_fb_order_id_imprsn_f TO group grp_data_users;

