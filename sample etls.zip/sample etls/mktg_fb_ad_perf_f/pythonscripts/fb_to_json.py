#/usr/bin/python
"""Getting Facebook performance data through API call and convert results to json file.

Input file is .json file contains query string, output file name based on the group of attributes,
query string to call Facebook API and input/output directories.
run example:
  python fb_to_json.py -c config.json -i /Users/uname/tmp/ -o /Users/uname/tmp/ -s 2016-08-30
                       -e 2016-08-300 --fb_app_id=xxx --fb_app_secret=xxx --fb_access_token=xxx
"""
import argparse
import json
import os
import sys
import pprint
from datetime import datetime
import time

from facebook_business import FacebookAdsApi
from facebook_business.adobjects.adaccountuser import AdAccountUser 

import fb_modules
from nw_generic_utils_modules import export_to_json_redshift


def valid_date(s):
    try:
        dt = datetime.strptime(s, "%Y-%m-%d")
        return s
    except ValueError:
        msg = "Not a valid date format('yyyy-mm-dd): '{0}'.".format(s)
        raise argparse.ArgumentTypeError(msg)


def main(start_dt, end_dt):
    """Do work"""
    # Get FB API
    api = fb_modules.get_api(
        app_id=fb_app_id,
        app_secret=fb_app_secret,
        access_token=fb_access_token)
    FacebookAdsApi.set_default_api(api)

    # Setup user and read the object from the server
    me = AdAccountUser(fbid='me')

    # Read user permissionsa
    print '>>> Reading permissions field of user:'
    #pp.pprint(me.remote_read(fields=[AdAccountUser.Field.permissions]))

    params = CONFIG['params']

    # Add date range to params
    params['time_range'] = {'since':start_dt, 'until':end_dt}

    # Get all accounts connected to the user
    accounts = fb_modules.get_accounts(
        me, fields=params['acc_fields'])

    fields = params['fields'] + params['breakdowns'] +\
             params['acc_fields']
    data = []
    print '>>> Reading accounts associated with user'
    print '>>> Number of accounts associated with the user :',len(accounts)
    for account in accounts:
        print "Getting Campaign Stats..."
        insights_data = fb_modules.to_dict(
            fb_api_data=fb_modules.get_insights(
                account, params=params),
            fields=fields)

        # ingest account data
        insights_data_ext = []
        for insight_row in insights_data:
            for acc_field in params['acc_fields']:
                insight_row[acc_field] = account[acc_field]
            insights_data_ext.append(insight_row)
        data.extend(insights_data_ext)
        print '>>> Sleeping for 5 min before fetching data for each account'
        time.sleep(300)
    # Create Redshift json file
    export_to_json_redshift(data, os.path.join(
        output_file_dir, CONFIG['dwh_file_name'] + '.json'))


if __name__ == '__main__':
    desc = (
        "Getting Facebook performance data through API call and convert results to json file."
    )
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument(
        '-c',
        '--config_file',
        required=True,
        action='store',
        dest='config_file',
        help='Config json file with "fields":[field1...] and/or "breakdowns":[field1...]')
    parser.add_argument(
        '-i',
        '--input_dir',
        required=True,
        action='store',
        dest='input_dir',
        help='Input directory')
    parser.add_argument(
        '-o',
        '--output_dir',
        required=True,
        action='store',
        dest='output_dir',
        help='Output directory')
    parser.add_argument(
        '-s',
        '--start_date',
        required=True,
        action='store',
        type=valid_date,
        dest='start_date',
        help='Start date in "yyyy-mm-dd" format')
    parser.add_argument(
        '-e',
        '--end_date',
        required=True,
        action='store',
        type=valid_date,
        dest='end_date',
        help='End date in "yyyy-mm-dd" format')
    parser.add_argument(
        '--fb_app_id',
        required=True,
        action='store',
        dest='fb_app_id',
        help='FB App ID')
    parser.add_argument(
        '--fb_app_secret',
        required=True,
        action='store',
        dest='fb_app_secret',
        help='FB App Secret')
    parser.add_argument(
        '--fb_access_token',
        required=True,
        action='store',
        dest='fb_access_token',
        help='FB App Access Token')

    args = parser.parse_args()

    # input file name e.g. config.json
    input_config_file_nm = args.config_file

    # input file location
    input_file_dir = args.input_dir

    # output file location
    output_file_dir = args.output_dir

    # dates
    start_date, end_date = args.start_date, args.end_date
    print "date_range: " + start_date + ',' + end_date

    # get FB credentials
    fb_app_id = args.fb_app_id
    fb_app_secret = args.fb_app_secret
    fb_access_token = args.fb_access_token

    pp = pprint.PrettyPrinter(indent=4)
    this_dir = os.path.dirname(__file__)
    config_filename = os.path.join(this_dir, input_config_file_nm)

    # Read config file
    try:
        with open(config_filename) as config_file:
            CONFIG = json.load(config_file)
    except Exception, e:
        print "Error: can not open config file {}".format(config_filename)
        print str(e)
        sys.exit(1)

    # Do work
    main(start_date, end_date)
