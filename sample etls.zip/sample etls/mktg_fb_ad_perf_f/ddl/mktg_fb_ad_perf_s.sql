
          DROP TABLE "dw_stage"."mktg_fb_ad_perf_s";

          CREATE TABLE "dw_stage"."mktg_fb_ad_perf_s"
          (

             "account_id"    VARCHAR(2000)   ENCODE lzo
,    "account_name"    VARCHAR(2000)   ENCODE lzo
,    "campaign_id"    VARCHAR(2000)   ENCODE lzo
,    "campaign_name"    VARCHAR(2000)   ENCODE lzo
,    "ad_id"    VARCHAR(2000)   ENCODE lzo
,    "ad_name"    VARCHAR(2000)   ENCODE lzo
,    "adset_id"    VARCHAR(2000)   ENCODE lzo
,    "adset_name"    VARCHAR(2000)   ENCODE lzo
,    "clicks"    VARCHAR(2000)   ENCODE lzo
,    "cpm"    VARCHAR(2000)   ENCODE lzo
,    "cpp"    VARCHAR(2000)   ENCODE lzo
,    "ctr"    VARCHAR(2000)   ENCODE lzo
,    "date_start"    VARCHAR(2000)   ENCODE lzo
,    "frequency"    VARCHAR(2000)   ENCODE lzo
,    "impressions"    VARCHAR(2000)   ENCODE lzo
,    "inline_link_clicks"    VARCHAR(2000)   ENCODE lzo
,    "reach"    VARCHAR(2000)   ENCODE lzo
,    "social_clicks"    VARCHAR(2000)   ENCODE lzo
,    "social_impressions"    VARCHAR(2000)   ENCODE lzo
,    "social_reach"    VARCHAR(2000)   ENCODE lzo
,    "spend"    VARCHAR(2000)   ENCODE lzo
,    "total_action_value"    VARCHAR(2000)   ENCODE lzo
,    "total_unique_actions"    VARCHAR(2000)   ENCODE lzo
,    "unique_clicks"    VARCHAR(2000)   ENCODE lzo
,    "unique_ctr"    VARCHAR(2000)   ENCODE lzo
,    "unique_inline_link_clicks"    VARCHAR(2000)   ENCODE lzo
,    "unique_social_clicks"    VARCHAR(2000)   ENCODE lzo
,    "device_platform"    VARCHAR(2000)   ENCODE lzo
,    "currency"    VARCHAR(2000)   ENCODE lzo
,    "timezone_name"    VARCHAR(2000)   ENCODE lzo
          )
          DISTSTYLE KEY
          DISTKEY ("campaign_id")
          SORTKEY (
              "date_start"
              ) ;
          GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON
               dw_stage.mktg_fb_ad_perf_s TO group grp_etl;
          GRANT SELECT ON dw_stage.mktg_fb_ad_perf_s TO group grp_data_users;
          GRANT ALL ON dw_stage.mktg_fb_ad_perf_s to nw_dwh_etl;
          
