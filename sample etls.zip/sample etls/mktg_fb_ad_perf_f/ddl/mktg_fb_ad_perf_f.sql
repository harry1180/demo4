DROP TABLE "dw_report"."mktg_fb_ad_perf_f";

CREATE TABLE "dw_report"."mktg_fb_ad_perf_f"
(
"campaign_domain_id"               VARCHAR(100)    ENCODE LZO
,"campaign_type_id"                VARCHAR(100)    ENCODE LZO
,"vertical_id"                     VARCHAR(100)    ENCODE LZO
,"ext_customer_id"                 BIGINT          ENCODE LZO
,"acct_desc_nm"                    VARCHAR(2000)   ENCODE LZO
,"acct_currency_cd"                VARCHAR(1000)   ENCODE LZO
,"acct_tz_nm"                      VARCHAR(1000)   ENCODE LZO
,"campaign_id"                     BIGINT          ENCODE LZO
,"campaign_nm"                     VARCHAR(2000)   ENCODE LZO
,"adset_id"                        BIGINT          ENCODE LZO
,"adset_nm"                        VARCHAR(2000)   ENCODE LZO
,"ad_id"                           BIGINT          ENCODE LZO
,"ad_nm"                           VARCHAR(2000)   ENCODE LZO
,"dvc_type_cd"                     VARCHAR(100)    ENCODE LZO
,"clicks_ct"                       BIGINT          ENCODE LZO
,"cpm"                             NUMERIC(23,13)  ENCODE LZO
,"cpp"                             NUMERIC(23,13)  ENCODE LZO
,"ctr"                             NUMERIC(23,13)  ENCODE LZO
,"dw_eff_dt"                       DATE            ENCODE LZO
,"ad_serv_freq"                    NUMERIC(23,13)  ENCODE LZO
,"imprsn_ct"                       BIGINT          ENCODE LZO
,"inline_link_clicks_ct"           BIGINT          ENCODE LZO
,"reach_ct"                        BIGINT          ENCODE LZO
,"social_clicks_ct"                BIGINT          ENCODE LZO
,"social_imprsn_ct"                BIGINT          ENCODE LZO
,"social_reach_ct"                 BIGINT          ENCODE LZO
,"spend_am"                        NUMERIC(23,2)   ENCODE LZO
,"total_actn_val_am"               NUMERIC(23,13)  ENCODE LZO
,"total_unique_actns_ct"           BIGINT          ENCODE LZO
,"unique_clicks_ct"                BIGINT          ENCODE LZO
,"unique_ctr"                      NUMERIC(23,13)  ENCODE LZO
,"unique_inline_link_clicks_ct"    BIGINT          ENCODE LZO
,"unique_social_clicks_ct"         BIGINT          ENCODE LZO
,"src_sys_id"                      INTEGER         ENCODE LZO
,"dw_ad_perf_sk"                   BIGINT          ENCODE LZO
,"dw_load_ts"                      TIMESTAMP       ENCODE LZO
)
DISTKEY ("campaign_id")
SORTKEY (   "dw_eff_dt" ) ;
    GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_report.mktg_fb_ad_perf_f TO group grp_etl;
    GRANT SELECT ON dw_report.mktg_fb_ad_perf_f TO group grp_data_users;
    GRANT ALL ON dw_report.mktg_fb_ad_perf_f TO nw_dwh_etl;
