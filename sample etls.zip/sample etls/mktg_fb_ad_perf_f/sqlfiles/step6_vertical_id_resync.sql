UPDATE
  dw_report.mktg_fb_ad_perf_f
SET vertical_id = v.vertical_id
FROM
  dw_report.mktg_vertical_d v
WHERE
  dw_report.mktg_fb_ad_perf_f.vertical_id IS NULL AND
SPLIT_PART(dw_report.mktg_fb_ad_perf_f.adset_nm, '_', 1) = SPLIT_PART(v.vertical_short_nm, '_', 1);
