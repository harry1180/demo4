delete from dw_report.mktg_fb_ad_perf_f
where
dw_eff_dt > current_date - 7 ;

