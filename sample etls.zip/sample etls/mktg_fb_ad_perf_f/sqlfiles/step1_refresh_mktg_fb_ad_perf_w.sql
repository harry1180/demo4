DELETE FROM dw_stage.mktg_fb_ad_perf_w ;

INSERT INTO dw_stage.mktg_fb_ad_perf_w
SELECT
dom.campaign_domain_id AS campaign_domain_id
,camp_type.campaign_type_id AS campaign_type_id
,v.vertical_id AS  vertical_id
,s.account_id::BIGINT AS ext_customer_id
,s.account_name	AS acct_desc_nm
,s.currency AS acct_currency_cd
,s.timezone_name AS acct_tz_nm
,s.campaign_id::BIGINT	AS campaign_id
,s.campaign_name	AS campaign_nm
,s.adset_id::BIGINT	AS adset_id
,s.adset_name	AS adset_nm
,s.ad_id::BIGINT	AS ad_id
,s.ad_name	AS ad_nm
,s.device_platform AS dvc_type_cd
,s.clicks::BIGINT	AS clicks_ct
,s.cpm::NUMERIC(23,13)	AS cpm
,s.cpp::NUMERIC(23,13)	AS cpp
,s.ctr::NUMERIC(23,13)	AS ctr
,s.date_start::DATE	AS dw_eff_dt
,s.frequency::NUMERIC(23,13)		AS ad_serv_freq
,s.impressions::BIGINT	AS imprsn_ct
,s.inline_link_clicks::BIGINT	AS inline_link_clicks_ct
,s.reach::BIGINT	AS reach_ct
,s.social_clicks::BIGINT	AS social_clicks_ct
,s.social_impressions::BIGINT	AS social_imprsn_ct
,s.social_reach::BIGINT	AS social_reach_ct
,s.spend::NUMERIC(23,2)	AS spend_am
,s.total_action_value::NUMERIC(23,13)	AS total_actn_value_am
,s.total_unique_actions::BIGINT	AS total_unique_actns_ct
,s.unique_clicks::BIGINT	AS unique_clicks_ct
,s.unique_ctr::NUMERIC(23,13)	 AS unique_ctr
,s.unique_inline_link_clicks::BIGINT	AS unique_inline_link_clicks_ct
,s.unique_social_clicks::BIGINT	AS unique_social_clicks_ct
,COALESCE(xref.src_sys_id,-1)  AS  src_sys_id
,-1		AS dw_ad_perf_sk
,getdate() dw_load_ts

FROM
dw_stage.mktg_fb_ad_perf_s s
LEFT JOIN dw_report.mktg_src_sys_campaign_domain_xref xref ON s.account_id::VARCHAR(100)=xref.campaign_domain_ext_acct_id AND xref.referrer_nm = 'facebook'
LEFT JOIN dw_report.mktg_vertical_d v ON SPLIT_PART(s.adset_name,'_',1) = SPLIT_PART(v.vertical_short_nm,'_',1)
LEFT JOIN dw_report.mktg_campaign_domain_d dom ON dom.referrer_nm = 'facebook'
LEFT JOIN dw_report.mktg_campaign_type_d camp_type on camp_type.campaign_domain_id = dom.campaign_domain_id and 'native' =   lower(camp_type.campaign_type_nm)
;

