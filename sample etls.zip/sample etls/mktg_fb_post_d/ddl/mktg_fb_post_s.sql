drop table dw_stage.mktg_fb_post_s;
create table dw_stage.mktg_fb_post_s
(
"id" varchar(250) encode lzo,
"application_name" varchar(500) encode lzo,
"application_link" varchar(500) encode lzo,
"application_id" varchar(500) encode lzo,
"caption" varchar(500) encode lzo,
"created_time" timestamp,
"description" varchar(2500) encode lzo,
"page_name" varchar(100) encode lzo,
"page_id" varchar(100) encode lzo,
"instagram_eligibility" varchar(100) encode lzo,
"is_hidden" boolean,
"is_instagram_eligible" boolean,
"is_published" boolean,
"link" varchar(2500) encode lzo,
"message" varchar(2500) encode lzo,
"name" varchar(2500) encode lzo,
"object_id" varchar(500) encode lzo,
"parent_id" varchar(500) encode lzo,
"permalink_url" varchar(500) encode lzo,
"place" varchar(100) encode lzo,
"promotable_id" varchar(500) encode lzo,
"promotion_status" varchar(100) encode lzo,
"video_length" varchar(10) encode lzo,
"source" varchar(2500) encode lzo,
"status_type" varchar(100) encode lzo,
"type" varchar(100) encode lzo,
"updated_time" timestamp
);

GRANT REFERENCES, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_stage.mktg_fb_post_s TO group grp_etl;
GRANT TRIGGER, REFERENCES, RULE, UPDATE, INSERT, DELETE, SELECT ON dw_stage.mktg_fb_post_s TO nw_dwh_etl;
GRANT SELECT ON dw_stage.mktg_fb_post_s TO group grp_data_users;
