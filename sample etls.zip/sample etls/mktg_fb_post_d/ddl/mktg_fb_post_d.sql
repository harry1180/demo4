DROP TABLE dw_report.mktg_fb_post_d;
CREATE TABLE dw_report.mktg_fb_post_d
(
  "id" varchar(250) encode lzo,
  "dw_eff_dt" date,
  "app_nm" varchar(500) encode lzo,
  "app_lnk" varchar(500) encode lzo,
  "app_id" varchar(500) encode lzo,
  "caption_nm" varchar(500) encode lzo,
  "created_ts" timestamp,
  "desc" varchar(2500) encode lzo,
  "pg_nm" varchar(100) encode lzo,
  "pg_id" varchar(100) encode lzo,
  "is_instagram" varchar(100) encode lzo,
  "is_hidden" boolean,
  "is_instagram_eligible" boolean,
  "is_pub" boolean,
  "link" varchar(2500) encode lzo,
  "utm_campaign_id" varchar(500) encode lzo,
  "message" varchar(2500) encode lzo,
  "name_tx" varchar(2500) encode lzo,
  "obj_id" varchar(500) encode lzo,
  "parent_id" varchar(500) encode lzo,
  "permlnk_url" varchar(500) encode lzo,
  "place_tx" varchar(100) encode lzo,
  "promo_id" varchar(500) encode lzo,
  "promo_status" varchar(100) encode lzo,
  "video_len" varchar(10) encode lzo,
  "source_tx" varchar(2500) encode lzo,
  "status_type_cd" varchar(100) encode lzo,
  "type_tx" varchar(100) encode lzo,
  "last_updt_ts" timestamp,
  "dw_load_ts" timestamp
)
DISTKEY (id)
SORTKEY (dw_eff_dt);

GRANT REFERENCES, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_report.mktg_fb_post_d TO group grp_etl;
GRANT TRIGGER, REFERENCES, RULE, UPDATE, INSERT, DELETE, SELECT ON dw_report.mktg_fb_post_d TO nw_dwh_etl;
GRANT SELECT ON dw_report.mktg_fb_post_d TO group grp_data_users;
