DELETE FROM dw_report.mktg_fb_post_d WHERE id in (SELECT id from dw_stage.mktg_fb_post_s);
