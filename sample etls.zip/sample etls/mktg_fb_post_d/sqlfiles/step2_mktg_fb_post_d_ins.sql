INSERT INTO dw_report.mktg_fb_post_d
(
  id
, dw_eff_dt
, app_nm
, app_lnk
, app_id
, caption_nm
, created_time
, "desc"
, pg_nm
, pg_id
, is_instagram
, is_hidden
, is_instagram_eligible
, is_published
, link
, utm_campaign_id
, message
, name_tx
, obj_id
, parent_id
, permlnk_url
, place_tx
, promo_id
, promo_status
, video_len
, source_tx
, status_type_cd
, type_tx
, last_updt_time
, dw_load_ts
)
  SELECT
  distinct
  id,
  trunc(sysdate),
  application_name,
  application_link,
  application_id,
  caption,
  created_time,
  description,
  page_name,
  page_id,
  instagram_eligibility,
  is_hidden,
  is_instagram_eligible,
  is_published,
  link,
  split_part(split_part(link,'?utm_campaign=',2),'&',1),
  message,
  name,
  object_id,
  parent_id,
  permalink_url,
  place,
  promotable_id,
  promotion_status,
  video_length,
  source,
  status_type,
  type,
  updated_time,
  getdate()
FROM dw_stage.mktg_fb_post_s;
