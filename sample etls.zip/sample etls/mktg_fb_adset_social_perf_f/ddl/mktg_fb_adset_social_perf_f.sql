DROP TABLE dw_report.mktg_fb_adset_social_perf_f;
CREATE TABLE "dw_report"."mktg_fb_adset_social_perf_f"
(

     "acct_id"    VARCHAR(500)   ENCODE lzo
,    "acct_nm"    VARCHAR(500)   ENCODE lzo
,    "campaign_id"    VARCHAR(500)   ENCODE lzo
,    "campaign_nm"    VARCHAR(500)   ENCODE lzo
,    "campaign_domain_id" VARCHAR(100) ENCODE lzo
,    "campaign_type_id" VARCHAR(100) ENCODE lzo
,    "vertical_id" VARCHAR(50) ENCODE lzo
,    "adset_id"    VARCHAR(100)   ENCODE lzo
,    "adset_nm"    VARCHAR(100)   ENCODE lzo
,    "click_ct"    INTEGER   ENCODE lzo
,    "cpm"    DECIMAL(10,3)    ENCODE lzo
,    "cpp"    DECIMAL(10,3)    ENCODE lzo
,    "ctr"    DECIMAL(10,3)    ENCODE lzo
,    "dw_eff_dt"    DATE   ENCODE lzo
,    "freq_ct"    DECIMAL(10,3)    ENCODE lzo
,    "imprsn_ct"    INTEGER   ENCODE lzo
,    "inline_link_click_ct"    INTEGER   ENCODE lzo
,    "reach_ct"    INTEGER   ENCODE lzo
,    "social_click_ct"    INTEGER   ENCODE lzo
,    "social_imprsn_ct"    INTEGER   ENCODE lzo
,    "social_reach_ct"    INTEGER   ENCODE lzo
,    "spend_am"    DECIMAL(10,3)   ENCODE lzo
,    "src_sys_id"  VARCHAR(50)   ENCODE lzo
,    "total_actn_val_am"    DECIMAL(10,3)    ENCODE lzo
,    "total_unique_actn_ct"    INTEGER   ENCODE lzo
,    "unique_click_ct"    INTEGER   ENCODE lzo
,    "unique_ctr"    DECIMAL(10,3)    ENCODE lzo
,    "unique_inline_link_click_ct"   INTEGER   ENCODE lzo
,    "unique_social_click_ct"    INTEGER   ENCODE lzo
,    "dev_type_cd"    VARCHAR(100)   ENCODE lzo
,    "comment_ct"   INTEGER   ENCODE lzo
,    "share_ct"   INTEGER   ENCODE lzo
,    "post_like_ct"    INTEGER   ENCODE lzo
,    "post_love_ct"    INTEGER   ENCODE lzo
,    "post_sad_ct"    INTEGER   ENCODE lzo
,    "post_wow_ct"    INTEGER   ENCODE lzo
,    "post_haha_ct"    INTEGER   ENCODE lzo
,    "post_sorry_ct"    INTEGER   ENCODE lzo
,    "post_anger_ct"    INTEGER   ENCODE lzo
,    "page_egmt_ct"    INTEGER   ENCODE lzo
,    "post_egmt_ct"    INTEGER   ENCODE lzo
,    "video_view_ct"    INTEGER   ENCODE lzo
,    "video_10_sec_view_ct"    INTEGER   ENCODE lzo
,    "video_15_sec_view_ct"    INTEGER   ENCODE lzo
,    "video_30_sec_view_ct"    INTEGER   ENCODE lzo
,    "acct_curr_cd"    VARCHAR(50)   ENCODE lzo
,    "acct_tz_nm"    VARCHAR(50)   ENCODE lzo
,    "dw_load_ts" TIMESTAMP
)
DISTSTYLE KEY
DISTKEY ("campaign_id")
SORTKEY (
    "dw_eff_dt"
    ) ;

GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON "dw_report"."mktg_fb_adset_social_perf_f" TO group grp_etl;
GRANT SELECT ON "dw_report"."mktg_fb_adset_social_perf_f" TO group grp_data_users;
GRANT ALL ON "dw_report"."mktg_fb_adset_social_perf_f" to nw_dwh_etl;