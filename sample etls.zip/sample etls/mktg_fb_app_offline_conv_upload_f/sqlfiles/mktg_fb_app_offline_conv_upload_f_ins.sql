insert into  dw_report.mktg_fb_app_offline_conv_upload_f

select
sv.site_uv_id site_uv_id
,c.dw_src_sys_id dw_src_sys_id
,c.dw_eff_dt dw_eff_dt
,c.src_prod_id src_prod_id
,c.page_path_tx page_path_tx
from dw_views.dw_clicks_enriched c
left join dw_views.dw_aflt_tran_enriched af
on c.dw_click_id = af.dw_click_id
left join dw_report.site_visitor_d sv
on c.dw_site_visitor_id = sv.dw_site_visitor_id
where c.dw_eff_dt = 'load_dt'
and c.dw_src_sys_id = 1
and af.dw_click_id is NULL
and not exists
        (
          select 1 from dw_report.mktg_fb_app_offline_conv_upload_f tgt
          where sv.site_uv_id = tgt.site_uv_id
          and c.dw_eff_dt = tgt.dw_eff_dt
          and c.src_prod_id = tgt.src_prod_id
          and c.page_path_tx = tgt.page_path_tx
        )
;
