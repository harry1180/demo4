drop table if exists dw_report.mktg_fb_app_offline_conv_upload_f;
create table dw_report.mktg_fb_app_offline_conv_upload_f
(
 site_uv_id varchar(45) encode lzo
,dw_src_sys_id SMALLINT encode lzo
,dw_eff_dt date encode lzo
,src_prod_id varchar(1000) encode lzo
,page_path_tx varchar(3000) encode lzo
)
distkey(site_uv_id) sortkey(dw_eff_dt)
;

GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_report.mktg_fb_app_offline_conv_upload_f TO group grp_etl;
GRANT SELECT ON dw_report.mktg_fb_app_offline_conv_upload_f TO group grp_data_users;
GRANT ALL ON dw_report.mktg_fb_app_offline_conv_upload_f TO nw_dwh_etl;
