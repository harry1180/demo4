import sys

import json
from redshift_modules import exec_query, load_creds

import hashlib
import datetime
from facebookads import FacebookSession
from facebookads import FacebookAdsApi
import pandas as pd
from IPython.display import display
from fb_graph_api import GraphAPI as fb_graph_api
# Need to create offline event set only once as part of setup.
# Create OFFLINE_EVENT_SET_ID
# Need app_id, app_secret and access_token
#
# session = FacebookSession(
#         app_id=app_id, app_secret=app_secret, access_token=access_token)
# api = FacebookAdsApi(session)
# api.set_default_api(api)
# params = {
#    'name': 'dwh_cc_propensity_to_transact',
#    'description': 'test'
# }
# url = "https://graph.facebook.com/v3.0/10153528399908502/offline_conversion_data_sets"
# call = api.call('post', url, params=params)
# print call.__dict__
# OFFLINE_CONVERSION_DATA_SET_ID = '1761457463867001'
OFFLINE_CONVERSION_DATA_SET_ID = '1761457463867001'

print "Fetching credentials from chef passwords file"
dwh_chef_credentials_file = str(sys.argv[1])

chef_creds = load_creds(dwh_chef_credentials_file)
fb_app_id = chef_creds['fb_app_id'].replace("'", "")
fb_app_secret = chef_creds['fb_app_secret'].replace("'", "")
fb_access_token = chef_creds['fb_access_token'].replace("'", "")
fb_pixel_id="612184065591075"

EVENT_NAME = "Other"

sql_qry = """
select
site_uv_id
, date_part(epoch, upload_dt) event_time
, propensity_cd
from dw_report.mktg_fb_propensity_offline_upload_f
where propensity_cd != 'mid'
and upload_dt = trunc(CURRENT_DATE)
;
"""
sql_output_dict = exec_query(sql_qry)
print "Row count from dw_report.mktg_fb_propensity_offline_upload_f :" + str(len(sql_output_dict))

session = FacebookSession(app_id=fb_app_id, app_secret=fb_app_secret, access_token=fb_access_token)

api = FacebookAdsApi(session)
api.set_default_api(api)
print "FB API session initiated"


def upload_uvs_to_fb(sql_output_dict):
    total_counter = 0
    success_counter = 0
    exception_counter = 0

    for uv in sql_output_dict:

        hash_object = hashlib.sha256(uv['site_uv_id'])
        hex_dig = hash_object.hexdigest()

        data = [
            {
                'match_keys': {"extern_id": str(hex_dig)},
                'event_name': EVENT_NAME,
                'event_time': int(float(str(uv['event_time']))),
                'custom_data': {
                    'propensity': str(uv['propensity_cd'])
                }
            }
        ]
        #print data
        params = {
            'upload_tag': 'DWH_Upload_' + EVENT_NAME + str(datetime.datetime.today().strftime('%Y-%m-%d')),
            'data': data,
            'namespace_id': fb_pixel_id
        }

        try:
            url = fb_graph_api.base_url+"{}/events".format(OFFLINE_CONVERSION_DATA_SET_ID)
            call = api.call('post', url, params=params)
            success_counter += 1
        except Exception, e:
            exception_counter += 1
            print e
        # Server to Server call made in BETA version
        # fb_url='https://www.facebook.com/tr/?id='+str(FB_PIXEL_ID)+'&ev='+str(EVENT_NAME)+'&ud[external_id]='+str(hex_dig)+'&cd[src_sys_id]='+str(uv['src_sys_id'])+'&cd[value]='+str(uv['value'])+'&cd[src_prod_id]='+str(uv['src_prod_id'])+'&cd[conf_page_path_tx]='+str(uv['conf_page_path_tx'])+'&cd[currency]=USD'

        total_counter += 1

    print "Done"
    print "EVENT_NAME :", EVENT_NAME
    print "total_counter :", total_counter
    print "success_counter :", success_counter
    print "exception_counter :", exception_counter

    print "upload stats"
    url = fb_graph_api.base_url+"{}/uploads".format(OFFLINE_CONVERSION_DATA_SET_ID)
    call = api.call('get', url)
    print (call.__dict__).keys()
    data_dict = json.loads(call.__dict__['_body'])
    df = pd.DataFrame(data_dict['data'])
    display(df)


print "FB Offline upload started..."
upload_uvs_to_fb(sql_output_dict)
print "FB Offline upload completed..."
