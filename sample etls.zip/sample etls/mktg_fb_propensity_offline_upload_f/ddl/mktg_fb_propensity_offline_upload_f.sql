DROP TABLE IF EXISTS dw_report.mktg_fb_propensity_offline_upload_f ;
create table dw_report.mktg_fb_propensity_offline_upload_f
(
  site_uv_id    varchar(45)
  , upload_dt  Date
  , propensity_cd varchar(100)
  , prob_to_transact_scr numeric(38,10)
  , dw_load_ts timestamp
)
distkey(site_uv_id)
sortkey(upload_dt) ;
GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_report.mktg_fb_propensity_offline_upload_f TO group grp_etl;
GRANT SELECT ON dw_report.mktg_fb_propensity_offline_upload_f TO group grp_data_users;
GRANT ALL ON dw_report.mktg_fb_propensity_offline_upload_f TO nw_dwh_etl;