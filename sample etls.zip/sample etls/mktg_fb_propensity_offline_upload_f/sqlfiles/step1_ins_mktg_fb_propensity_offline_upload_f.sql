delete from dw_report.mktg_fb_propensity_offline_upload_f
where upload_dt = trunc(current_date);

insert into dw_report.mktg_fb_propensity_offline_upload_f
(
site_uv_id
, upload_dt
, propensity_cd
, prob_to_transact_scr
, dw_load_ts
)
select d.site_uv_id
, trunc(current_date) as upload_dt
, case when prob_to_transact < .10 then 'low'
 when prob_to_transact >= .92 then 'high' else 'mid' end as propensity
, prob_to_transact
, sysdate
from dw_ba_report.cc_prop_to_transact_values_bt s
left join dw_report.site_visitor_d d
  on s.dw_site_visitor_id = d.dw_site_visitor_id
where 
s.prob_to_transact >=.92
and s.dw_site_visitor_id not in (
  select distinct coalesce(dw_site_visitor_id, -999999999)
  from dw_aflt_tran_enriched where src_sys_id = 1
 and dw_eff_dt between 'from_date' and 'to_date')
-- and dw_eff_dt between current_date-31 and current_date-1 )
-- and NOT EXISTS
-- (select 1 from dw_report.mktg_fb_propensity_offline_upload_f tgt
--  where tgt.site_uv_id = d.site_uv_id
--   and tgt.propensity_cd = (case when prob_to_transact < .10 then 'low' when prob_to_transact >= .92 then 'high' else 'mid' end)
-- )
-- Justin asked to change logic, upload ALL users including existing ones for last 30 days.
;

