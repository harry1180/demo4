job_name='mktg_email_remktg_upload_f'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
stage_db="dw_stage"
target_db='dw_report'
stg_tbl_nm='mktg_goog_email_remktg_s'

echo "if user_date_range is empty then default is from yesterday data"
if [ -z $1 ] ; then
  date_load_from="$(date -d '-6 days' '+%Y-%m-%d')"
else
  date_load_from="$1"
fi

if [ -z $2 ] ; then
  date_load_to="$(date -d '1 days' +'%Y-%m-%d')"
else
  date_load_to="$2"
fi

echo 'config_file_name       :-   '${config_file_name}
echo 'date_load_from:        :-   '${date_load_from}
echo 'date_load_to:          :-   '${date_load_to}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

trap 'abort' 0
set -e

echo "Delete records from stage table dw_stage.mktg_goog_email_remktg_s started"
query_stage_delete="delete from "$stage_db"."$stg_tbl_nm" ;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo "Delete records from stage table dw_stage.mktg_goog_email_remktg_s finish"

#generate redshift param file
echo_processing_step ${job_name} "generate redshift param file" "notify"
echo "{
\"from_date\":\"${date_load_from}\",
\"to_date\":\"${date_load_to}\"
}" > ${Linux_Output}/${job_name}_redshift_params.json

echo "ins_email_remkg_banking_non_click_cd_daily.sql
ins_email_remkg_banking_non_click_checking_daily.sql
ins_email_remkg_banking_non_click_saving_daily.sql
ins_email_remkg_banking_trans_cd_daily.sql
ins_email_remkg_banking_trans_checking_daily.sql
ins_email_remkg_banking_trans_saving_daily.sql
ins_email_remkg_cc_bt_trans_liveramp_daily_q118.sql
ins_email_remkg_cc_bt_trans_nullcs_liveramp_daily_q118.sql
ins_email_remkg_cc_travel_trans_liveramp_daily_q118.sql
ins_email_remkg_cc_lowinterest_liveramp_daily.sql
ins_email_remkg_cc_rewards_liveramp_daily.sql
ins_email_remkg_cc_upgrade_liveramp_daily.sql
ins_email_remkg_cc_rewardsv2_liveramp_daily.sql
ins_email_remkg_cc_travel_liveramp_daily.sql
ins_email_remkg_investing_click_not_trans_broker_daily.sql
ins_email_remkg_investing_click_not_trans_ira_daily.sql
ins_email_remkg_investing_click_not_trans_robo_advisor_daily.sql
ins_email_remkg_investing_click_not_trans_roth_ira_daily.sql
ins_email_remkg_investing_not_click_broker_daily.sql
ins_email_remkg_investing_not_click_ira_daily.sql
ins_email_remkg_investing_not_click_robo_advisor_daily.sql
ins_email_remkg_investing_not_click_roth_ira_daily.sql
ins_email_remkg_investing_trans_broker_daily.sql
ins_email_remkg_investing_trans_ira_daily.sql
ins_email_remkg_investing_trans_robo_advisor_daily.sql
ins_email_remkg_investing_trans_roth_ira_daily.sql
ins_email_remkg_membership_daily.sql
ins_email_remkg_membership_fico_high_daily.sql
ins_email_remkg_membership_fico_low_daily.sql
ins_email_remkg_membership_fico_med_daily.sql
ins_email_remkg_pl_daily.sql
ins_email_remkg_investing_advisory_not_sign_daily.sql
ins_email_remkg_investing_advisory_sign_not_onboard_daily.sql
ins_email_remkg_membership_more_30_days_daily.sql
ins_email_remkg_membership_bank_account_daily.sql
ins_email_remkg_membership_cc_quiz_daily.sql
ins_email_remkg_membership_cc_tool_daily.sql
ins_email_remkg_membership_cc_trans_outbound_click_daily.sql
ins_email_remkg_membership_30_days_daily.sql
ins_email_remkg_cc_transactors_liveramp_daily.sql
ins_email_remkg_cc_bt720_pay2000_daily_q218.sql
ins_email_remkg_cc_bt720_pay2000_liveramp_daily_q218.sql
ins_email_remkg_cc_bt770_pay2750_liveramp_daily_q218.sql
ins_email_remkg_cc_brand_travel_cmpgn_q218.sql
ins_mktg_goog_email_remktg_f.sql" | while read sql_script other_var
do
  echo_processing_step ${job_name} "$sql_script" "Started"
  bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/${sql_script} ${Linux_Output}/${job_name}_redshift_params.json
  echo_processing_step ${job_name} "$sql_script" "Completed"
done

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
