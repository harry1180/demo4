DROP TABLE dw_stage.mktg_goog_email_remktg_s;

CREATE TABLE dw_stage.mktg_goog_email_remktg_s
(
    adnc_id VARCHAR(10) ENCODE LZO,
    adnc_nm VARCHAR(100) ENCODE LZO,
    ext_acct_id VARCHAR(100) ENCODE LZO,
    src_sys_id VARCHAR(10) ENCODE LZO,
    dw_site_visitor_id VARCHAR(1000) ENCODE LZO,
    user_id VARCHAR(1000) ENCODE LZO,
    email_hs VARCHAR(1000) ENCODE LZO,
    pfm_tx VARCHAR(50) ENCODE LZO
)DISTKEY(user_id)
SORTKEY(dw_site_visitor_id);

GRANT REFERENCES, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_stage.mktg_goog_email_remktg_s TO group grp_etl;
GRANT TRIGGER, REFERENCES, RULE, UPDATE, INSERT, DELETE, SELECT ON dw_stage.mktg_goog_email_remktg_s TO nw_dwh_etl;
GRANT SELECT ON dw_stage.mktg_goog_email_remktg_s TO group grp_data_users;