DROP TABLE IF EXISTS "dw_report"."mktg_goog_remktg_adnc_d" ;

CREATE TABLE dw_report.mktg_goog_remktg_adnc_d(
  adnc_id VARCHAR(10) ENCODE LZO,
  adnc_nm VARCHAR(100) ENCODE LZO,
  acct_id VARCHAR(100) ENCODE LZO,
  desc VARCHAR(2500) ENCODE LZO,
  criteria VARCHAR(8000) ENCODE LZO,
  reqstr  VARCHAR(100) ENCODE LZO,
  jira  VARCHAR(100) ENCODE LZO,
  reqdate VARCHAR(100) ENCODE LZO,
  src_sys_id VARCHAR(10) ENCODE LZO,
  pltfm VARCHAR(50) ENCODE LZO
);

GRANT REFERENCES, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_report.mktg_goog_remktg_adnc_d TO group grp_etl;
GRANT TRIGGER, REFERENCES, RULE, UPDATE, INSERT, DELETE, SELECT ON dw_report.mktg_goog_remktg_adnc_d TO nw_dwh_etl;
GRANT SELECT ON dw_report.mktg_goog_remktg_adnc_d TO group grp_data_users;
