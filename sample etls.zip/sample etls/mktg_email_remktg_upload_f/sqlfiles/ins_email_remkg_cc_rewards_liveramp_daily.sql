INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx
)
SELECT
    '103' AS adnc_id
    , 'email_remkg_cc_rewards_liveramp_daily' AS adnc_nm
    , c.dw_site_visitor_id :: VARCHAR(1000)
    , c.user_id
    , e.sha256_email_hs
    , '24' AS src_sys_id
    , 'undefined' AS ext_account_id
    , 'liveramp' AS pfm_tx
  FROM dw_views.dw_aflt_tran_enriched a
    LEFT OUTER JOIN dw_views.dw_creditcard_catg b
      ON (a.dw_site_prod_sk = b.dw_site_prod_sk
          AND b.curr_in = 1
          AND b.reporting_category_nm IN ('Cash Back',
                                          'Balance Transfer',
                                          'Travel',
                                          'Airline',
                                          'Rewards',
                                          'Zero Percent'))
    LEFT OUTER JOIN dw_report.dw_identity_site_visitor_xref_d c
      ON (a.dw_site_visitor_id = c.dw_site_visitor_id)
    LEFT OUTER JOIN dw_pud_report.dw_identity_glb_profile_d d
      ON (d.user_id = c.user_id
          AND d.subscr_email_enbl_in = 'true'
          AND d.curr_in = 1)
    LEFT OUTER JOIN dw_pud_report.dw_identity_d e
      ON (d.user_id = e.user_id
          AND d.curr_in = 1)
  WHERE a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
        AND lower(a.page_hier_lvl1_nm) = 'credit cards'
        AND a.dw_suspected_bot_in = 'False'
        AND a.dw_site_visitor_id IS NOT NULL
        AND c.user_id IS NOT NULL
        AND e.sha256_email_hs IS NOT NULL
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8
;
