  INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx
)
  select
    '105' AS adnc_id
      , 'email_remkg_cc_rewardsv2_liveramp_daily' AS adnc_nm
      , a.dw_site_visitor_id :: VARCHAR(1000)
      , b.user_id
      , c.md5_email_hs
      , '24' AS src_sys_id
      , 'undefined' AS ext_account_id
      , 'liveramp' AS pfm_tx
  from dw_views.dw_aflt_tran_enriched a
  join dw_report.dw_identity_site_visitor_xref_d b
  on a.dw_site_visitor_id = b.dw_site_visitor_id
  join dw_pud_report.dw_identity_d c
  on a.user_id = c.user_id
  and c.curr_in = 1
  join(select user_id
  , vantage_cr_scr_v3_rng_start_nr
  from dw_pud_views.dw_user_snap_v
  where nw_acct_status_cd = 'ACTIVE'
  and tu_acct_status_cd = 'ACTIVE'
  and dw_suspected_bot_in = 'false'
  and vantage_cr_scr_v3_rng_start_nr >= 700
  ) d
  on b.user_id = d.user_id
  where  a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
  and a.prod_seo_nm in ('Capital One Venture','Chase Sapphire Preferred'
  , 'Discover it', 'Chase Freedom' || CHR(174)
  , 'Citi Double Cash Card')
;
