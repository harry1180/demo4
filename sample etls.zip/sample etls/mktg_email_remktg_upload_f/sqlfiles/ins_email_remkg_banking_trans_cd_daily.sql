INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx
)
SELECT
DISTINCT
'1123' AS adnc_id
, 'email_remkg_banking_trans_cd_daily' AS adnc_nm
, d.dw_site_visitor_id :: VARCHAR(1000)
, e.user_id
, e.sha256_email_hs
, '-1' AS src_sys_id
, '416-486-4694'
, 'google' AS pfm_tx
FROM dw_views.dw_clicks_enriched b
JOIN dw_report.dw_prod_d c
ON b.src_prod_id = c.src_prod_id
AND c.curr_in = 1
AND c.del_in = 0
AND b.is_sponsored_in = 1
AND b.click_utc_ts BETWEEN 'from_date' AND 'to_date'
AND c.dw_src_sys_id = 8
JOIN dw_report.dw_identity_site_visitor_xref_d d
ON b.dw_site_visitor_id = d.dw_site_visitor_id
JOIN dw_pud_report.dw_identity_d e
ON d.user_id = e.user_id
AND e.curr_in = 1
WHERE c.fin_prod_fmly_nm IN ('CD')
;
