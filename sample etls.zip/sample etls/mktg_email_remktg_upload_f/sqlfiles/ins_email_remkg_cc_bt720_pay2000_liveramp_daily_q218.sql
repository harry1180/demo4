--CC BT Transactors with credit score under 720 and monthly payment under 2000
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx)
select '128' as adnc_id
       , 'email_remkg_cc_bt720_pay2000_liveramp_daily_q218' as adnc_nm
       , a.dw_site_visitor_id :: VARCHAR(1000)
       , b.user_id
       , c.sha256_email_hs
       , '-1' AS src_sys_id
       , null as ext_acct_id
       , 'liveramp' AS pfm_tx
from dw_views.dw_aflt_tran_enriched a
     join dw_report.dw_identity_site_visitor_xref_d b
on  a.dw_site_visitor_id = b.dw_site_visitor_id
     join dw_pud_views.dw_identity_d c
on b.user_id = c.user_id
and c.curr_in = 1
     join dw_pud_views.dw_identity_tu_credit_rprt_profile_d d
on b.user_id = d.user_id
and d.curr_in = 1
and d.vantage_cr_scr_3_bkt_nm not in ('EXCELLENT_720_850','UNKNOWN')
     join(
          select user_id
              from(
                  select a.user_id
                    , count(a.tu_trdln_id)
                    , count(distinct a.tu_trdln_id)
                    , count(a.acct_subtype_desc_tx)
                    , sum(cur_bal_am) as tot_bal_am
                    , sum(credit_limit_am) as tot_crdt_lim_am
                    , sum(mly_pmt) as tot_mly_pmt
                    , case when sum(credit_limit_am) > 0 then sum(cur_bal_am)/sum(credit_limit_am) else null end as utilization
                  from dw_pud_views.dw_identity_tu_trdln_snap_f a
                    left outer join dw_pud_views.trdln_accnt_sub_type_map b
                  on a.acct_subtype_desc_tx = b.acct_subtype_desc_tx
                  where a.trdln_clsd_ts is null
                  and a.curr_in = 1 
                  and a.del_in = 0
                  and b.category = 'Credit Cards'
                  and a.acct_dsgntr_desc_tx <> 'Authorized User'
                  group by 1)a
          where tot_mly_pmt < 2000) e
on b.user_id = e.user_id
where a.dw_eff_dt between 'from_date' AND 'to_date'
and a.revenue_tran_in = 'True'
and a.dw_suspected_bot_in = 'False'
and a.dw_site_visitor_id > 0
and a.prmry_vrtcl = 'Credit Cards |@| ALL'
and a.page_hier_lvl2_nm = 'Balance Transfer Credit Cards'
group by 1,2,3,4,5,6,7,8;
