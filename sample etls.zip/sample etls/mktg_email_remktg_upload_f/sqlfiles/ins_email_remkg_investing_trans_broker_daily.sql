-- https://nerdwallet.atlassian.net/browse/DWH-1618
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
  SELECT u.*
  FROM (
         WITH prod_clicks_with_me_et AS (
             SELECT
               dw_site_visitor_id
               , user_id
             FROM dw_views.dw_aflt_tran_enriched
             WHERE tran_click_ts BETWEEN 'from_date' AND 'to_date'
                   AND revenue_tran_in = 'True'
                   AND dw_click_page_sk IN ('398843','401219')
             GROUP BY 1, 2
             UNION
             SELECT
               dw_site_visitor_id
               , user_id
             FROM dw_views.dw_clicks_enriched
             WHERE click_utc_ts BETWEEN 'from_date' AND 'to_date'
                   AND is_sponsored_in = 1
                   AND dw_page_sk IN ('398843','401219')
                   AND src_prod_nm IN ('Merrill Edge', 'Etrade')
             GROUP BY 1, 2)

         SELECT DISTINCT
           '1153' AS adnc_id
           , 'email_remkg_investing_trans_broker_daily' AS adnc_nm
           , prod_clicks_with_me_et.dw_site_visitor_id :: VARCHAR(1000)
           , prod_clicks_with_me_et.user_id
           , c.sha256_email_hs
           , '-1' AS src_sys_id
           , '895-678-2332'
           , 'google' AS pfm_tx
         FROM prod_clicks_with_me_et
           JOIN dw_pud_report.dw_identity_d c
             ON prod_clicks_with_me_et.user_id = c.user_id
                AND c.curr_in = 1
       ) u;
