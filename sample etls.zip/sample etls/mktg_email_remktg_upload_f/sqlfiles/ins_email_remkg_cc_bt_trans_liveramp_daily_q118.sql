--balance transfer transcators with Excellent & Good FICO score -- formatted for upload
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx)
select '123' as adnc_id
       , 'email_remkg_cc_BTGoodCS_balance_transfer_liveramp_daily_q118' as adnc_nm
       , a.dw_site_visitor_id :: VARCHAR(1000)
       , b.user_id
       , c.sha256_email_hs
       , '-1' AS src_sys_id
       , null as ext_acct_id
       , 'liveramp' AS pfm_tx
from dw_views.dw_aflt_tran_enriched a
     join dw_report.dw_identity_site_visitor_xref_d b
on  a.dw_site_visitor_id = b.dw_site_visitor_id
     join dw_pud_views.dw_identity_d c
on b.user_id = c.user_id
and c.curr_in = 1
     join(
          select user_id
               , vantage_cr_scr_v3_bkt_nm
          from dw_pud_views.dw_user_snap_v
          where vantage_cr_scr_v3_bkt_nm in ('GOOD_690_719','EXCELLENT_720_850')
          ) d
on a.user_id = d.user_id
where a.dw_eff_dt between 'from_date' AND 'to_date'
and a.revenue_tran_in = 'True'
and a.dw_suspected_bot_in = 'False'
and (lower(dw_site_prod_nm) like '%bankamericard&%'
     or lower(dw_site_prod_nm) like '%simplicity%'
     or lower(dw_site_prod_nm) like '%discover it%balance%'
     or lower(dw_site_prod_nm) like '%slate%')
group by 1,2,3,4,5,6,7,8;

