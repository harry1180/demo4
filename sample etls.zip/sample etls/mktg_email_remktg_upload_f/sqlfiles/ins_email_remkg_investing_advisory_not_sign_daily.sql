-- https://nerdwallet.atlassian.net/browse/DWH-1594
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
  SELECT u.*
  FROM (
         WITH retirement_tool_onboarding_start AS (
             SELECT
               dw_site_visitor_id
               , user_id
             FROM dw_report.dw_pv_form_input_chg_event_f
             WHERE form_input_chg_utc_ts BETWEEN 'from_date' AND 'to_date'
                   AND field_nm = 'step:register:shown'
                   AND dw_page_sk IN ('1079565', '1062514', '397204')
             GROUP BY 1, 2
         ),
             retirement_tool_onboarding_flow AS (
               SELECT
                 dw_site_visitor_id
                 , user_id
               FROM dw_views.dw_page_view_enriched
               WHERE page_view_utc_ts BETWEEN 'from_date' AND 'to_date'
                     AND src_view_page_long_tx IN ('https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/maritalStatus_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/maritalStatus_response'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/income_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/savings_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/annual_savings_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/retirementAccounts401k_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/location_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/age_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/homeOwnership_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/spending_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/lifestyle_input'
                 , 'https://www.nerdwallet.com/investing/retirement-planning-tool/action/onboarding/page/connect_accounts')
               GROUP BY 1, 2)

         SELECT DISTINCT
           '1161' AS adnc_id
           , 'email_remkg_investing_advisory_not_sign_daily' AS adnc_nm
           , retirement_tool_onboarding_start.dw_site_visitor_id :: VARCHAR(1000)
           , retirement_tool_onboarding_start.user_id
           , c.sha256_email_hs
           , '-1' AS src_sys_id
           , '895-678-2332'
           , 'google' AS pfm_tx
         FROM retirement_tool_onboarding_start
           JOIN dw_pud_report.dw_identity_d c
             ON retirement_tool_onboarding_start.user_id = c.user_id
                AND c.curr_in = 1
           LEFT OUTER JOIN retirement_tool_onboarding_flow
             ON retirement_tool_onboarding_start.dw_site_visitor_id = retirement_tool_onboarding_flow.dw_site_visitor_id
         WHERE retirement_tool_onboarding_flow.user_id IS NULL
       ) u;
