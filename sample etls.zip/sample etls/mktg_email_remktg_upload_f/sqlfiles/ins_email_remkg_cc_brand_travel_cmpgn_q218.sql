--Visitors that clicked or had sizmek impression of brand travel campaign ads (pinterest, instagram or facebook)
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx)
select '130' as adnc_id
       , 'email_remkg_cc_brand_travel_cmpgn_q218' as adnc_nm
       , dw_site_visitor_id :: VARCHAR(1000)
       , user_id
       , sha256_email_hs
       , '21' AS src_sys_id
       , '400-092-3014' as ext_acct_id
       , 'google' AS pfm_tx
from(
	select a.dw_site_visitor_id :: VARCHAR(1000)
  		, c.user_id
  		, d.sha256_email_hs
	from dw_report.mktg_sizmek_conv_f a
  		join dw_report.mktg_sizmek_plcmt_ad_xref b
	on a.winner_entity_id = b.ad_id
	and a.plcmt_id = b.plcmt_id
  		join dw_report.dw_identity_site_visitor_xref_d c
	on a.dw_site_visitor_id = c.dw_site_visitor_id
  		join dw_pud_views.dw_identity_d d
	on c.user_id = d.user_id
	and d.curr_in = 1
	where b.plcmt_nm in ('cc_mktg_paid_050218_Traffic_CC_TravelCampaign_wave1_dma'
						, 'tv_mktg_paid_051618_brand_travel_wave2_pin_key'
						, 'tv_mktg_paid_051618_brand_travel_wave2_itg_dma')
	and a.dw_site_visitor_id is not null
	and a.dw_site_visitor_id <> '292844476'
	and a.dw_eff_dt between 'from_date' AND 'to_date'
	group by 1,2,3
	UNION ALL
	select a.dw_site_visitor_id :: VARCHAR(1000)
  		, b.user_id
  		, c.sha256_email_hs
	from dw_views.dw_session_enriched a
    	join dw_report.dw_identity_site_visitor_xref_d b
	on a.dw_site_visitor_id = b.dw_site_visitor_id
    	join dw_pud_views.dw_identity_d c
	on b.user_id = c.user_id
	and c.curr_in = 1
	where a.utm_campaign_id in ('cc_mktg_paid_050218_Traffic_CC_TravelCampaign_wave1_dma'
								, 'cc_mktg_paid_050218_Traffic_CC_TravelCampaign_wave1_lal'
								, 'tv_mktg_paid_051618_brand_travel_wave2_pin_lal'
								, 'tv_mktg_paid_051618_brand_travel_wave2_pin_key'
								, 'tv_mktg_paid_051618_brand_travel_wave2_itg_lal'
								, 'tv_mktg_paid_051618_brand_travel_wave2_itg_dma')
	and a.dw_site_visitor_id <> '292844476'
	and a.dw_suspected_bot_in = 'False'
	and a.dw_eff_dt between 'from_date' AND 'to_date'
	group by 1,2,3) a
group by 1,2,3,4,5,6,7,8;
