--All CC transactors + outbound clickers
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
  SELECT
    DISTINCT
    '121' AS adnc_id
    , 'email_remkg_membership_cc_trans_outbound_click_daily' AS adnc_nm
    , b.dw_site_visitor_id :: VARCHAR(1000)
    , b.user_id
    , c.sha256_email_hs
    , '21' AS src_sys_id
    , '400-092-3014'
    , 'google' AS pfm_tx

  FROM dw_views.dw_clicks_enriched a
    JOIN dw_report.dw_identity_site_visitor_xref_d b
      ON a.dw_site_visitor_id = b.dw_site_visitor_id
         AND a.dw_src_sys_id = 1
         AND a.is_sponsored_in = 1
    JOIN dw_pud_report.dw_identity_d c
      ON b.user_id = c.user_id
         AND c.curr_in = 1
  WHERE a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
        AND b.user_id <> 'guest'
        AND c.sha256_email_hs IS NOT NULL
        AND b.dw_site_visitor_id <> -1;
