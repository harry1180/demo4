INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
  SELECT em.*
  FROM (

         WITH em1 AS
         (SELECT
            e.sha256_email_hs
            , e.user_id
          FROM dw_views.dw_clicks_enriched b
            JOIN dw_report.dw_prod_d c
              ON b.src_prod_id = c.src_prod_id
                 AND c.curr_in = 1
                 AND c.del_in = 0
                 AND b.is_sponsored_in = 1
                 AND b.click_utc_ts BETWEEN 'from_date' AND 'to_date'
                 AND c.dw_src_sys_id = 8
            JOIN dw_report.dw_identity_site_visitor_xref_d d
              ON b.dw_site_visitor_id = d.dw_site_visitor_id
            JOIN dw_pud_report.dw_identity_d e
              ON d.user_id = e.user_id
                 AND e.curr_in = 1
          WHERE c.fin_prod_fmly_nm IN ('Checking Account')
          GROUP BY 1, 2),
             em2 AS (
               SELECT DISTINCT
                 '1111' AS adnc_id
                 , 'email_remkg_banking_non_click_checking_daily' AS adnc_nm
                 , a.dw_site_visitor_id :: VARCHAR(1000)
                 , a.user_id
                 , c.sha256_email_hs
                 , '-1' AS src_sys_id
                 , '416-486-4694'
                 , 'google' AS pfm_tx
               FROM dw_views.dw_page_view_enriched a
                 JOIN dw_report.dw_identity_site_visitor_xref_d b
                   ON a.dw_site_visitor_id = b.dw_site_visitor_id
                 JOIN dw_pud_report.dw_identity_d c
                   ON b.user_id = c.user_id
                      AND c.curr_in = 1
                 WHERE a.page_view_utc_ts BETWEEN 'from_date' AND 'to_date'
                     AND a.view_dw_page_sk IN ('16165', '1014671')
                     AND sha256_email_hs IS NOT NULL)
         SELECT em2.*
         FROM em2
           LEFT OUTER JOIN em1
             ON em1.sha256_email_hs = em2.sha256_email_hs
         WHERE em1.user_id IS NULL) em;
