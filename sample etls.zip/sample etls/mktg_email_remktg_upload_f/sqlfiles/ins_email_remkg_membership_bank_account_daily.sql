--People who have registered and linked a bank account
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
  SELECT
    DISTINCT
    '118' AS adnc_id
    , 'email_remkg_membership_bank_account_daily' AS adnc_nm
    , xref.dw_site_visitor_id :: VARCHAR(1000)
    , a.user_id
    , b.sha256_email_hs
    , '21' AS src_sys_id
    , '400-092-3014'
    , 'google' AS pfm_tx

  FROM dw_pud_views.dw_yd_acct_d a
  JOIN dw_pud_report.dw_identity_d b
    ON a.user_id = b.user_id
       AND b.curr_in = 1
       AND lower(a.yd_acct_type_cd) = 'bank'
       AND a.curr_in = 1
       AND a.del_in = 0
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d xref ON xref.user_id = a.user_id
  WHERE xref.user_id <> 'guest'
        AND b.sha256_email_hs IS NOT NULL
        AND b.first_rgstr_utc_ts BETWEEN 'from_date' AND 'to_date'
        AND xref.dw_site_visitor_id <> -1;
