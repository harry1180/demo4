INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
SELECT u.*
FROM (

       WITH mrkt_visitors AS
       (SELECT
          dw_site_visitor_id
          , user_id
        FROM dw_views.dw_page_view_enriched
        WHERE page_view_utc_ts BETWEEN 'from_date' AND 'to_date'
              AND view_dw_page_sk IN ('398843','401219')
        GROUP BY 1, 2),

           prod_clicks AS (
             SELECT
               dw_site_visitor_id
               , user_id
             FROM dw_views.dw_clicks_enriched
             WHERE click_utc_ts BETWEEN 'from_date' AND 'to_date'
                   AND dw_page_sk IN ('398843','401219')
             GROUP BY 1, 2
         ),

           prod_clicks_me_et AS (
             SELECT
               dw_site_visitor_id
               , user_id
             FROM dw_views.dw_clicks_enriched
             WHERE click_utc_ts BETWEEN 'from_date' AND 'to_date'
                   AND dw_page_sk IN ('398843','401219')
                   AND is_sponsored_in = 1
                   AND src_prod_nm NOT IN ('Merrill Edge', 'Etrade')
             GROUP BY 1, 2
         )

       SELECT DISTINCT
         '1133' AS adnc_id
         , 'email_remkg_investing_not_click_broker_daily' AS adnc_nm
         , mrkt_visitors.dw_site_visitor_id :: VARCHAR(1000)
         , mrkt_visitors.user_id
         , c.sha256_email_hs
         , '-1' AS src_sys_id
         , '895-678-2332'
         , 'google' AS pfm_tx
       FROM mrkt_visitors
         JOIN dw_pud_report.dw_identity_d c
           ON mrkt_visitors.user_id = c.user_id
              AND c.curr_in = 1
         LEFT OUTER JOIN prod_clicks_me_et d
           ON mrkt_visitors.dw_site_visitor_id = d.dw_site_visitor_id
         WHERE d.user_id IS NULL
     ) u;
