INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
  SELECT
    DISTINCT
    '101'
    , 'email_remkg_pl_daily'
    , dwh_pl_uvs.dw_site_visitor_id :: VARCHAR(1000)
    , dw_id.user_id
    , dw_email_hash.sha256_email_hs
    , '14'
    , '863-187-2757'
    , 'google' AS pfm_tx
  FROM
    (SELECT DISTINCT a.dw_site_visitor_id
     FROM dw_report.dw_prequal_offer_event_pl_f a
       LEFT JOIN dw_report.dw_clicks_event_f b ON (a.dw_site_visitor_id = b.dw_site_visitor_id
                                                   AND b.dw_url_sk IN (2433919, 2433920, 2409871)
                                                   AND b.dw_src_sys_id = 14)
     WHERE b.dw_site_visitor_id IS NULL
           AND a.dw_site_visitor_id <> -1
           AND a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
    ) dwh_pl_uvs
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d dw_id ON dwh_pl_uvs.dw_site_visitor_id = dw_id.dw_site_visitor_id
    LEFT JOIN dw_pud_report.dw_identity_d dw_email_hash ON dw_email_hash.user_id = dw_id.user_id
  WHERE dw_id.user_id <> 'guest'
        AND dw_email_hash.sha256_email_hs IS NOT NULL
;
