INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx
)
SELECT
    '109' AS adnc_id
    , 'email_remkg_cc_lowinterest_liveramp_daily' AS adnc_nm
    , a.dw_site_visitor_id :: VARCHAR(1000)
    , b.user_id
    , c.md5_email_hs
    , '24' AS src_sys_id
    , 'undefined' AS ext_account_id
    , 'liveramp' AS pfm_tx
  FROM dw_views.dw_aflt_tran_enriched a
    INNER JOIN dw_report.dw_identity_site_visitor_xref_d b
      ON a.dw_site_visitor_id = b.dw_site_visitor_id
    INNER JOIN dw_pud_report.dw_identity_d c
      ON a.user_id = c.user_id
         AND c.curr_in = 1
    INNER JOIN (SELECT
                  user_id
                  , vantage_cr_scr_v3_rng_start_nr
                FROM dw_pud_views.dw_user_snap_v
                WHERE nw_acct_status_cd = 'ACTIVE'
                      AND tu_acct_status_cd = 'ACTIVE'
                      AND dw_suspected_bot_in = 'false'
                      AND vantage_cr_scr_v3_rng_start_nr >= 600
               ) d
      ON b.user_id = d.user_id
  WHERE a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
        AND a.prod_seo_nm IN ('Chase Freedom' || CHR(174), 'Citi Simplicity', 'Discover it')
;
