INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
-- Start Google --

  SELECT
    DISTINCT
    '101'
    , 'email_remkg_pl_daily'
    , dwh_pl_uvs.dw_site_visitor_id :: VARCHAR(1000)
    , dw_id.user_id
    , dw_email_hash.sha256_email_hs
    , '14'
    , '863-187-2757'
    , 'google' AS pfm_tx
  FROM
    (SELECT DISTINCT a.dw_site_visitor_id
     FROM dw_report.dw_prequal_offer_event_pl_f a
       LEFT JOIN dw_report.dw_clicks_event_f b ON (a.dw_site_visitor_id = b.dw_site_visitor_id
                                                   AND b.dw_url_sk IN (2433919, 2433920, 2409871)
                                                   AND b.dw_src_sys_id = 14)
     WHERE b.dw_site_visitor_id IS NULL
           AND a.dw_site_visitor_id <> -1
           AND a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
    ) dwh_pl_uvs
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d dw_id ON dwh_pl_uvs.dw_site_visitor_id = dw_id.dw_site_visitor_id
    LEFT JOIN dw_pud_report.dw_identity_d dw_email_hash ON dw_email_hash.user_id = dw_id.user_id
  WHERE dw_id.user_id <> 'guest'
        AND dw_email_hash.sha256_email_hs IS NOT NULL

  UNION

  SELECT
    DISTINCT
    '102' AS adnc_id
    , 'email_remkg_membership_daily' AS adnc_nm
    , xref.dw_site_visitor_id :: VARCHAR(1000)
    , dw_id.user_id
    , dw_email_hash.sha256_email_hs
    , '21' AS src_sys_id
    , '748-142-2174'
    , 'google' AS pfm_tx
  FROM dw_report.dw_user_d dw_id
    LEFT JOIN dw_pud_report.dw_identity_d dw_email_hash ON dw_email_hash.user_id = dw_id.user_id
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d xref ON xref.user_id = dw_id.user_id
  WHERE xref.user_id <> 'guest'
        AND dw_email_hash.sha256_email_hs IS NOT NULL
        AND dw_id.reg_ts BETWEEN 'from_date' AND 'to_date'
        AND xref.dw_site_visitor_id <> -1

  UNION
  -- Membership data segmented into FICO bands - Low.
  SELECT
    DISTINCT
    '1101' AS adnc_id
    , 'email_remkg_membership_fico_low_daily' AS adnc_nm
    , xref.dw_site_visitor_id :: VARCHAR(1000)
    , dw_id.user_id
    , dw_email_hash.sha256_email_hs
    , '-1' AS src_sys_id
    , '400-092-3014'
    , 'google' AS pfm_tx
  FROM
    (SELECT
        user_id
        , reg_ts
      FROM dw_pud_views.dw_user_snap_v
      WHERE
        vantage_cr_scr_v3_bkt_nm IN ('POOR_300_629')
        AND nw_acct_status_cd = 'ACTIVE'
        AND tu_acct_status_cd = 'ACTIVE'
        AND dw_suspected_bot_in = 'false'
    ) dw_id
    LEFT JOIN dw_pud_report.dw_identity_d dw_email_hash ON dw_email_hash.user_id = dw_id.user_id
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d xref ON xref.user_id = dw_id.user_id
  WHERE xref.user_id <> 'guest'
        AND dw_email_hash.sha256_email_hs IS NOT NULL
        AND dw_id.reg_ts BETWEEN 'from_date' AND 'to_date'
        AND xref.dw_site_visitor_id <> -1

  UNION
  -- Membership data segmented into FICO bands - Med.
  SELECT
    DISTINCT
    '1102' AS adnc_id
    , 'email_remkg_membership_fico_med_daily' AS adnc_nm
    , xref.dw_site_visitor_id :: VARCHAR(1000)
    , dw_id.user_id
    , dw_email_hash.sha256_email_hs
    , '-1' AS src_sys_id
    , '400-092-3014'
    , 'google' AS pfm_tx
  FROM
    (SELECT
        user_id
        , reg_ts
      FROM dw_pud_views.dw_user_snap_v
      WHERE
        vantage_cr_scr_v3_bkt_nm IN ('AVERAGE_630_689', 'GOOD_690_719')
        AND nw_acct_status_cd = 'ACTIVE'
        AND tu_acct_status_cd = 'ACTIVE'
        AND dw_suspected_bot_in = 'false'
    ) dw_id
    LEFT JOIN dw_pud_report.dw_identity_d dw_email_hash ON dw_email_hash.user_id = dw_id.user_id
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d xref ON xref.user_id = dw_id.user_id
  WHERE xref.user_id <> 'guest'
        AND dw_email_hash.sha256_email_hs IS NOT NULL
        AND dw_id.reg_ts BETWEEN 'from_date' AND 'to_date'
        AND xref.dw_site_visitor_id <> -1

  UNION
  -- Membership data segmented into FICO bands - High.
  SELECT
    DISTINCT
    '1103' AS adnc_id
    , 'email_remkg_membership_fico_high_daily' AS adnc_nm
    , xref.dw_site_visitor_id :: VARCHAR(1000)
    , dw_id.user_id
    , dw_email_hash.sha256_email_hs
    , '-1' AS src_sys_id
    , '400-092-3014'
    , 'google' AS pfm_tx
  FROM
    (SELECT
        user_id
        , reg_ts
      FROM dw_pud_views.dw_user_snap_v
      WHERE
        vantage_cr_scr_v3_bkt_nm IN ('EXCELLENT_720_850')
        AND nw_acct_status_cd = 'ACTIVE'
        AND tu_acct_status_cd = 'ACTIVE'
        AND dw_suspected_bot_in = 'false'
    ) dw_id
    LEFT JOIN dw_pud_report.dw_identity_d dw_email_hash ON dw_email_hash.user_id = dw_id.user_id
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d xref ON xref.user_id = dw_id.user_id
  WHERE xref.user_id <> 'guest'
        AND dw_email_hash.sha256_email_hs IS NOT NULL
        AND dw_id.reg_ts BETWEEN 'from_date' AND 'to_date'
        AND xref.dw_site_visitor_id <> -1

  -- End Google --

  -- Start Liveramp --

  UNION
  SELECT
    '103' AS adnc_id
    , 'email_remkg_cc_rewards_liveramp_daily' AS adnc_nm
    , c.dw_site_visitor_id :: VARCHAR(1000)
    , c.user_id
    , e.sha256_email_hs
    , '24' AS src_sys_id
    , 'undefined' AS ext_account_id
    , 'liveramp' AS pfm_tx
  FROM dw_views.dw_aflt_tran_enriched a
    LEFT OUTER JOIN dw_views.dw_creditcard_catg b
      ON (a.dw_site_prod_sk = b.dw_site_prod_sk
          AND b.curr_in = 1
          AND b.reporting_category_nm IN ('Cash Back',
                                          'Balance Transfer',
                                          'Travel',
                                          'Airline',
                                          'Rewards',
                                          'Zero Percent'))
    LEFT OUTER JOIN dw_report.dw_identity_site_visitor_xref_d c
      ON (a.dw_site_visitor_id = c.dw_site_visitor_id)
    LEFT OUTER JOIN dw_pud_report.dw_identity_glb_profile_d d
      ON (d.user_id = c.user_id
          AND d.subscr_email_enbl_in = 'true'
          AND d.curr_in = 1)
    LEFT OUTER JOIN dw_pud_report.dw_identity_d e
      ON (d.user_id = e.user_id
          AND d.curr_in = 1)
  WHERE a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
        AND lower(a.page_hier_lvl1_nm) = 'credit cards'
        AND a.dw_suspected_bot_in = 'False'
        AND a.dw_site_visitor_id IS NOT NULL
        AND c.user_id IS NOT NULL
        AND e.sha256_email_hs IS NOT NULL
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8

  UNION

  SELECT
    '106' AS adnc_id
    , 'email_remkg_cc_upgrade_liveramp_daily' AS adnc_nm
    , a.dw_site_visitor_id :: VARCHAR(1000)
    , b.user_id
    , c.md5_email_hs
    , '24' AS src_sys_id
    , 'undefined' AS ext_account_id
    , 'liveramp' AS pfm_tx
  FROM dw_views.dw_aflt_tran_enriched a
    JOIN dw_report.dw_identity_site_visitor_xref_d b
      ON a.dw_site_visitor_id = b.dw_site_visitor_id
    JOIN dw_pud_report.dw_identity_d c
      ON a.user_id = c.user_id
         AND c.curr_in = 1
    JOIN (SELECT
            user_id
            , vantage_cr_scr_v3_rng_start_nr
          FROM dw_pud_views.dw_user_snap_v
          WHERE nw_acct_status_cd = 'ACTIVE'
                AND tu_acct_status_cd = 'ACTIVE'
                AND dw_suspected_bot_in = 'false'
                AND vantage_cr_scr_v3_rng_start_nr >= 700
         ) d
      ON b.user_id = d.user_id
  WHERE a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
        AND a.prod_seo_nm IN ('Discover it 18 Month Balance Transfer'
    , 'Citi Simplicity'
    , 'Chase Sapphire Preferred'
    , 'BankAmericard Travel Rewards'
    , 'Discover it'
    , 'Citi Double Cash Card')

  UNION

  SELECT
    '109' AS adnc_id
    , 'email_remkg_cc_lowinterest_liveramp_daily' AS adnc_nm
    , a.dw_site_visitor_id :: VARCHAR(1000)
    , b.user_id
    , c.md5_email_hs
    , '24' AS src_sys_id
    , 'undefined' AS ext_account_id
    , 'liveramp' AS pfm_tx
  FROM dw_views.dw_aflt_tran_enriched a
    INNER JOIN dw_report.dw_identity_site_visitor_xref_d b
      ON a.dw_site_visitor_id = b.dw_site_visitor_id
    INNER JOIN dw_pud_report.dw_identity_d c
      ON a.user_id = c.user_id
         AND c.curr_in = 1
    INNER JOIN (SELECT
                  user_id
                  , vantage_cr_scr_v3_rng_start_nr
                FROM dw_pud_views.dw_user_snap_v
                WHERE nw_acct_status_cd = 'ACTIVE'
                      AND tu_acct_status_cd = 'ACTIVE'
                      AND dw_suspected_bot_in = 'false'
                      AND vantage_cr_scr_v3_rng_start_nr >= 600
               ) d
      ON b.user_id = d.user_id
  WHERE a.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
        AND a.prod_seo_nm IN ('Chase Freedom' || CHR(174), 'Citi Simplicity', 'Discover it')

-- End Liveramp --
;
