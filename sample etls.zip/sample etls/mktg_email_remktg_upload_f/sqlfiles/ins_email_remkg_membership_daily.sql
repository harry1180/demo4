INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
SELECT
    DISTINCT
    '102' AS adnc_id
    , 'email_remkg_membership_daily' AS adnc_nm
    , c.dw_site_visitor_id :: VARCHAR(1000)
    , b.user_id
    , b.sha256_email_hs
    , '21' AS src_sys_id
    , '748-142-2174'
    , 'google' AS pfm_tx
from dw_pud_report.dw_identity_d b
LEFT JOIN dw_report.dw_identity_site_visitor_xref_d c
ON b.user_id = c.user_id
WHERE b.sha256_email_hs IS NOT NULL
AND b.dw_eff_dt BETWEEN 'from_date' AND 'to_date'
AND c.dw_site_visitor_id <> -1
;