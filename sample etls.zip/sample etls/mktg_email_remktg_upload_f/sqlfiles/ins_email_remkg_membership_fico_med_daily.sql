INSERT INTO dw_stage.mktg_goog_email_remktg_s (
adnc_id,
adnc_nm,
dw_site_visitor_id,
user_id,
email_hs,
src_sys_id,
ext_acct_id,
pfm_tx
)
SELECT
DISTINCT
'1102' AS adnc_id
, 'email_remkg_membership_fico_med_daily' AS adnc_nm
, xref.dw_site_visitor_id :: VARCHAR(1000)
, dw_id.user_id
, dw_email_hash.sha256_email_hs
, '-1' AS src_sys_id
, '400-092-3014'
, 'google' AS pfm_tx
FROM
(SELECT
user_id
, reg_ts
FROM dw_pud_views.dw_user_snap_v
WHERE
vantage_cr_scr_v3_bkt_nm IN ('AVERAGE_630_689', 'GOOD_690_719')
AND nw_acct_status_cd = 'ACTIVE'
AND tu_acct_status_cd = 'ACTIVE'
AND dw_suspected_bot_in = 'false'
) dw_id
LEFT JOIN dw_pud_report.dw_identity_d dw_email_hash ON dw_email_hash.user_id = dw_id.user_id
LEFT JOIN dw_report.dw_identity_site_visitor_xref_d xref ON xref.user_id = dw_id.user_id
WHERE xref.user_id <> 'guest'
AND dw_email_hash.sha256_email_hs IS NOT NULL
AND dw_id.reg_ts BETWEEN 'from_date' AND 'to_date'
AND xref.dw_site_visitor_id <> -1
;
