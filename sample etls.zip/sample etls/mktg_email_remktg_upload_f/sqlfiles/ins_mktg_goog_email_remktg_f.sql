--Delete all rows for 'upadte' type lists
DELETE FROM dw_report.mktg_goog_email_remktg_f
WHERE mktg_goog_email_remktg_f.adnc_id IN (SELECT DISTINCT adnc_id
                                           FROM dw_report.mktg_goog_remktg_adnc_d
                                           WHERE COALESCE(upload_type_cd, '') = 'update');

--Insert a new rows
INSERT INTO dw_report.mktg_goog_email_remktg_f
(
  adnc_id,
  adnc_nm,
  dw_eff_dt,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx,
  dw_load_ts
)
  SELECT
    stg.adnc_id,
    stg.adnc_nm,
    trunc(sysdate),
    stg.dw_site_visitor_id,
    stg.user_id,
    stg.email_hs,
    stg.src_sys_id,
    stg.ext_acct_id,
    stg.pfm_tx,
    getdate()
  FROM dw_stage.mktg_goog_email_remktg_s stg LEFT JOIN dw_report.mktg_goog_email_remktg_f fct
      ON (stg.adnc_id = fct.adnc_id AND stg.email_hs = fct.email_hs)
  WHERE fct.adnc_id IS NULL AND stg.dw_site_visitor_id <> -1;

