--Segment people who registered for an account within the 30 days
INSERT INTO dw_stage.mktg_goog_email_remktg_s (
  adnc_id,
  adnc_nm,
  dw_site_visitor_id,
  user_id,
  email_hs,
  src_sys_id,
  ext_acct_id,
  pfm_tx
)
  SELECT
    DISTINCT
    '1171' AS adnc_id
    , 'email_remkg_membership_30_days_daily' AS adnc_nm
    , xref.dw_site_visitor_id :: VARCHAR(1000)
    , a.user_id
    , b.sha256_email_hs
    , '21' AS src_sys_id
    , '400-092-3014'
    , 'google' AS pfm_tx

  FROM dw_pud_views.dw_user_snap_v a
    JOIN dw_pud_report.dw_identity_d b
      ON a.user_id = b.user_id
         AND b.curr_in = 1
         AND a.nw_acct_status_cd = 'ACTIVE'
    LEFT JOIN dw_report.dw_identity_site_visitor_xref_d xref ON xref.user_id = a.user_id
  WHERE xref.user_id <> 'guest'
        AND b.sha256_email_hs IS NOT NULL
        AND a.reg_dw_eff_dt BETWEEN current_date - 30 and current_date
        AND xref.dw_site_visitor_id <> -1;
