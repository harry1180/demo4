job_name='mktg_fb_offline_event_upload_f'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
dwh_chef_credentials_file=${dwh_chef_credentials_file_dir}"/passwords.ctrl"
echo "dwh_chef_credentials_file:"${dwh_chef_credentials_file}
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
stage_db="dw_stage"
target_db='dw_report'

echo 'config_file_name   :-   '${config_file_name}
date_load_from=$1
date_load_to=$2
echo 'stage_db:        :-   '${stage_db}
echo 'target_db:        :-   '${target_db}

echo 'if date range is not defined by user input then default is loading today-30 to yesterday'
if [[ -n "${date_load_from}" && -n "${date_load_to}" ]]; then
    echo "date range defined by user"
else
    date_load_from=`date --date='-30 day' '+%Y-%m-%d'`
    date_load_to=`date --date='-1 day' '+%Y-%m-%d'`
fi

echo 'date_load_from:     :-   '${date_load_from}
echo 'date_load_to:       :-   '${date_load_to}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

trap 'abort' 0
set -e


# ETL scripts executed in sequence
echo_processing_step ${job_name} "Removing Data Files" "Started"
list_job_related_files
find ${Linux_Input} -name \*fb\* -exec rm {} \; || true
list_job_related_files
echo_processing_step ${job_name} "Removing Data Files" "Completed"

echo_processing_step ${job_name} "generate redshift param file" "notify"
echo "{
\"from_date\":\"${date_load_from}\",
\"to_date\":\"${date_load_to}\"
}" > ${Linux_Output}/${job_name}_redshift_params.json

cat ${Linux_Output}/${job_name}_redshift_params.json
# ETL scripts executed in sequence
# Disabling Yodlee not activated audience set since social team dont need it anymore. Confirmed with Vivian. When we re-enable, we need to override the complete audience, not incremental like we currently do for all other audience.
# mktg_segments_fb_yodlee_not_activated_q318.sql - 2102634543291946  
echo "mktg_segments_fb_engage_session_metric.sql
mktg_segments_fb_credit_score_activation.sql
mktg_segments_fb_cc_bt720_pay2000_q218.sql
mktg_segments_fb_synchrony_acct_opens_q218.sql
mktg_segments_fb_amex_acct_opens_q218.sql
mktg_segments_fb_barclays_acct_opens_q218.sql
mktg_segments_fb_cit_acct_opens_q218.sql" | while read sql_script other_var
do
  echo_processing_step ${job_name} "$sql_script" "Started"
  bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/${sql_script} ${Linux_Output}/${job_name}_redshift_params.json
  echo_processing_step ${job_name} "$sql_script" "Completed"
done

echo_processing_step ${job_name} "Upload offline events" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/mktg_fb_offline_event_upload_f.py ${dwh_chef_credentials_file} ${date_load_to}
echo_processing_step ${job_name} "Upload offline events" "Completed"

# DQ scripts executed in sequence
#echo "" | while read script other_var
#do
#  Processing_Step="DQ check - ${script}"
#  echo_processing_step ${job_name} "${Processing_Step}" "Started"
#  python ${dwh_common_base_dir}/run_dq_check.py ${dwh_scripts_base_dir}/${job_name}/pythonscripts/${script}
#  echo_processing_step ${job_name} "${Processing_Step}" "Completed"
#done

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
