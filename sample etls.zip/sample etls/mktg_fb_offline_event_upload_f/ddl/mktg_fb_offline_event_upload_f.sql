DROP TABLE IF EXISTS dw_report.mktg_fb_offline_event_upload_f;

CREATE TABLE dw_report.mktg_fb_offline_event_upload_f
(
      offline_event_set_id  VARCHAR(100)   ENCODE zstd
    , dw_upload_dt          DATE           ENCODE zstd
    , dw_eff_dt             DATE           ENCODE zstd
    , site_uv_id            VARCHAR(45)    ENCODE zstd
    , adr_id                VARCHAR(500)   ENCODE zstd
    , lead_id               VARCHAR(500)   ENCODE zstd
    , gender_tx             VARCHAR(500)   ENCODE zstd
    , event_nm              VARCHAR(100)   ENCODE zstd
    , event_ts              TIMESTAMP      ENCODE zstd
    , match_key_list_tx     VARCHAR(500)   ENCODE zstd
    , custom_tx             VARCHAR(6000)  ENCODE zstd
    , dw_load_ts            TIMESTAMP      ENCODE zstd
)
distkey(site_uv_id)
sortkey(dw_upload_dt) ;
GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_report.mktg_fb_offline_event_upload_f TO group grp_etl;
GRANT SELECT ON dw_report.mktg_fb_offline_event_upload_f TO group grp_data_users;
GRANT ALL ON dw_report.mktg_fb_offline_event_upload_f TO nw_dwh_etl;

