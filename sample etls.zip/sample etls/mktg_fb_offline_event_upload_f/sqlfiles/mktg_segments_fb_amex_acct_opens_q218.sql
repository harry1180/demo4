--Audience of Visitors that opened Synchrony bank accounts (clickmeter data starting 2/21)
delete from dw_report.mktg_fb_offline_event_upload_f
where dw_upload_dt = 'to_date'
and offline_event_set_id = '298553544247705';

insert into dw_report.mktg_fb_offline_event_upload_f
(
offline_event_set_id
,dw_upload_dt
,dw_eff_dt
,site_uv_id
,adr_id
,lead_id
,gender_tx
,event_nm
,event_ts
,match_key_list_tx
,custom_tx
,dw_load_ts
)SELECT
  '298553544247705' -- hardcode provided event set ID
  , 'to_date'::date AS upload_dt -- we have SQL param 'to_date' getting input date
  , a.dw_eff_dt AS dw_eff_dt
  , b.site_uv_id
  , null
  , null
  , null
  , 'Other'
  , cast('to_date' as timestamp)
  , 'extern_id' -- only extern_id is used for match_key
  , null AS custom_tx -- no custom params for this segment
  , sysdate
from dw_report.dw_aflt_tran_consolidated_f a

left join dw_views.dw_session_enriched b
on a.dw_site_visitor_id = b.dw_site_visitor_id
and a.dw_session_id = b.dw_session_id

where lower(aflt_fin_tran_type_cd) = 'conversion'
and coalesce(nw_click_dt,tran_post_dt) between 'from_date' AND 'to_date'
and a.dw_site_visitor_id <> '-999999999'
and b.dw_eff_dt between 'from_date' AND 'to_date'
--and prog_nm = 'Barclays US Online Savings'
and prog_nm = 'American Express Personal Savings'
--and prog_nm = 'CIT Bank'
group by 1,2,3,4,5,6,7,8,9,10,11,12;

 
