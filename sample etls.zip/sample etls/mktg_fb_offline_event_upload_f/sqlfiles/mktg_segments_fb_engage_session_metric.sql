-- upload engaged session of last 7 days, no need to exclude the visitors already uploaded previous days

delete from dw_report.mktg_fb_offline_event_upload_f
where dw_upload_dt = 'to_date'
and offline_event_set_id = '191892838093424';

insert into dw_report.mktg_fb_offline_event_upload_f
(
offline_event_set_id
,dw_upload_dt
,dw_eff_dt
,site_uv_id
,event_nm
,event_ts
,match_key_list_tx
,custom_tx
,dw_load_ts
)
 SELECT
  '191892838093424'
  , 'to_date' AS upload_dt
  , dw_eff_dt AS dw_eff_dt
  , site_uv_id
  , 'Other'
  , 'to_date'
  , 'extern_id'
  ----- custom data should be in JSON format -----
  , '{"landing_page":"'|| landing_page_path ||'"}' AS custom_tx
  , sysdate
 FROM (
  SELECT
   b.dw_eff_dt
   , b.dw_site_visitor_id
   , uv.site_uv_id
   , b.dw_session_id
   , b.model_wt
   , b.model_id
   , b.attr_dw_campaign_id
   , b.attr_dw_ad_id
   , b.attr_trfc_src_lvl1_nm
   , b.attr_trfc_src_lvl2_nm
   , b.attr_trfc_src_lvl3_nm
   , b.attribution
   , b.attr_utm_campaign_id
   , b.attr_utm_content_tx
   , b.attr_utm_term_tx
   , b.mktg_img_id
   , b.mktg_place_id
   , b.mktg_hline_id
   , b.mktg_body_id
   , b.mktg_link_id
   , b.device
   , b.os_type
   , b.mktg_vertical_id
   , coalesce(e.page_path_tx, 'NA') AS landing_page_path
   , CASE WHEN b.tot_page_view_ct > 1 THEN 1 ELSE 0 END AS multiple_pv_session_ind
   , sum(b.durtn_in_sec_nr) * model_wt AS time_spent
   , CASE WHEN sum(b.durtn_in_sec_nr) * model_wt >= 600 THEN 1 ELSE 0 END AS long_session_ind
   , CASE WHEN c.dw_session_id IS NOT NULL THEN 1 ELSE 0 END AS form_change_session_ind
  FROM dw_views.dw_session_enriched_mta_104 b
  LEFT OUTER JOIN (
                   SELECT DISTINCT dw_session_id
                   FROM dw_report.dw_pv_form_input_chg_event_f
                   WHERE dw_eff_dt BETWEEN 'to_date' - 1 AND 'to_date'
                         AND dw_suspected_bot_in = 'False') c
  ON b.dw_session_id = c.dw_session_id
  LEFT OUTER JOIN dw_report.mktg_tch_ad_d d
  ON b.attr_dw_ad_id = d.dw_ad_id
  LEFT OUTER JOIN dw_report.dw_page_d e
  ON d.dw_page_sk = e.dw_page_sk
  LEFT OUTER JOIN dw_report.site_visitor_d uv
  ON b.dw_site_visitor_id = uv.dw_site_visitor_id
  WHERE b.dw_eff_dt BETWEEN 'to_date' - 1 AND 'to_date'
        AND b.dw_suspected_bot_in = 'False'
        AND b.dw_site_visitor_id <> 49593011
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 28)
 GROUP BY site_uv_id, landing_page_path, dw_eff_dt
 HAVING sum((CASE WHEN multiple_pv_session_ind >= 1 OR long_session_ind >= 1 OR
                       form_change_session_ind >= 1 THEN 1 ELSE 0 END) * model_wt) > 0;