--Upload all BT transactors with credit score < 720 and monthly payment under 2000
delete from dw_report.mktg_fb_offline_event_upload_f
where dw_upload_dt = 'to_date'
and offline_event_set_id = '443543366098082';

insert into dw_report.mktg_fb_offline_event_upload_f
(
offline_event_set_id
,dw_upload_dt
,dw_eff_dt
,site_uv_id
,adr_id
,lead_id
,gender_tx
,event_nm
,event_ts
,match_key_list_tx
,custom_tx
,dw_load_ts
)
 SELECT
  '443543366098082' -- hardcode provided event set ID
  , 'to_date'::date AS upload_dt -- we have SQL param 'to_date' getting input date
  , a.dw_eff_dt AS dw_eff_dt
  , b.site_uv_id
  , null
  , null
  , null
  , 'Other'
  , 'to_date'
  , 'extern_id' -- only extern_id is used for match_key
  , '{"fico_credit_score":"'|| d.vantage_cr_scr_3_nr ||'","monthly_payment":"'|| e.tot_mly_pmt ||'"}' AS custom_tx -- in this example there's one custom param 'landing_page'
  , sysdate
from dw_views.dw_aflt_tran_enriched a
     join dw_report.dw_identity_site_visitor_xref_d b
on  a.dw_site_visitor_id = b.dw_site_visitor_id
     join dw_pud_views.dw_identity_d c
on b.user_id = c.user_id
and c.curr_in = 1
     join dw_pud_views.dw_identity_tu_credit_rprt_profile_d d
on b.user_id = d.user_id
and d.curr_in = 1
and d.vantage_cr_scr_3_bkt_nm not in ('EXCELLENT_720_850','UNKNOWN')
     join(
          select user_id
              , tot_mly_pmt
              from(
                  select a.user_id
                    , count(a.tu_trdln_id)
                    , count(distinct a.tu_trdln_id)
                    , count(a.acct_subtype_desc_tx)
                    , sum(cur_bal_am) as tot_bal_am
                    , sum(credit_limit_am) as tot_crdt_lim_am
                    , sum(mly_pmt) as tot_mly_pmt
                    , case when sum(credit_limit_am) > 0 then sum(cur_bal_am)/sum(credit_limit_am) else null end as utilization
                  from dw_pud_views.dw_identity_tu_trdln_snap_f a
                    left outer join dw_pud_views.trdln_accnt_sub_type_map b
                  on a.acct_subtype_desc_tx = b.acct_subtype_desc_tx
                  where a.trdln_clsd_ts is null
                  and a.curr_in = 1 
                  and a.del_in = 0
                  and b.category = 'Credit Cards'
                  and a.acct_dsgntr_desc_tx <> 'Authorized User'
                  group by 1)a
          where tot_mly_pmt < 2000) e
on b.user_id = e.user_id
where a.dw_eff_dt between 'from_date' AND 'to_date'
and a.revenue_tran_in = 'True'
and a.dw_suspected_bot_in = 'False'
and a.dw_site_visitor_id > 0
and a.prmry_vrtcl = 'Credit Cards |@| ALL'
and a.page_hier_lvl2_nm = 'Balance Transfer Credit Cards'
group by 1,2,3,4,5,6,7,8,vantage_cr_scr_3_nr, tot_mly_pmt;
