--Audience of Visitors that opened Synchrony bank accounts (clickmeter data starting 2/21)
delete from dw_report.mktg_fb_offline_event_upload_f
where dw_upload_dt = 'to_date'
and offline_event_set_id = '986940538139411';

insert into dw_report.mktg_fb_offline_event_upload_f
(
offline_event_set_id
,dw_upload_dt
,dw_eff_dt
,site_uv_id
,adr_id
,lead_id
,gender_tx
,event_nm
,event_ts
,match_key_list_tx
,custom_tx
,dw_load_ts
)
 SELECT
  '986940538139411' -- hardcode provided event set ID
  , 'to_date'::date AS upload_dt -- we have SQL param 'to_date' getting input date
  , a.dw_eff_dt AS dw_eff_dt
  , b.site_uv_id
  , null
  , null
  , null
  , 'Other'
  , cast('to_date' as timestamp)
  , 'extern_id' -- only extern_id is used for match_key
  , null AS custom_tx -- no custom params for this segment
  , sysdate
from dw_report.dw_aflt_tran_clickmeter_f a
  join dw_views.dw_session_enriched b
on a.dw_site_visitor_id = b.dw_site_visitor_id
and a.dw_session_id = b.dw_session_id
where a.conversion_in = true
and lower(a.src_group_nm) = 'synchrony'
and a.dw_eff_dt between 'from_date' AND 'to_date'
and a.dw_site_visitor_id <> '-999999999'
and b.dw_eff_dt between 'from_date' AND 'to_date'
group by 1,2,3,4,5,6,7,8,9,10,11,12;

