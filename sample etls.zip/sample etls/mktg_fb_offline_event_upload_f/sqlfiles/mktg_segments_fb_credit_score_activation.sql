--Upload all Credit Score activations in the last 7 days
delete from dw_report.mktg_fb_offline_event_upload_f
where dw_upload_dt = 'to_date'
and offline_event_set_id = '2062364774033793';

insert into dw_report.mktg_fb_offline_event_upload_f
(
offline_event_set_id
,dw_upload_dt
,dw_eff_dt
,site_uv_id
,adr_id
,lead_id
,gender_tx
,event_nm
,event_ts
,match_key_list_tx
,custom_tx
,dw_load_ts
)
 SELECT
  '2062364774033793' -- hardcode provided event set ID
  , 'to_date' AS upload_dt -- we have SQL param 'to_date' getting input date
  , tu_actvn_dt AS dw_eff_dt
  , site_uv_id
  , null
  , null
  , null
  , 'Other'
  , tu_actvn_dt
  , 'extern_id' -- only extern_id is used for match_key
  , '{"reg_cmpltd_page_path_tx":"'|| reg_cmpltd_page_path_tx ||'","reg_rfrl_page_path_tx":"'|| reg_rfrl_page_path_tx ||'","vantage_cr_scr_v3_bkt_nm":"'|| vantage_cr_scr_v3_bkt_nm ||'","reg_device":"'|| reg_device ||'", "age_yr_nr":"'|| age_yr_nr ||'"}' AS custom_tx
  , sysdate
 FROM(
      SELECT a.tu_actvn_dt
        , a.user_id
        , b.site_uv_id
        , a.reg_cmpltd_page_path_tx
        , a.reg_rfrl_page_path_tx
        , a.vantage_cr_scr_v3_bkt_nm
        , a.reg_device
        , date_part_year(current_date) - c.dem_birth_yr_nr as age_yr_nr
      FROM dw_pud_views.dw_user_snap_v a
        JOIN dw_report.dw_identity_site_visitor_xref_d b
      ON a.user_id = b.user_id
        JOIN dw_pud_views.dw_user_d c
      ON a.user_id = c.user_id
      AND c.curr_in = 1
        LEFT OUTER JOIN dw_report.mktg_fb_offline_event_upload_f d
      ON b.site_uv_id = d.site_uv_id
      AND d.offline_event_set_id = '2062364774033793'
      WHERE a.tu_actvn_dt IS NOT null
      AND a.tu_actvn_dt BETWEEN 'to_date' - 7 AND 'to_date'
      AND d.site_uv_id IS null
      GROUP BY 1,2,3,4,5,6,7,8
)
;

