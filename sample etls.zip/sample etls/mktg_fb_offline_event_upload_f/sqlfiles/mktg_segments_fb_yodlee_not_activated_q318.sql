--All Members
delete from dw_report.mktg_fb_offline_event_upload_f
where offline_event_set_id = '2102634543291946';

insert into dw_report.mktg_fb_offline_event_upload_f
(
offline_event_set_id
,dw_upload_dt
,dw_eff_dt
,site_uv_id
,adr_id
,lead_id
,gender_tx
,event_nm
,event_ts
,match_key_list_tx
,custom_tx
,dw_load_ts
)
  SELECT
  '2102634543291946' -- hardcode provided event set ID
  , 'to_date'::date AS upload_dt -- we have SQL param 'to_date' getting input date
  , a.reg_dw_eff_dt AS dw_eff_dt
  , b.site_uv_id
  , null
  , null
  , null
  , 'Other'
  , 'to_date'
  , 'extern_id' -- only extern_id is used for match_key
  , null AS custom_tx -- in this example there's one custom param 'landing_page'
  , sysdate
  FROM dw_pud_views.dw_user_snap_v a
    JOIN dw_report.dw_identity_site_visitor_xref_d b
  ON a.user_id = b.user_id
  WHERE a.nw_acct_status_cd = 'ACTIVE'
  AND a.yd_acct_status_cd = 'NOT ACTIVATED'
  AND a.reg_dw_eff_dt between 'to_date' - 90 AND 'to_date'
;

