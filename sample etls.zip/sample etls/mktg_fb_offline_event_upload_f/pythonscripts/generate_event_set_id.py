import sys

from redshift_modules import load_creds

from facebook_business import FacebookSession
from facebook_business import FacebookAdsApi

# Need to create offline event set only once as part of setup.
# Create new OFFLINE_EVENT_SET_ID based on given event name, 10153528399908502 in url is nerdwallet account ID
# Need app_id, app_secret and access_token
# :param name: str, name of the event
# :param desc: str, description of events

URL = "https://graph.facebook.com/v2.11/10153528399908502/offline_conversion_data_sets"

print "Fetching credentials from chef passwords file"
dwh_chef_credentials_file = str(sys.argv[1])
chef_creds = load_creds(dwh_chef_credentials_file)
fb_app_id = chef_creds['fb_app_id'].replace("'", "")
fb_app_secret = chef_creds['fb_app_secret'].replace("'", "")
fb_access_token = chef_creds['fb_access_token'].replace("'", "")

def fb_offline_event_id_gen(name, desc):
    session = FacebookSession(
            app_id=fb_app_id, app_secret=fb_app_secret, access_token=fb_access_token)
    api = FacebookAdsApi(session)
    api.set_default_api(api)
    params = {
       'name': name,
       'description': desc
    }
    url = URL
    call = api.call('post', url, params=params)
    print call.__dict__

# example of call
#name = 'dwh_engaged_session_metric'
#desc = 'dwh_engaged_session_metric'
#fb_offline_event_id_gen(name, desc)
#
# add generated ID into the sql files
# e.g. OFFLINE_CONVERSION_DATA_SET_ID = '1761457463867001'