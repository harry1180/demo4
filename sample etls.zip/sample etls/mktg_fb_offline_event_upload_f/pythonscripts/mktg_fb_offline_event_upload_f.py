import sys

import json
from redshift_modules import exec_query, load_creds

import hashlib
import datetime
from facebook_business import FacebookSession
from facebook_business import FacebookAdsApi
import pandas as pd
from IPython.display import display
from fb_graph_api import GraphAPI as fb_graph_api

FB_PIXEL_ID = "612184065591075"
EVENT_URL = fb_graph_api.base_url+"{}/events"
UPLOAD_URL = fb_graph_api.base_url+"{}/uploads"

def get_distinct_events():
    sql_qry = """
    select offline_event_set_id, event_nm
    from dw_report.mktg_fb_offline_event_upload_f
    where offline_event_set_id not in ('2102634543291946')
    group by 1, 2;
    """
    dwh_output = exec_query(sql_qry)

    print "number of offline events to upload :" + str(len(dwh_output))
    return dwh_output


def upload_uvs_to_fb(set_id, event_url, upload_url, fb_pixel_id, session, to_date):
    total_counter = 0
    success_counter = 0
    exception_counter = 0

    api = FacebookAdsApi(session)
    api.set_default_api(api)
    sql_qry = """
    select
    site_uv_id as extern_id
    , adr_id as madid
    , lead_id
    , gender_tx as gen
    , offline_event_set_id
    , event_nm
    , date_part(epoch, event_ts) event_time
    , match_key_list_tx
    , custom_tx
    from dw_report.mktg_fb_offline_event_upload_f
    where offline_event_set_id = '{0}'
    and dw_upload_dt = '{1}'
     ;
    """.format(set_id,to_date)

    sql_output_dict = exec_query(sql_qry)
    print "Number of records for event {0} :".format(set_id) + str(len(sql_output_dict))
    event_nm = ''
    for uv in sql_output_dict:
        event_nm = uv['event_nm']

        data = [
            {
                'event_name': event_nm,
                'event_time': int(float(str(uv['event_time'])))
            }
        ]
        # loads match_keys based on key_list_tx and update data, we are hashing all values
        key_list = (uv['match_key_list_tx'].split(','))
        key_cols = {}
        for key in key_list:
            hash_object = hashlib.sha256(uv[key.strip()])
            val = hash_object.hexdigest()
            key_cols.update({key.strip(): val})
        data[0].update({'match_keys': key_cols})

        #loads json format custom params and update data
        if uv['custom_tx']:
            custom_tx = json.loads(uv['custom_tx'])
        else:
            custom_tx = '{}'
        data[0].update({'custom_data': custom_tx})
        #print data
        params = {
            'upload_tag': 'DWH_Upload_' + event_nm + str(datetime.datetime.today().strftime('%Y-%m-%d')),
            'data': data,
            'namespace_id': fb_pixel_id
        }

        try:
            url = event_url
            call = api.call('post', url, params=params)
            success_counter += 1
        except Exception, e:
            exception_counter += 1
            print e
        total_counter += 1

    print "Done"
    print "EVENT_NAME :", event_nm
    print "total_counter :", total_counter
    print "success_counter :", success_counter
    print "exception_counter :", exception_counter

    print "upload stats"
    url = upload_url
    call = api.call('get', url)
    print (call.__dict__).keys()
    data_dict = json.loads(call.__dict__['_body'])
    df = pd.DataFrame(data_dict['data'])
    display(df)


def main():
    print "Fetching credentials from chef passwords file"
    dwh_chef_credentials_file = str(sys.argv[1])
    to_date = sys.argv[2]
    chef_creds = load_creds(dwh_chef_credentials_file)
    fb_app_id = chef_creds['fb_app_id'].replace("'", "")
    fb_app_secret = chef_creds['fb_app_secret'].replace("'", "")
    fb_access_token = chef_creds['fb_access_token'].replace("'", "")

    fb_pixel_id = FB_PIXEL_ID
    session = FacebookSession(app_id=fb_app_id, app_secret=fb_app_secret, access_token=fb_access_token)
    print "FB API session initiated"

    print "Get offline events list to upload"
    event_list = get_distinct_events()

    print "FB Offline upload started..."
    for event in event_list:
        set_id = event['offline_event_set_id']
        event_url = EVENT_URL.format(set_id)
        upload_url = UPLOAD_URL.format(set_id)
        upload_uvs_to_fb(set_id, event_url, upload_url, fb_pixel_id, session, to_date)
    print "FB Offline upload completed..."

if __name__ == '__main__':
    main()
