/* nPK = aflt_network_tran_id 
Load type: Insert New */


INSERT INTO dw_report.dw_aflt_tran_quinstreet_f
(
  aflt_network_tran_id,
  aflt_network_id,
  dw_eff_dt,
  nw_passed_custom_tx,
  dw_site_visitor_id,
  src_site_uv_id,
  click_ts,
  src_click_time_tx,
  src_unique_click_id,
  src_parsed_prod_nm,
  src_parsed_company_nm,
  nw_transaction_id,
  search_type_tx,
  is_mobile_in,
  qs_search_ts,
  src_search_time_tx,
  src_click_id,
  src_nw_srvc_acct_nm,
  src_prod_amount_tx,
  src_prod_nm,
  src_term_nm,
  earning_am,
  dw_load_ts
)
SELECT DISTINCT s.aflt_network_tran_id,
       -16 AS aflt_network_id,
       s.parsed_search_time_tx::DATE AS dw_eff_dt,
       s.nw_passed_custom_tx,
       sv.dw_site_visitor_id,
       s.src_site_visitor_tx,
       CASE
         WHEN len (s.parsed_click_time_tx) = 19 THEN s.parsed_click_time_tx::TIMESTAMP
         ELSE NULL
       END,
       s.click_time_tx,
       s.src_unique_click_id,
       s.parsed_prod_nm AS src_parsed_prod_nm,
       s.parsed_company_nm src_parsed_company_nm,
       s.nw_transaction_id AS nw_transaction_id,
       s.search_type_tx,
       s.is_mobile_in,
       TRIM(s.parsed_search_time_tx)::TIMESTAMP AS qs_search_ts,
       s.search_time_tx,
       s.src_click_id,
       s.src_nw_srvc_acct_nm,
       s.src_prod_amount_tx,
       s.src_prod_nm,
       s.src_term_nm,
       CASE
         WHEN s.earning_am = '' THEN 0.0
         WHEN s.earning_am IS NULL THEN 0.0
         ELSE CAST(s.earning_am AS decimal(10,4))
       END,
       getdate() AS dw_load_ts
FROM (SELECT aflt_network_tran_id,
             nw_passed_custom_tx,
             src_site_visitor_tx,
             src_unique_click_id,
             parsed_prod_nm,
             parsed_company_nm,
             nw_transaction_id,
             search_type_tx,
             is_mobile_in,
             search_time_tx,
             parsed_search_time_tx,
             src_click_id,
             click_time_tx,
             parsed_click_time_tx,
             src_nw_srvc_acct_nm,
             src_prod_amount_tx,
             src_prod_nm,
             src_term_nm,
             earning_am,
             ROW_NUMBER() OVER (PARTITION BY aflt_network_tran_id ORDER BY parsed_search_time_tx DESC) AS row_num
      FROM dw_stage.dw_aflt_tran_quinstreet_s) AS s
  LEFT JOIN dw_report.dw_aflt_tran_quinstreet_f trgt ON s.aflt_network_tran_id = trgt.aflt_network_tran_id
  LEFT JOIN (SELECT dw_site_visitor_id,
                    site_uv_id
             FROM dw_report.site_visitor_d
             GROUP BY 1,
                      2) AS sv ON s.src_site_visitor_tx = sv.site_uv_id
WHERE trgt.aflt_network_tran_id IS NULL
AND   s.row_num = 1;

