import os
import sys
import csv

if __name__ == '__main__':
    infolder='/data/etl/Data/aflt_tran_quinstreet/input/'
    for infile in os.listdir(infolder):
        with open(infolder+infile,'rb') as f:
            freader =  csv.reader(f, delimiter='|')
            for rows in freader:
                print '%s row count %d' %(infile, len(rows))

