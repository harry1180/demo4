import os
import sys
import csv

# in row: dw_eff_Dt, custom_tx, custom_tx, prod_nm, deevice_nm, page_view_ct, clicks_ct, ctr_tx, earning_am, cpc_am, ecpm_tx, quality_tx
#   	   0		1	 2		3	4	5		6	7	8		9	10	11

## outrow:
## dw_eff_Dt, custom_tx, uv, click_tx, prod_id, cmpny, prod_nm, device_nm, page_view_ct, clicks_ct, ctr_num, earning_am, cpc_am, ecpm_tx, quality_tx

infolder='/data/etl/Data/aflt_tran_quinstreet/input/'
outfolder='/data/etl/Data/aflt_tran_quinstreet/output/'
 	
def text_to_num(text_in):
    chars=['$',',','%',' ']
    for char in chars: 
        text_in = text_in.replace(char,'')
    return text_in

def parse_custom_tx(custom_tx):
    uv =''
    click_tx =''
    prod_id = ''
    cmpny = ''
    if len(custom_tx) == 8:
        return([custom_tx, click_tx, prod_id, cmpny])
    else:
        parts=custom_tx.split('-')
        if len(parts) == 3:
            if len(parts[0]) == 8:
                return([parts[0],click_tx, parts[1], parts[2]])
            else:
                return([uv, parts[0], parts[1], parts[2]])
        if len(parts) == 2:
            if len(parts[0]) == 8:
                return([parts[0],click_tx, parts[1], cmpny])
            else:
                return([uv, parts[0], parts[1], cmpny])
        else: 
            return([uv, click_tx, prod_id, cmpny])

       
if __name__ == '__main__':
    for infile in os.listdir(infolder):
        with open(infolder+infile,'rb') as fr:
            freader =  csv.reader(fr, delimiter='|')
            with open(outfolder+infile,'wr') as fw:
                fwriter = csv.writer(fw, delimiter = '|')
                for row in freader:
                    if len(row) == 12:
                     #print '%s row count %d' %(infile, len(rows))
                        fwriter.writerow([row[0], row[1]]+ parse_custom_tx(row[1]) + [row[3], row[4], text_to_num(row[5]), text_to_num(row[6]), text_to_num(row[7]),
                               text_to_num(row[8]), text_to_num(row[9]), text_to_num(row[10]), text_to_num(row[11])])
                     

