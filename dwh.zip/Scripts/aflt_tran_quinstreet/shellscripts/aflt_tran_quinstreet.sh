


job_name='aflt_tran_quinstreet'



job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
File_Search="SupplierDaily"
source_bucket=$Events_dwh_bucket
aflt_tran_id=-16
echo 'File_Search               :-   '${File_Search}
echo 'source_bucket             :-   '${source_bucket}
echo 'aflt_tran_id              :-   '${aflt_tran_id}
echo '+----------+----------+----------+----------+----------+----------+'



bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Removing Data Files" "Started"
find $Linux_Input -name \*.txt -exec rm {} \; || true
find $Linux_Output -name \*.txt -exec rm {} \; || true
find $Linux_Output -name \*.gz -exec rm {} \; || true
echo_processing_step ${job_name} "Removing Data Files" "Completed" 

echo_processing_step ${job_name} "Removing S3 Files" "Started"
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Output','$source_bucket','*gz')" || true
echo_processing_step ${job_name} "Removing S3 Files" "Completed"

echo_processing_step ${job_name} "Downloading the file to local" "Started"
python -c "from s3_modules import s3_file_download_wildcard_search; s3_file_download_wildcard_search('$source_bucket','${S3_Events_Input}','${File_Search}','$Linux_Input','${S3_Events_Archive}')" || true
echo_processing_step ${job_name} "Downloading the file to local" "Completed"

echo_processing_step ${job_name} "Calling Python script to parse the data" "Started"
echo "______________"$Processing_Step"______________"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/parse_qs_file_new.py $Linux_Input $Linux_Output
echo_processing_step ${job_name} "Calling Python script to parse the data" "Completed"

echo_processing_step ${job_name} "Gzip and Moving to S3" "Started"
  for f in ${Linux_Output}*.txt
  do
  gzip $f 
  gzip_file=${f}.gz
  python -c "from s3_modules import s3_file_upload; s3_file_upload('${gzip_file}', '$source_bucket', '$S3_Events_Output', s3_file_nm='default')" || true
  done
echo_processing_step ${job_name} "Gzip and Moving to S3" "Completed"

echo_processing_step ${job_name} "Delete data from post Stage table" "Started"
query_stage_delete="truncate table dw_stage.dw_aflt_tran_quinstreet_s;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Delete data from post Stage table" "Started"

echo_processing_step ${job_name} "Copy supplier data to stage table" "Started"
bash ${dwh_common_base_dir}/redshift_copy_function_delim.sh dw_stage.dw_aflt_tran_quinstreet_s /aflt_tran_quinstreet/output/ supplier  '|'  'header'
echo_processing_step ${job_name} "Copy supplier data to stage table" "Started"

echo_processing_step ${job_name} "Copy NerdWallet data to stage table" "Started"
bash ${dwh_common_base_dir}/redshift_copy_function_delim.sh dw_stage.dw_aflt_tran_quinstreet_s /aflt_tran_quinstreet/output/ NerdWallet  '|'  'header' || true
echo_processing_step ${job_name} "Copy NerdWallet data to stage table" "Started"

echo_processing_step ${job_name} "Copy nerdwallet data to stage table" "Started"
bash ${dwh_common_base_dir}/redshift_copy_function_delim.sh dw_stage.dw_aflt_tran_quinstreet_s /aflt_tran_quinstreet/output/ nerdwallet  '|'  'header' || true
echo_processing_step ${job_name} "Copy nerdwallet data to stage table" "Started"

echo_processing_step ${job_name} "Loading data to target fact table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/aflt_tran_quinstreet_load.sql
echo_processing_step ${job_name} "Loading data to target fact table" "Started"

echo_processing_step ${job_name} "Running Vacuum and Analyze" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/aflt_tran_quinstreet_analyze.sql
echo_processing_step ${job_name} "Running Vacuum and Analyze" "Started"

echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Started"
python -c "from tran_log_modules import insert_log; insert_log($aflt_tran_id);"
echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Completed"

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

