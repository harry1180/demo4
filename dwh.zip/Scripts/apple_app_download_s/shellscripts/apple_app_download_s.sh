job_name='apple_app_download_s'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_chef_credentials_file_dir}/passwords.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
	echo "App download error message" $response
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'

if [ -z $1 ] ; then
  from_date="$(date -d '-4 days' '+%Y%m%d')"
else
  from_date="$1"
fi 

if [ -z $2 ] ; then
  to_date="$(date -d '-1 days' +'%Y%m%d')"
else
  to_date="$2"
fi

input_date="$(date +'%Y%m%d%H%M%S')"
output_file="apple_app_download_s"

echo 'from_date                  :-   '${from_date}
echo 'to_date                    :-   '${to_date}
echo 'input_date                    :-   '${input_date}

echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning dwh S3 files" "Started"
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Output','$Events_dwh_bucket','apple_app_download_s*')" || true
echo_processing_step ${job_name} "Cleaning dwh S3 files" "Completed"

echo_processing_step ${job_name} "Cleaning local files" "Started"
find $Linux_Input   -name \*app_download\* -exec rm {} \; || true
find $Linux_Output  -name \*app_download\* -exec rm {} \; || true
find $Linux_Archive -name \*app_download\* -exec rm {} \; || true
echo_processing_step ${job_name} "Cleaning local files" "Completed"

cp /etc/dwh_secured_tokens/Reporter.jar .
cp /etc/dwh_secured_tokens/Reporter.properties .

d="$from_date"
while [ "$to_date" -ge  "$d" ]; do
    echo_processing_step ${job_name} "Download data " "Started"
    
    response=`java -jar Reporter.jar p=Reporter.properties m=Normal  Sales.getReport  $apple_vendor_id, Sales, Summary, Daily, $d`
    
    echo 'App download message: ' $response
    #cp S_D_85708938_$from_date* ${Linux_Output}${output_file}
    cp S_D_"$apple_vendor_id"_"$d"* ${Linux_Output}${output_file}.gz
     
    echo_processing_step ${job_name} "Download data " "Completed"
    
    
    echo_processing_step ${job_name} "Compress and move data to s3" "Started"
    python -c "from s3_modules import s3_file_upload; s3_file_upload('${Linux_Output}${output_file}.gz', '$Events_dwh_bucket', '$S3_Events_Output','${output_file}_${d}.gz')" || true
    python -c "from s3_modules import s3_file_upload; s3_file_upload('${Linux_Output}${output_file}.gz', '$Events_dwh_bucket', '$S3_Events_Archive','${output_file}_${d}_${input_date}.gz')" || true
    echo_processing_step ${job_name} "Compress and move data to s3" "Completed"
    d=`date '+%C%y%m%d' -d "$d+1 days"`
done

echo_processing_step ${job_name} "Loading data file into Redshift stage table" "Started"

query_stage_delete="delete from dw_stage.apple_app_download_s ;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"

copy_query="copy dw_stage.apple_app_download_s
from 's3://"$Events_dwh_bucket"/"$job_name"/output/"$job_name"' 
credentials '$s3_prod_load_creds' gzip delimiter '\t' dateformat 'auto' NULL AS 'NULL' 
ACCEPTINVCHARS 
COMPUPDATE OFF
STATUPDATE OFF
BLANKSASNULL 
IGNOREHEADER  AS 1
EMPTYASNULL
TIMEFORMAT 'auto';
"

psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$copy_query"


echo_processing_step ${job_name} "Loading data file into Redshift stage table" "Completed"

echo_processing_step ${job_name} "Cleaning up files" "Started"
find  /etc/dwh_secured_tokens -name \*S_D_85708938*\* -exec rm {} \; || true
echo_processing_step ${job_name} "Cleaning up files" "Completed"
 

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
