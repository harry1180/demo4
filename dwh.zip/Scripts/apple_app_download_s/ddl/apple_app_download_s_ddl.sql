create table dw_stage.apple_app_download_s
(
Provider                                  VARCHAR(100),
Provider_Country                                  VARCHAR(100),
SKU                                  VARCHAR(100),
Developer                                  VARCHAR(100),
Title                                  VARCHAR(1000),
Version                                  VARCHAR(10),
Product_Type_Identifier                                  VARCHAR(10),
Units                                  BIGINT,
Developer_Proceeds                                  DECIMAL(18,5),
Begin_Date                                  DATE,
End_Date                                 DATE,
Customer_Currency                                  VARCHAR(10),
Country_Code                                  VARCHAR(2),
Currency_of_Proceeds                                  VARCHAR(10),
Apple_Identifier                                 BIGINT,
Customer_Price                                  DECIMAL(18,5),
Promo_Code                                  VARCHAR(100),
Parent_Identifier                                  BIGINT,
Subscription                                  VARCHAR(100),
Period                                  VARCHAR(100),
Category                                  VARCHAR(100),
CMB                                  VARCHAR(10),
Device                                  VARCHAR(100),
Supported_Platforms                                  VARCHAR(100),
Proceeds_Reason                                  VARCHAR(100),
Preserved_Pricing                                  VARCHAR(100),
Client                                  VARCHAR(500)
)
distkey(Apple_Identifier);

