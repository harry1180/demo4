source /data/etl/Scripts/aflt_tran_commission_codes/shellscripts/parm_commission_codes.ctrl

#######################################
#Main Script
######################################
input_date="$(date +'%Y%m%d%H%M%S')"
#Delete Files if files exist in Directory. The below deletes are for safety if the script fails in between then we dont need any manual deletions
rm -f $Linux_Input*clicks*
rm -f $S3_Input*.csv.gz
#Function to pull mysql data to the linux input it takes 2 inputs 1) sql file and 2) path and the file name to place the records
bash /data/etl/Common/mysql_linux_copy_function.sh /data/etl/Scripts/aflt_tran_commission_codes/sqlfiles/aflt_tran_commission_codes.sql /data/etl/Data/aflt_tran_commission_codes/aflt_commission_codes.csv

#removing the cnt file temporarily until the sql's are run using data parameters
rm -f $Linux_Input*commission*.cnt
#gzip the output file
gzip /data/etl/Data/aflt_tran_commission_codes/aflt_commission_codes.csv
#move the gzip file to the s3 input
mv /data/etl/Data/aflt_tran_commission_codes/aflt_commission_codes.csv.gz /s3mnt-dwh-staging/aflt_tran_commission_codes/
#changing the permissions of the gz file
chmod 775 /s3mnt-dwh-staging/aflt_tran_commission_codes/aflt_commission_codes.csv.gz
chgrp etl /s3mnt-dwh-staging/aflt_tran_commission_codes/aflt_commission_codes.csv.gz

#delete the data from the staging table before reloading it
query_stage_delete="delete from dw_stage.aflt_tran_commission_codes_s;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"

#copy command to move the processed file to the redshift staging table
bash /data/etl/Common/redshift_copy_function.sh dw_stage.aflt_tran_commission_codes_s /aflt_tran_commission_codes/ aflt_commission
