SELECT 
affiliate, code, fieldname, fieldval, category, id
FROM
nwallet_analytics.commission_codes;
