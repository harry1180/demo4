truncate :stagedb.click_event_post_s ;
