
insert into :stagedb.click_event_post_s
(
  cookieid
, environment
, eventname
, guid
, ip
, pageviewid
, dw_pageviewid
, dw_src_sys_id
, "timestamp"
, url
, useragent
, userid
, usertype
, impressionid
, productid
, productslug
, productlocation
, category
, sponsored
, monetizing
, productposition
, sectionposition
, pagenumber
, productinstance
, linktype
, uniqueclickid
, affiliateid
, zdw_user_agent
, zzz_new_url
, zzz_parse_netloc
, zzz_parse_path
, zzz_parse_scheme
, zzz_validated_netloc
, zzz_validated_path
, zzz_validated_scheme
, zzz_validated_url
, zzz_validated_query
)
select
  trim(stg.cookieid)
, stg.environment
, stg.eventName as eventname
, stg.guid
, stg.ip
, trim(stg.pageviewid)
, trim(stg.pageviewid)   as dw_pageviewid
, 2    as dw_src_sys_id  -- Brokerage
, stg."timestamp"  as "timestamp"
, stg.url
, stg.useragent
, stg.userid
, stg.usertype
, trim(stg.impressionid)
, stg.productid
, stg.productslug
, stg.productlocation
, stg.category
, case 
    when lower(stg.sponsored) = 'true'  or lower(stg.sponsored) = 't' then 1 
    when lower(stg.sponsored) = 'false' or lower(stg.sponsored) = 'f' then 0
    else null
  end                   as sponsored
, case 
    when lower(stg.monetizing) = 'true'  or lower(stg.monetizing) = 't' then 1
    when lower(stg.monetizing) = 'false' or lower(stg.monetizing) = 'f' then 0
    else null
  end                   as monetizing
, cast(stg.productposition as integer) as productposition
, cast(stg.sectionposition as integer) as sectionposition
, cast(stg.pagenumber      as integer) as pagenumber
, stg.productinstance
, stg.linktype
, stg.uniqueclickid
, stg.affiliateid
, stg.zdw_user_agent
, stg.zzz_new_url
, stg.zzz_parse_netloc
, stg.zzz_parse_path
, stg.zzz_parse_scheme
, stg.zzz_validated_netloc
, stg.zzz_validated_path
, stg.zzz_validated_scheme
, stg.zzz_validated_url
, stg.zzz_validated_query
from 
  dw_stage.click_event_investing_s stg
where length(coalesce(trim(stg.cookieid), ''))     < 45
  and length(coalesce(trim(stg.pageviewid), ''))   < 45
  and length(coalesce(trim(stg.impressionid), '')) < 45 
;
