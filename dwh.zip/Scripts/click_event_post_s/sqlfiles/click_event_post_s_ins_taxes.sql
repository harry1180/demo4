INSERT INTO :stagedb.click_event_post_s
(
  cookieid,
  environment,
  eventname,
  guid,
  ip,
  pageviewid,
  dw_pageviewid,
  dw_src_sys_id,
  TIMESTAMP,
  url,
  useragent,
  userid,
  usertype,
  impressionid,
  productid,
  productslug,
  productlocation,
  category,
  sponsored,
  monetizing,
  productposition,
  sectionposition,
  pagenumber,
  productinstance,
  linktype,
  uniqueclickid,
  affiliateid,
  zdw_user_agent,
  zzz_new_url,
  zzz_parse_netloc,
  zzz_parse_path,
  zzz_parse_scheme,
  zzz_validated_netloc,
  zzz_validated_path,
  zzz_validated_scheme,
  zzz_validated_url,
  zzz_validated_query
)
SELECT trim(cookieid),
       environment,
       eventname,
       guid,
       ip,
       trim(pageviewid),
       trim(pageviewid),
       9 as dw_src_sys_id,
       event_timestamp AS src_timestamp,
       url,
       useragent,
       userid,
       usertype,
       trim(impressionid),
       productid,
       productslug,
       productlocation,
       category,
 case 
   when lower(stg.sponsored) = 'true'  or lower(stg.sponsored) = 't' then 1 
   when lower(stg.sponsored) = 'false' or lower(stg.sponsored) = 'f' then 0
   else null
 end                   as sponsored
, case 
   when lower(stg.monetizing) = 'true'  or lower(stg.monetizing) = 't' then 1
   when lower(stg.monetizing) = 'false' or lower(stg.monetizing) = 'f' then 0
   else null
 end                   as monetizing,
       productposition :: INTEGER,
       sectionposition :: INTEGER,
       pagenumber :: INTEGER,
       productinstance,
       linktype,
       uniqueclickid,
       affiliateid,
       zdw_user_agent,
       zzz_new_url,
       zzz_parse_netloc,
       zzz_parse_path,
       zzz_parse_scheme,
       zzz_validated_netloc,
       zzz_validated_path,
       zzz_validated_scheme,
       zzz_validated_url,
       zzz_validated_query
FROM 
dw_stage.click_event_taxes_s stg 
where length(coalesce(trim(stg.cookieid), ''))     < 45
  and length(coalesce(trim(stg.pageviewid), ''))   < 45
  and length(coalesce(trim(stg.impressionid), '')) < 45 
;
