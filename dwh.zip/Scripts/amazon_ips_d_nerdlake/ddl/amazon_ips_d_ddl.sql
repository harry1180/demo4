DROP TABLE IF EXISTS dwnl_data.amazon_ips_d;
CREATE TABLE dwnl_data.amazon_ips_d (
     amazon_ip                          string,
     service_nm                         array<string>
)
STORED AS ORC
LOCATION 's3://east1-prod-nerdlake-0/dwnl_data/amazon_ips_d/'
;
