DELETE FROM hive.dwnl_data.amazon_ips_d;

INSERT INTO hive.dwnl_data.amazon_ips_d
( amazon_ip, service_nm )
SELECT amazon_ip, NULLIF(array_remove(array_agg(service_nm), 'AMAZON'), ARRAY[])
FROM hive.dwnl_stage.amazon_ips_s
WHERE amazon_ip IS NOT NULL
GROUP BY amazon_ip;
