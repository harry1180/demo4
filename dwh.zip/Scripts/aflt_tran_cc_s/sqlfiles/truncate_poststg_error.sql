DELETE FROM dw_stage.aflt_tran_cc_error;
