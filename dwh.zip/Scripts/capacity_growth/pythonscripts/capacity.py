#######################################################################################
#
# This script will be executed weekly to get the 7-day and 30-day growth rate for 
# top 30 tables in ('dw_report', 'dw_stage', 'dw_ba_report')  
#
# usage: python capacity.py cap_q1.sql cap_q2.sql cap_q3.sql cap_q4.sql cap_q5.sql cap_q6.sql
#
#######################################################################################
import os, sys
from redshift_modules import exec_query 

if len(sys.argv) != 7:
   print 'usage: python capacity.py cap_q1.sql cap_q2.sql cap_q3.sql cap_q4.sql cap_q5.sql cap_q6.sql'
   sys.exit(1)

with open (sys.argv[1], 'r') as sql1:
   query1 = sql1.read()
 
exec_query(query1, DB='redshift', user='superuser')

with open (sys.argv[2], 'r') as sql2:
   run_query2 = sql2.read()
print run_query2
list_of_dicts = exec_query(run_query2, DB='redshift', user='superuser')

# print list_of_dicts;

with open (sys.argv[3], 'r') as sql3:
  query3 = sql3.read()

for dic in list_of_dicts:
  run_query3 = query3.format(v_schema=dic['schema'], v_tablename=dic['tablename'])
  print run_query3
  exec_query(run_query3, DB='redshift', user='superuser')

with open (sys.argv[4], 'r') as sql4:
  query4 = sql4.read()

for dic in list_of_dicts:
  run_query4 = query4.format(v_schema=dic['schema'], v_tablename=dic['tablename'])
  try:
    exec_query(run_query4, DB='redshift', user='superuser')
  except:
    try:
      with open (sys.argv[6], 'r') as sql6:
        query6 = sql6.read() 
      run_query6 = query6.format(v_schema=dic['schema'], v_tablename=dic['tablename'])
      exec_query(run_query6, DB='redshift', user='superuser')
    except:
      print "%s.%s DID NOT WORK"%(dic['schema'], dic['tablename'])

  with open (sys.argv[5], 'r') as sql5:
    query5 = sql5.read()

  exec_query(query5, DB='redshift', user='superuser')

