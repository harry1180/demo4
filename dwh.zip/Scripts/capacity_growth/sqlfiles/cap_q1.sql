insert into  dw_dba.capacity_plan_top32
  select schema, "table" as tablename, size as size_MB, tbl_rows, (size*1024*1024/tbl_rows) as avg_row_len, null, null, null, null, current_date
  from svv_table_info where schema in ('dw_report', 'dw_stage', 'dw_ba_report') and "table" not like '%_f_%'
  order by size desc 
  limit 32;
