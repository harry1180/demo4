select schema, tablename from dw_dba.capacity_plan_top32 where dw_eff_dt = current_date
