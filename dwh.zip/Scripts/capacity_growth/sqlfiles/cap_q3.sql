update dw_dba.capacity_plan_top32 
    set tbl_rows    = (select count(*) from "{v_schema}"."{v_tablename}" )
    where schema='{v_schema}' and tablename = '{v_tablename}'
