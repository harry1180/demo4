update dw_dba.capacity_plan_top32 set
    rows_7_day      = (select count(*) from "{v_schema}"."{v_tablename}"  where dw_eff_dt>= dateadd(day, -7, current_date)),
    rows_30_day     = (select count(*) from "{v_schema}"."{v_tablename}"  where dw_eff_dt>= dateadd(day, -30, current_date))
    where schema='{v_schema}' and tablename = '{v_tablename}'
