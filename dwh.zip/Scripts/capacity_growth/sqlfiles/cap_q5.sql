update dw_dba.capacity_plan_top32  
    set grow_pct_7_day  = (case when tbl_rows = rows_7_day  then 0 else 100*rows_7_day/(tbl_rows - rows_7_day)::decimal(15,4) end),
        grow_pct_30_day = (case when tbl_rows = rows_30_day then 0 else 100*rows_30_day/(tbl_rows - rows_30_day)::decimal(15,4) end)   
    where rows_7_day is not null and rows_30_day is not null
