select
        distinct NULL  AS src_prod_id,
        8 AS src_sys_id,
                concat(trim(nwallet_analytics.clicks_rates.InstitutionName),
                trim(nwallet_analytics.clicks_rates.CertNumber),
                trim(nwallet_analytics.clicks_rates.InstitutionType),
                trim(nwallet_analytics.clicks_rates.Instrumenttype),
                trim(nwallet_analytics.clicks_rates.LengthofTerm)) AS slug_tx,
        trim(nwallet_analytics.clicks_rates.InstitutionName),
                trim(nwallet_analytics.clicks_rates.CertNumber),
                trim(nwallet_analytics.clicks_rates.InstitutionType),
                trim(nwallet_analytics.clicks_rates.Instrumenttype),
                trim(nwallet_analytics.clicks_rates.LengthofTerm),
        NULL as prod_nm 
    from
        nwallet_analytics.clicks_rates
where length(trim(nwallet_analytics.clicks_rates.InstitutionName)) < 200
     		and length(lengthofterm) < 10
		and length(Instrumenttype) < 10
		and length(InstitutionType) < 10
		and trim(lengthofterm) not like '%\\t%'
	 	and trim(lengthofterm) not like '%=%'; 
