INSERT INTO dw_report.banking_prod_xref_d
(
  dw_site_prod_sk,
  dw_src_sys_id,
  dw_eff_dt,
  dw_slug_tx,
  institution_nm,
  cert_nr_tx,
  instituition_type_cd,
  instrument_type_cd,
  length_of_term_tx,
  src_prod_nm,
  dw_load_ts
)
SELECT prod.dw_site_prod_sk,
       s.dw_src_sys_id,
       getdate() AS dw_eff_dt,
       s.dw_slug_tx,
       s.institution_nm,
       s.cert_nr_tx,
       s.instituition_type_cd,
       s.instrument_type_cd,
       s.length_of_term_tx,
       s.src_prod_nm,
       getdate() AS dw_load_ts
FROM dw_stage.banking_prod_xref_s s
	left join (select max(dw_site_prod_sk) as dw_site_prod_sk, dw_slug_tx from dw_report.dw_prod_d group by 2) as prod
	on s.dw_slug_tx = prod.dw_slug_tx
 ;
