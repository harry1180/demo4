DELETE FROM dw_stage.aflt_tran_edu_loan_error;
