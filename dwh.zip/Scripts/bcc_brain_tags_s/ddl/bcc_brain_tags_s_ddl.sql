
drop   table dw_stage.bcc_brain_tags_s;

CREATE TABLE dw_stage.bcc_brain_tags_s  
(  
id             BIGINT , 
tag_type       BIGINT , 
change_number  BIGINT , 
name           varchar(255)  ,
description    varchar(2000)  ,
start_date     TIMESTAMP , 
end_date       TIMESTAMP , 
user_id        BIGINT , 
created_at     TIMESTAMP , 
updated_at     TIMESTAMP , 
min_categories BIGINT , 
max_categories BIGINT  
)  
distkey (id) ;

GRANT ALL  ON dw_stage.bcc_brain_tags_s TO GROUP grp_etl;


