SELECT 
  id            
, tag_type       
, change_number  
, name           
, description    
, start_date     
, end_date       
, user_id        
, created_at     
, updated_at     
, min_categories 
, max_categories 
FROM
  bcc_app.tags;
;

