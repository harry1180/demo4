UPDATE dw_report.dw_aflt_tran_consolidated_f
  SET commission_am = bank.commission_am,
      revenue_tran_in = CASE WHEN bank.revenue_tran_in IS TRUE THEN 'True' ELSE 'False' END,
      dw_last_updt_ts = bank.dw_last_updt_ts,
      dw_last_updt_tx = bank.dw_last_updt_tx
FROM dw_report.dw_aflt_tran_banking_f bank
  WHERE   COALESCE(dw_report.dw_aflt_tran_consolidated_f.aflt_network_tran_id, 'XXXX') = COALESCE(bank.aflt_network_tran_id, 'XXXX')
  AND (
          COALESCE(dw_report.dw_aflt_tran_consolidated_f.commission_am, 0) <> COALESCE(bank.commission_am, 0)
       OR COALESCE(dw_report.dw_aflt_tran_consolidated_f.revenue_tran_in, 'False') <> COALESCE(CASE WHEN bank.revenue_tran_in IS TRUE THEN 'True' ELSE 'False' END, 'False')
      )
  AND (
          bank.dw_load_ts >= date_trunc('month', current_date) - '2 month'::interval
       OR bank.dw_last_updt_ts >= date_trunc('month', current_date) - '2 month'::interval
      )
;
