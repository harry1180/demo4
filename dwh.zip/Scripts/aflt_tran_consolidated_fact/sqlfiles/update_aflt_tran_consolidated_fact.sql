UPDATE dw_report.dw_aflt_tran_consolidated_f
   SET commission_am = b.commision_am, merchant_am = b.merchant_am
  FROM dw_stage.dw_aflt_tran_consolidated_post_stg b
 WHERE     dw_report.dw_aflt_tran_consolidated_f.aflt_network_tran_id =
              b.aflt_network_tran_id
       AND dw_report.dw_aflt_tran_consolidated_f.aflt_network_id =
              b.aflt_network_id
			  and COALESCE(dw_report.dw_aflt_tran_consolidated_f.commission_am, -99999) <> COALESCE(b.commision_am, -99999)
			  and COALESCE(dw_report.dw_aflt_tran_consolidated_f.merchant_am, -99999) <> COALESCE(b.merchant_am, -99999)
			  and dw_report.dw_aflt_tran_consolidated_f.aflt_network_id in (4, 8, 9, -15, 14)
			  and dw_report.dw_aflt_tran_consolidated_f.src_sys_id not in (8);
