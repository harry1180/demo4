analyze dw_report.dw_aflt_tran_consolidated_f;

Drop table if exists tmp_dw_clicks_event_f;
create temp table tmp_dw_clicks_event_f
DISTSTYLE KEY
DISTKEY ( src_unique_click_id )
SORTKEY ( dw_eff_dt )
as
Select user_id,dw_click_id,dw_src_sys_id,dw_site_visitor_id,click_utc_ts,dw_session_id,dw_page_sk,dw_user_agent_id,dw_site_prod_sk,src_unique_click_id,dw_eff_dt,dw_imprsn_id,dw_suspected_bot_in,dw_page_view_id,logged_ip,dw_url_sk from dw_report.dw_clicks_event_f where dw_eff_dt>sysdate-300;
analyze tmp_dw_clicks_event_f;

UPDATE dw_report.dw_aflt_tran_consolidated_f
set dw_click_id = b.dw_click_id
       ,user_id = b.user_id
       ,dw_click_src_id = b.dw_src_sys_id
       ,dw_site_visitor_id = b.dw_site_visitor_id
       ,src_clicks_utc_ts = b.click_utc_ts
       ,nw_click_dt  = trunc(b.click_utc_ts)
       ,dw_session_id =     b.dw_session_id
       ,dw_click_page_sk     = COALESCE(b.dw_page_sk,-1)
       ,dw_click_user_agent_id = COALESCE(b.dw_user_agent_id,1)
       ,dw_site_prod_sk = COALESCE(b.dw_site_prod_sk,'-999999999')
       ,dw_imprsn_id = COALESCE(b.dw_imprsn_id,'-999999999')
       ,dw_page_view_id = b.dw_page_view_id
       ,logged_ip = b.logged_ip
       ,dw_url_sk              = coalesce(b.dw_url_sk, -1) 
       ,dw_suspected_bot_in    = case when b.dw_suspected_bot_in is null or trim(b.dw_suspected_bot_in)='' then 'False' else b.dw_suspected_bot_in end
       ,dw_last_updt_ts        = sysdate
       ,dw_last_updt_tx        = 'update user, click, session and page columns-final update'
from tmp_dw_clicks_event_f b
where dw_report.dw_aflt_tran_consolidated_f.src_unique_click_id = b.src_unique_click_id and dw_report.dw_aflt_tran_consolidated_f.dw_eff_dt>sysdate-360;

UPDATE dw_report.dw_aflt_tran_consolidated_f
set src_sys_id= b.dw_src_sys_id
from tmp_dw_clicks_event_f b
where dw_report.dw_aflt_tran_consolidated_f.src_unique_click_id = b.src_unique_click_id and dw_report.dw_aflt_tran_consolidated_f.dw_eff_dt>sysdate-360 and dw_report.dw_aflt_tran_consolidated_f.src_sys_id is null
and dw_report.dw_aflt_tran_consolidated_f.src_sys_id not in (8);

Update dw_report.dw_aflt_category_map
set src_sys_id=b.src_sys_id
from (select src_prod_nm,prog_nm,aflt_catg_nm,src_sys_id from dw_report.dw_aflt_tran_consolidated_f group by 1,2,3,4) b
where b.src_prod_nm = dw_report.dw_aflt_category_map.src_aflt_prod_nm AND b.prog_nm = dw_report.dw_aflt_category_map.src_aflt_prog_nm AND b.aflt_catg_nm = dw_report.dw_aflt_category_map.src_aflt_catg_nm and dw_report.dw_aflt_category_map.src_sys_id is null;


Update dw_report.dw_aflt_tran_consolidated_f
Set dw_suspected_bot_in='False',
dw_last_updt_ts=sysdate,
dw_last_updt_tx='update bot in'
where dw_click_id is null and dw_suspected_bot_in is null;

UPDATE dw_report.dw_aflt_tran_consolidated_f
  SET dw_site_prod_nm = COALESCE(b.prod_nm,'Could not Identify the right product to this Transaction')
  from (select * from dw_report.dw_prod_d where curr_in = 1) b
  where dw_report.dw_aflt_tran_consolidated_f.dw_site_prod_sk = b.dw_site_prod_sk
  and dw_report.dw_aflt_tran_consolidated_f.dw_eff_dt > '2015-10-31'
  and dw_report.dw_aflt_tran_consolidated_f.src_sys_id not in (8);

update dw_report.dw_aflt_tran_consolidated_f
set  page_vertical_tx       = coalesce(b.page_vertical_tx, 'Other')
    ,page_topic_tx          = coalesce(b.page_topic_tx, 'Other')
   	,dw_last_updt_ts        = sysdate
    ,dw_last_updt_tx        = 'update page vertical and topic'
from dw_report.dw_url_d b
where dw_report.dw_aflt_tran_consolidated_f.page_vertical_tx is null
  and dw_report.dw_aflt_tran_consolidated_f.dw_url_sk = b.dw_url_sk
;

Update dw_report.dw_aflt_tran_consolidated_f
set dw_eff_dt= COALESCE(nw_click_dt, tran_click_dt, tran_post_dt)
where dw_report.dw_aflt_tran_consolidated_f.dw_eff_dt>sysdate-360
and dw_report.dw_aflt_tran_consolidated_f.src_sys_id not in (8);
