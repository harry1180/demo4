CREATE TABLE dw_report.dw_aflt_tran_consolidated_snapshot_f
(
  aflt_network_tran_id	    varchar(256)     encode lzo
, aflt_network_id	        integer          encode lzo
, aflt_fin_tran_type_cd	    varchar(256)     encode lzo
, dw_eff_dt	                date             encode lzo
, nw_click_dt	            date             encode lzo
, tran_rev_rlzd_dt	        date             encode lzo
, tran_post_dt	            date             encode delta
, tran_click_dt	            date             encode lzo
, tran_post_ts	            timestamp        encode lzo
, tran_click_ts	            timestamp        encode lzo
, src_clicks_utc_ts	        timestamp        encode lzo
, src_prod_nm	            varchar(256)     encode lzo
, dw_site_visitor_id	    bigint           encode lzo
, dw_site_prod_sk	        varchar(256)     encode lzo
, dw_site_prod_nm	        varchar(256)     encode lzo
, prog_nm	                varchar(256)     encode lzo
, src_unique_click_id	    varchar(256)     encode lzo
, aflt_catg_nm	            varchar(256)     encode lzo
, dw_click_id	            varchar(1000)    encode lzo
, dw_click_src_id	        integer          encode lzo
, src_sys_id	            integer          encode lzo
, user_id                   varchar(256)     encode lzo
, dw_session_id	            varchar(120)     encode lzo
, dw_page_view_id           varchar(6000)    encode lzo
, dw_suspected_bot_in	    varchar(10)      encode lzo
, logged_ip                 varchar(200)     encode lzo
, dw_click_page_sk	        bigint           encode lzo
, dw_url_sk                 bigint           encode lzo
, dw_imprsn_id              varchar(1000)    encode lzo
, page_vertical_tx          varchar(6000)    encode lzo
, page_topic_tx             varchar(6000)    encode lzo
, dw_click_user_agent_id	integer          encode lzo
, dw_catg_nm	            varchar(256)     encode lzo
, commission_am	            numeric(10,2)    encode lzo
, merchant_am	            numeric(10,2)    encode lzo
, revenue_tran_in	        varchar(10)      encode lzo
, txn_ct                  	integer 	encode lzo
, src_commission_am	        numeric(10,2)    encode lzo
, src_revenue_tran_in	    varchar(10)      encode lzo
, dw_last_updt_ts           TIMESTAMP        ENCODE delta
, dw_last_updt_tx           VARCHAR(3000)    ENCODE lzo
, dw_snapshot_dt          date
, dw_load_ts	            timestamp        encode lzo
)
DISTSTYLE KEY
DISTKEY (src_unique_click_id)
SORTKEY (dw_eff_dt)
;

GRANT REFERENCES,  TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_etl;
GRANT  SELECT ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_data_users_secured;
GRANT SELECT, REFERENCES, RULE, INSERT, TRIGGER,  UPDATE, DELETE ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_dba;
GRANT TRIGGER, REFERENCES, UPDATE, DELETE, SELECT, RULE,  INSERT ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO nw_dwh_etl;
GRANT UPDATE, INSERT, REFERENCES, TRIGGER, SELECT, DELETE, RULE ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_etl_secured;
GRANT  SELECT ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_bi_tool_users;
GRANT  SELECT ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_meta_nerd;
GRANT SELECT ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_redash;
GRANT SELECT ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_ba_users;
GRANT SELECT,  TRIGGER, DELETE, UPDATE ON dw_report.dw_aflt_tran_consolidated_snapshot_f TO group grp_data_users;
