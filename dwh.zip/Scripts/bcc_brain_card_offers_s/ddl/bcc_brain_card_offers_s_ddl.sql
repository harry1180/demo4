
drop   table dw_stage.bcc_brain_card_offers_s;

CREATE TABLE dw_stage.bcc_brain_card_offers_s
(
id         BIGINT,
"uuid"      varchar(256),
panic      smallint,
user_agent varchar(2000),
url       varchar(6000),
params    varchar(5000),
ip        varchar(255),
offer_id  BIGINT,
created_at TIMESTAMP,
suspected_bot smallint
--,FOREIGN KEY (id) REFERENCES dw_stage.bcc_brain_offers_s(id),
)
distkey (id) ;

GRANT ALL  ON dw_stage.bcc_brain_card_offers_s TO GROUP grp_etl;

