SELECT 
  id     
, uuid    
, panic     
, user_agent
, url       
, params    
, ip        
, offer_id  
, created_at
, suspected_bot
FROM
  bcc_app.card_offers
  where created_at > DATE_SUB(current_date, INTERVAL 15 DAY) 
;



