
--create table dw_bkup.ctl_logger_event_file_tracking as select * from dw_report.ctl_logger_event_file_tracking;

--drop   table if exists dw_report.ctl_logger_event_file_tracking_N;
create table dw_report.ctl_logger_event_file_tracking_N
(
  platform_cd             varchar(300)     encode lzo
, event_nm                varchar(300)     encode lzo
, src_key_tx              varchar(2000)    encode lzo
, dw_eff_dt               date             encode lzo -- '2016-04-12' file created date
, record_ct               integer          encode lzo
, key_file_path_tx        varchar(2000)    encode lzo -- '2016/04/12/00'
, dw_last_updt_ts	      timestamp        encode lzo
, dw_last_updt_tx	      varchar(3000)    encode lzo
, dw_load_ts	          timestamp        encode lzo
)
distkey(key_file_path_tx) 
sortkey(dw_eff_dt)
;

insert into dw_report.ctl_logger_event_file_tracking_N
(
  platform_cd     
, event_nm        
, src_key_tx      
, dw_eff_dt       
, record_ct       
, key_file_path_tx
, dw_last_updt_ts	
, dw_last_updt_tx	
, dw_load_ts	     
)
select
  platform_cd     
, event_nm        
, src_key_tx      
, dw_eff_dt       
, record_ct       
, key_file_path_tx
, null as dw_last_updt_ts	
, null as dw_last_updt_tx	
, null as dw_load_ts	     
from dw_report.ctl_logger_event_file_tracking
;

select count(*) from dw_report.ctl_logger_event_file_tracking_N;
select count(*) from dw_report.ctl_logger_event_file_tracking;

drop  table if exists dw_report.ctl_logger_event_file_tracking_OLD;
alter table dw_report.ctl_logger_event_file_tracking   rename to ctl_logger_event_file_tracking_OLD;
alter table dw_report.ctl_logger_event_file_tracking_N rename to ctl_logger_event_file_tracking;
--select count(*) from dw_report.ctl_logger_event_file_tracking_OLD;
--select count(*) from dw_report.ctl_logger_event_file_tracking;

GRANT SELECT ON dw_report.ctl_logger_event_file_tracking TO group grp_data_users;
GRANT all    ON dw_report.ctl_logger_event_file_tracking TO group grp_etl;
--drop table dw_report.ctl_logger_event_file_tracking_OLD;


--create table dw_bkup.ctl_s3_event_file_tracking as select * from dw_report.ctl_s3_event_file_tracking;

--drop   table if exists dw_report.ctl_s3_event_file_tracking_N;
create table dw_report.ctl_s3_event_file_tracking_N
(
  platform_cd             varchar(300)     encode lzo
, event_nm                varchar(300)     encode lzo
, src_key_tx              varchar(2000)    encode lzo
, dw_eff_dt               date             encode lzo -- '2016-04-12' file created date
, record_ct               integer          encode lzo
, key_file_path_tx        varchar(2000)    encode lzo -- '2016/04/12/00'
, dw_last_updt_ts	      timestamp        encode lzo
, dw_last_updt_tx	      varchar(3000)    encode lzo
, dw_load_ts	          timestamp        encode lzo
)
distkey(key_file_path_tx) 
sortkey(dw_eff_dt)
;

insert into dw_report.ctl_s3_event_file_tracking_N
(
  platform_cd     
, event_nm        
, src_key_tx      
, dw_eff_dt       
, record_ct       
, key_file_path_tx
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts	  
)
select
  platform_cd     
, event_nm        
, src_key_tx      
, dw_eff_dt       
, record_ct       
, key_file_path_tx
, null as dw_last_updt_ts
, null as dw_last_updt_tx
, null as dw_load_ts	  
from dw_report.ctl_s3_event_file_tracking
;

select count(*) from dw_report.ctl_s3_event_file_tracking_N;
select count(*) from dw_report.ctl_s3_event_file_tracking;

drop  table if exists dw_report.ctl_s3_event_file_tracking_OLD;
alter table dw_report.ctl_s3_event_file_tracking   rename to ctl_s3_event_file_tracking_OLD;
alter table dw_report.ctl_s3_event_file_tracking_N rename to ctl_s3_event_file_tracking;
--select count(*) from dw_report.ctl_s3_event_file_tracking_OLD;
--select count(*) from dw_report.ctl_s3_event_file_tracking;

GRANT SELECT ON dw_report.ctl_s3_event_file_tracking TO group grp_data_users;
GRANT all    ON dw_report.ctl_s3_event_file_tracking TO group grp_etl;
--drop table dw_report.ctl_s3_event_file_tracking_OLD;


--drop   table if exists dw_report.ctl_event_file_tracking;
create table dw_report.ctl_event_file_tracking
(
  object_nm	              varchar(2000)    -- 'BrokersClickEvent'
, key_file_date_tx	      varchar(20)      -- '2016/04/12'
, key_file_nm	          varchar(2000)    -- '00'
, dw_eff_dt               date             -- 2016-04-12
, key_file_path_tx        varchar(2000)    -- '2016/04/12/00'
, yyyy_nr                 smallint
, mm_nr                   smallint
, dd_nr                   smallint
, logger_dt               date
, logger_start_hr_tx      varchar(20)      -- '23:00'
, logger_end_hr_tx        varchar(20)      -- '23:59'
, logger_record_ct        integer          -- logger record count
, s3_file_nm              varchar(400)
, s3_file_prefix_nm       varchar(300)
, s3_file_ext_nm          varchar(100)
, s3_record_ct            integer          -- s3 protobuf record count
, s3_vs_logger_diff_ct    integer          -- difference b/w s3_record_ct and logger_record_ct
, ds_file_ext_nm          varchar(200)     -- 'json' -- ds=deserialization
, ds_json_record_ct       integer          -- reading-raw-json-after-ds record count
, ds_vs_s3_diff_ct        integer          -- difference b/w ds_json_record_ct and s3_record_ct
, rs_json_record_ct       integer          -- parsed-json-to-Redshift(rs) record count
, rs_vs_ds_record_ct      integer          -- difference b/w rs_json_record_ct and ds_json_record_ct
, src_s3_file_tx          varchar(2000)    -- 'BrokersClickEvent/2016/04/12/00.protobuf'
, src_ds_file_tx          varchar(2000)    -- '/data/etl/Data/BrokersClickEvent/2016/04/12/00.json'
, src_rs_file_tx          varchar(2000)    -- '/data/etl/Data/click_event_broker_s/archive/2016/04/12/00.json'
, dw_last_updt_ts	      timestamp
, dw_last_updt_tx	      varchar(3000)
, dw_load_ts	          timestamp
) 
distkey(key_file_path_tx) 
sortkey(dw_eff_dt)
;

grant select on dw_report.ctl_event_file_tracking to group grp_data_users;
grant all    on dw_report.ctl_event_file_tracking to group grp_etl;

--drop table if exists dw_stage.ctl_counts_json_logger_post_s;
create table dw_stage.ctl_counts_json_logger_post_s
(
  logger_key	        varchar(2000)
, platform	            varchar(300)
, event_name	        varchar(300)
, written_file_date	    varchar(20)
, key_file_path_tx	    varchar(2000)
, logger_date	        date
, key_start_hour	    varchar(20)
, key_end_hour	        varchar(20)
, yyyy	                varchar(10)
, mm	                varchar(10)
, dd	                varchar(10)
, file_name	            varchar(400)
, file_prefix	        varchar(300)
, file_extension	    varchar(100)
, record_count	        integer
, derived_logger_key	varchar(2000)
) 
distkey(logger_key)
;

--drop table if exists dw_stage.ctl_counts_json_s3_post_s;
create table dw_stage.ctl_counts_json_s3_post_s
(
  s3_key	            varchar(2000)
, platform	            varchar(300)
, event_name	        varchar(300)
, written_file_date	    varchar(20)
, key_file_path_tx	    varchar(2000)
, yyyy	                varchar(10)
, mm	                varchar(10)
, dd	                varchar(10)
, file_name	            varchar(400)
, file_prefix	        varchar(300)
, file_extension	    varchar(100)
, record_count	        integer
)
distkey(s3_key)
;
