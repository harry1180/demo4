job_name='ctl_event_file_tracking'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

Processing_Step="Run SQL Scripts"
echo_processing_step ${job_name} "$Processing_Step" "Started"
echo "ctl_counts_json_logger_post_s_del.sql
ctl_counts_json_logger_post_s_ins.sql
ctl_counts_json_s3_post_s_del.sql
ctl_counts_json_s3_post_s_ins.sql
ctl_logger_event_file_tracking_ins.sql
ctl_logger_event_file_tracking_upd_record_ct.sql
ctl_s3_event_file_tracking_ins.sql
ctl_s3_event_file_tracking_upd_record_ct.sql
ctl_event_file_tracking_ins.sql
ctl_event_file_tracking_upd_logger_record_ct.sql
ctl_event_file_tracking_upd_s3_record_ct.sql
ctl_event_file_tracking_upd_s3_vs_logger_diff_ct.sql" | while read sql_script other_var
do
  echo_processing_step ${job_name} "$sql_script" "Started"
  bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/${sql_script} 
  echo_processing_step ${job_name} "$sql_script" "Completed"
done
echo_processing_step ${job_name} "$Processing_Step" "Completed"

script="ctl_event_file_tracking_event_volume_change.json"
Processing_Step="DQ check - ${script}"
echo_processing_step ${job_name} "${Processing_Step}" "Started"
python ${dwh_common_base_dir}/run_dq_check.py ${dwh_scripts_base_dir}/${job_name}/pythonscripts/${script}
echo_processing_step ${job_name} "${Processing_Step}" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
