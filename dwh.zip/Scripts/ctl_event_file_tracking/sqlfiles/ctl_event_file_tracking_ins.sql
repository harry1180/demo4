
insert into dw_report.ctl_event_file_tracking
(
  object_nm	          
, key_file_date_tx	      
, key_file_nm	      
, dw_eff_dt           
, key_file_path_tx    
, yyyy_nr             
, mm_nr               
, dd_nr               
, logger_dt           
, logger_start_hr_tx  
, logger_end_hr_tx    
, logger_record_ct    
, s3_file_nm          
, s3_file_prefix_nm   
, s3_file_ext_nm      
, s3_record_ct        
, s3_vs_logger_diff_ct
, ds_file_ext_nm      
, ds_json_record_ct   
, ds_vs_s3_diff_ct    
, rs_json_record_ct   
, rs_vs_ds_record_ct  
, src_s3_file_tx      
, src_ds_file_tx      
, src_rs_file_tx      
, dw_last_updt_ts	  
, dw_last_updt_tx	  
, dw_load_ts	      	          
)
select 
  stg.event_name                                               as object_nm	           
, stg.written_file_date                                        as key_file_date_tx	         
, stg.s3_file_prefix_nm                                        as key_file_nm	         
, to_date(stg.written_file_date, 'yyyy-mm-dd')                 as dw_eff_dt            
, stg.key_file_path_tx                                         as key_file_path_tx     
  -- would specially choose last day's logger information, current logger doesn't have the key information. 
  -- for example, the 00.protobuf, which reads logger info from last 23:00-23:59  
, cast(stg.yyyy_nr as smallint)                                as yyyy_nr
, cast(stg.mm_nr as smallint)                                  as mm_nr
, cast(stg.dd_nr as smallint)                                  as dd_nr
, coalesce(stg.logger_date,         tgt0.logger_dt)            as logger_dt         
, coalesce(stg.key_start_hour,      tgt0.logger_start_hr_tx)   as logger_start_hr_tx   
, coalesce(stg.key_end_hour,        tgt0.logger_end_hr_tx)     as logger_end_hr_tx     
, coalesce(stg.logger_record_ct,    tgt0.logger_record_ct)     as logger_record_ct 
, stg.s3_file_nm                                               as s3_file_nm
, stg.s3_file_prefix_nm                                        as s3_file_prefix_nm
, stg.s3_file_ext_nm                                           as s3_file_ext_nm       
, stg.s3_record_ct                                             as s3_record_ct      
, (stg.s3_record_ct - coalesce(stg.logger_record_ct, tgt0.logger_record_ct))              
                                                               as s3_vs_logger_diff_ct 
, null                                                         as ds_file_ext_nm       
, null                                                         as ds_json_record_ct    
, null                                                         as ds_vs_s3_diff_ct     
, null                                                         as rs_json_record_ct    
, null                                                         as rs_vs_ds_record_ct   
, stg.s3_file_nm                                               as src_s3_file_tx
, null                                                         as src_ds_file_tx
, null                                                         as src_rs_file_tx
, null                                                         as dw_last_updt_ts	     
, null                                                         as dw_last_updt_tx	     
, sysdate                                                      as dw_load_ts
from 
(
  select 
      coalesce(s3.key_file_path_tx,  logger.key_file_path_tx)   as key_file_path_tx
    , coalesce(s3.event_name,        logger.event_name)         as event_name
    , coalesce(s3.written_file_date, logger.written_file_date)  as written_file_date
    , coalesce(s3.yyyy,              logger.yyyy)               as yyyy_nr
    , coalesce(s3.mm,                logger.mm)                 as mm_nr
    , coalesce(s3.dd,                logger.dd)                 as dd_nr
    , logger.logger_date
    , logger.key_start_hour
    , logger.key_end_hour
    , logger.record_count                                       as logger_record_ct
    , coalesce(s3.s3_key,            logger.derived_logger_key) as s3_file_nm
    , coalesce(s3.file_prefix,       logger.file_prefix)        as s3_file_prefix_nm
    , coalesce(s3.file_extension,    logger.file_extension)     as s3_file_ext_nm    
    , s3.record_count                                           as s3_record_ct
  from 
       dw_stage.ctl_counts_json_s3_post_s     s3
  full join 
       dw_stage.ctl_counts_json_logger_post_s logger
    on s3.s3_key = logger.derived_logger_key
) stg

left join dw_report.ctl_event_file_tracking tgt0
 on stg.key_file_path_tx = tgt0.key_file_path_tx
and stg.event_name       = tgt0.object_nm

left join dw_report.ctl_event_file_tracking tgt
 on stg.key_file_path_tx = tgt.key_file_path_tx
and stg.event_name       = tgt.object_nm

where tgt.object_nm        is null
  and tgt.key_file_path_tx is null
;
