
update dw_report.ctl_logger_event_file_tracking

set record_ct       = stg.record_count
  , dw_last_updt_ts = sysdate
  , dw_last_updt_tx = 'Update record_ct'

from dw_stage.ctl_counts_json_logger_post_s   stg

where 
     dw_report.ctl_logger_event_file_tracking.key_file_path_tx = stg.key_file_path_tx
and  
     dw_report.ctl_logger_event_file_tracking.event_nm         = stg.event_name
and 
     coalesce(dw_report.ctl_logger_event_file_tracking.record_ct, -999999999) <> coalesce(stg.record_count, -999999999)
;

