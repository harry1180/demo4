
delete from dw_stage.ctl_counts_json_s3_post_s ;
