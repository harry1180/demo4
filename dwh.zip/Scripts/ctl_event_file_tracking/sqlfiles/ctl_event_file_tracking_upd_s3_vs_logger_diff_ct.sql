update dw_report.ctl_event_file_tracking
set s3_vs_logger_diff_ct    = s3_record_ct - logger_record_ct
  , dw_last_updt_ts         = sysdate
  , dw_last_updt_tx         = 'Update s3_vs_logger_diff_ct'
where 
     s3_vs_logger_diff_ct is null 
and
     s3_record_ct         is not null 
and 
    logger_record_ct      is not null 
;
