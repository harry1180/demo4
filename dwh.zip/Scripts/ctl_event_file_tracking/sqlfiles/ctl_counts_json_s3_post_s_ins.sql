
insert into dw_stage.ctl_counts_json_s3_post_s
(
  s3_key	       
, platform	       
, event_name	   
, written_file_date
, key_file_path_tx	
, yyyy	           
, mm	           
, dd	           
, file_name	       
, file_prefix	   
, file_extension	
, record_count	   
)
select
  key as s3_key
, platform
, event_name
, trim(yyyy||'/'||mm||'/'||dd) as written_file_date
, cast(trim(yyyy||'/'||mm||'/'||dd||'/'||file_prefix) as varchar(2000)) as key_file_path_tx
, yyyy
, mm
, dd
, file_name
, file_prefix
, file_extension
, record_count
from 
(
  select 
    key
  , platform
  , split_part(key,'/',1) as event_name
  , split_part(key,'/',2) as yyyy
  , split_part(key,'/',3) as mm
  , split_part(key,'/',4) as dd
  , split_part(key,'/',5) as file_name
  , split_part(split_part(key,'/',5), '.', 1) as file_prefix
  , split_part(split_part(key,'/',5), '.', 2) as file_extension
  , record_count
  from dw_stage.ctl_counts_json_s
  where platform = 's3'
) s3_sub
;
