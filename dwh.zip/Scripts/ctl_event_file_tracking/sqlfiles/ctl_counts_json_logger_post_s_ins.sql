
insert into dw_stage.ctl_counts_json_logger_post_s 
(
  logger_key	     
, platform	         
, event_name	     
, written_file_date	 
, key_file_path_tx	 
, logger_date	     
, key_start_hour	 
, key_end_hour	     
, yyyy	             
, mm	             
, dd	             
, file_name	         
, file_prefix	     
, file_extension	 
, record_count	     
, derived_logger_key
) 
select
  logger_key
, platform
, event_name
, written_file_date
, written_file_date||'/'||split_part(file_name, '.', 1) as key_file_path_tx
, logger_date
, key_start_hour
, key_end_hour
, split_part(written_file_date,'/',1) as yyyy
, split_part(written_file_date,'/',2) as mm
, split_part(written_file_date,'/',3) as dd
, file_name
, split_part(file_name, '.', 1) as file_prefix
, split_part(file_name, '.', 2) as file_extension
, record_count
, event_name||'/'||written_file_date||'/'||file_name as derived_logger_key
from
(
  select 
    key as logger_key
  , platform
  , event_name
  , logger_date
  , key_start_hour
  , key_end_hour
  , case 
    when key_end_hour = '23:59' then to_char(logger_date + interval '1 days', 'yyyy/mm/dd')
    else to_char(logger_date, 'yyyy/mm/dd')
    end as written_file_date
  , case 
    when key_end_hour = '23:59' then '00.protobuf'
    when key_end_hour = '00:59' then '01.protobuf'
    when key_end_hour = '01:59' then '02.protobuf'
    when key_end_hour = '02:59' then '03.protobuf'  
    when key_end_hour = '03:59' then '04.protobuf'
    when key_end_hour = '04:59' then '05.protobuf'
    when key_end_hour = '05:59' then '06.protobuf'  
    when key_end_hour = '06:59' then '07.protobuf'
    when key_end_hour = '07:59' then '08.protobuf'
    when key_end_hour = '08:59' then '09.protobuf'  
    when key_end_hour = '09:59' then '10.protobuf'
    when key_end_hour = '10:59' then '11.protobuf'
    when key_end_hour = '11:59' then '12.protobuf'  
    when key_end_hour = '12:59' then '13.protobuf'
    when key_end_hour = '13:59' then '14.protobuf'
    when key_end_hour = '14:59' then '15.protobuf'  
    when key_end_hour = '15:59' then '16.protobuf'
    when key_end_hour = '16:59' then '17.protobuf'  
    when key_end_hour = '17:59' then '18.protobuf'
    when key_end_hour = '18:59' then '19.protobuf'
    when key_end_hour = '19:59' then '20.protobuf'  
    when key_end_hour = '20:59' then '21.protobuf'  
    when key_end_hour = '21:59' then '22.protobuf'  
    when key_end_hour = '22:59' then '23.protobuf'  
    end as file_name
  , record_count as record_count
  from 
  (
    select key, platform, event_name, split_part(key,'/',1) as yyyy
    , split_part(key,'/',2) as mm, split_part(split_part(key,'/',3), ':', 1) as dd
    , cast(split_part(key,'/',1)||'-'||split_part(key,'/',2)||'-'||split_part(split_part(key,'/',3), ':', 1) as date) as logger_date
    , substring(key, 12, 5) as key_start_hour
    , split_part(key, '-', 2) as key_end_hour
    , record_count
     from dw_stage.ctl_counts_json_s
    where platform = 'logger'
  ) logger_sub1
) logger_sub2
;
