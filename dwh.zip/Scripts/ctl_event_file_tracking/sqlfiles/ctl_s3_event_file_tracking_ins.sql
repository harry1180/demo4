
insert into dw_report.ctl_s3_event_file_tracking
(
  platform_cd       
, event_nm          
, src_key_tx            
, dw_eff_dt         
, record_ct         
, key_file_path_tx  
, dw_load_ts
)
select
  's3'                                     as platform_cd
, stg.event_name                           as event_nm
, stg.s3_key                               as src_key_tx
, to_date(written_file_date, 'yyyy-mm-dd') as dw_eff_dt
, stg.record_count                         as record_ct
, stg.key_file_path_tx                     as key_file_path_tx
, sysdate                                  as dw_load_ts
from dw_stage.ctl_counts_json_s3_post_s stg
left join dw_report.ctl_s3_event_file_tracking tgt
on 
  stg.key_file_path_tx = tgt.key_file_path_tx
and
  stg.event_name       = tgt.event_nm
where 
  tgt.key_file_path_tx is null
;
