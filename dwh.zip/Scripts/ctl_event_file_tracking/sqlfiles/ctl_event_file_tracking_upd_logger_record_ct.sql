
update dw_report.ctl_event_file_tracking

set logger_record_ct = stg.record_count
  , dw_last_updt_ts  = sysdate
  , dw_last_updt_tx  = 'Update logger_record_ct'

from dw_stage.ctl_counts_json_logger_post_s   stg

where 
     dw_report.ctl_event_file_tracking.key_file_path_tx = stg.key_file_path_tx
and 
     dw_report.ctl_event_file_tracking.object_nm        = stg.event_name
and
     coalesce(dw_report.ctl_event_file_tracking.logger_record_ct, -999999999) <> coalesce(stg.record_count, -999999999)
;
