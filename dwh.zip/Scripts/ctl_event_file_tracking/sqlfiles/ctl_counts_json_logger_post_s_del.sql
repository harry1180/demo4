
delete from dw_stage.ctl_counts_json_logger_post_s ;
