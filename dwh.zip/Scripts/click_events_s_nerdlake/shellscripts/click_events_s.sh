job_name='click_events_s_nerdlake'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
if [ -d "$Linux_Temp" ] && [ "$Linux_Temp" != "/tmp" ]
then
    echo_processing_step ${job_name} "Removing Temporary Files" "Started"
    find $Linux_Temp -type f -exec rm {} \; || true
    echo_processing_step ${job_name} "Removing Temporary Files" "Completed"
fi

# Skip:
# --base-table dwnl_stage.InvestingClickEvent_s,INVESTING_CLICK_EVENT  # Last event on 2016-03-15
# --base-table dwnl_stage.ShoppingClickEvent_s,SHOPPING_CLICK_EVENT # Last event on 2017-01-09

echo_processing_step ${job_name} "Calling Composite Script" "Started"
python $dwh_common_base_dir/nerdlake_composite_table.py \
    --composite-table dwnl_stage.click_events_s \
    --base-field event_name \
    --base-table dwnl_stage.BrokersClickEvent_s,BROKERS_CLICK_EVENT \
    --base-table dwnl_stage.CCClickEvent_s,CC_CLICK_EVENT \
    --base-table dwnl_stage.CreditScoreClickEvent_s,CREDIT_SCORE_CLICK_EVENT \
    --base-table dwnl_stage.GenericClickEvent_s,GENERIC_CLICK_EVENT \
    --base-table dwnl_stage.InsuranceClickEvent_s,INSURANCE_CLICK_EVENT \
    --base-table dwnl_stage.InsuranceProductClickEvent_s,INSURANCE_PRODUCT_CLICK_EVENT \
    --base-table dwnl_stage.MortgageLenderClickEvent_s,MORTGAGE_LENDER_CLICK_EVENT \
    --base-table dwnl_stage.PersonalLoansClickEvent_s,PERSONAL_LOANS_CLICK_EVENT \
    --base-table dwnl_stage.PrepaidClickEvent_s,PREPAID_CLICK_EVENT \
    --base-table dwnl_stage.RateClickEvent_s,RATE_CLICK_EVENT \
    --base-table dwnl_stage.SMBClickEvent_s,SMB_CLICK_EVENT \
    --base-table dwnl_stage.TaxesClickEvent_s,TAXES_CLICK_EVENT
echo_processing_step ${job_name} "Calling Composite Script" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
