
job_name='cc_propensity_model'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

#######################################
#Main Script
#######################################

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'

output_file=${Linux_Output}finalfile.csv
output_wildcard='finalfile'
redshift_schema='dw_workarea'
redshift_table='ccproptoclick_members'

echo 'output_file             :-   '${output_file}
echo 'redshift_db             :-   '${redshift_schema}
echo 'redshift_table          :-   '${redshift_table}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleanup previous files" "Started"
rm -f $Linux_Output*$output_wildcard* || true
python -c "from s3_modules import delete_key; delete_key('${S3_Events_Output}','${Events_dwh_bucket}','${output_wildcard}')" || true
echo_processing_step ${job_name} "Cleanup previous files" "Completed"

echo_processing_step ${job_name} "Insert data model source table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/ins_finaltabletogivetomodel.sql
echo_processing_step ${job_name} "Insert data model source table" "Completed"

echo_processing_step ${job_name} "Running Python script to predict probability" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/cc_propensity_model.py $output_file
echo_processing_step ${job_name} "Running Python script to predict probability" "Completed"

echo_processing_step ${job_name} "Compressing output file and moving to S3" "Started"
gzip $output_file
python -c "from s3_modules import s3_file_upload; s3_file_upload('$output_file.gz', '$Events_dwh_bucket', '$S3_Events_Output')"
echo_processing_step ${job_name} "Compressing output file and moving to S3" "Completed"

echo_processing_step ${job_name} "Deleting old data from table" "Started"
query_stage_delete="delete from ${redshift_schema}.${redshift_table};"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Deleting old data from table" "Completed"

echo_processing_step ${job_name} "Copying the data to table" "Started"
load_query="copy $redshift_schema.$redshift_table from 's3://$Events_dwh_bucket/$S3_Events_Output$output_wildcard' credentials '$s3_prod_load_creds' gzip delimiter ',' IGNOREHEADER AS 1 COMPUPDATE OFF;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$load_query"
echo_processing_step ${job_name} "Copying the data to table" "Completed"


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds


trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
