import os
import sys

import numpy as np
import pandas as pd

from sklearn.externals import joblib

from redshift_modules import redshift_connect


if __name__ == '__main__':

    output_file = sys.argv[1]

    # dw_workarea.finaltabletogivetomodel has members from last 15 days and their 103 attributes
    conn = redshift_connect()
    dt = pd.read_sql("select * from dw_workarea.finaltabletogivetomodel", conn)
    conn.close()

    dt.transacted.unique()
    dt = dt.replace(np.nan, 0)

    # keep these columns separate since Justin will use this along with the 3rd predicted probability column
    cols_to_keep = ['user_id', 'transacted']
    finaldata = dt[cols_to_keep]

    # drop these two columns since we want to apply the Logistic regression model on this dataset
    dt.drop(['user_id', 'transacted'], axis=1, inplace=True)

    # read stored model
    current_dir = os.path.dirname(os.path.realpath(__file__))
    clflogreg = joblib.load(os.path.join(current_dir, 'CCPropModellogreg.pkl'))

    # convert the dataframe into array before applying the model - good practise
    dt = dt.values

    # lets predict the y's using this regression
    predicted = clflogreg.predict_proba(dt)

    # save results in a dataframe
    tempdf = pd.DataFrame(predicted)

    # only keep the values where class  = 1 i.e. prob of clicking on apply now
    df1 = tempdf[1]

    # merge our original dataframe having userid and actually clicked or not along with
    # predicted part which we get from df1
    result = pd.merge(finaldata, df1.to_frame(), right_index=True, left_index=True)

    # Rename column names so that we can remember what was what later
    result = result.rename(columns={result.columns[2]: "predicted_prob"})

    # export columns to csv
    result.to_csv(output_file, index=False)
