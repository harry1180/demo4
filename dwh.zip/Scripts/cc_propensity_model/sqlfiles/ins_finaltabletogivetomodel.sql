--- NOTE - LAST TABLE dw_workarea.finaltabletogivetomodel IS THE ONE WHICH THE MODEL WILL READ AND USE
-- *** Based on applying for a card
--- DATASET FOR PROPENSITY TO TRANSACT FOR MEMBERS WITH TU details


-- get all Desktop users who came to NW recently
drop table if exists users1;
create temp table users1 as
select a.user_id from dw_session_enriched a
where a.user_id <> 'guest'
and a.device = 'Desktop'
and tot_page_view_ct <> 1
and a.dw_eff_dt >= current_date-15
group by 1;


-- get all users who came to NW in a certain time period 
drop table if exists txns;
create temp table txns as
select user_id,min(click_utc_ts) as txn_ts from dw_clicks_enriched
where dw_imprsn_id in
(
select distinct dw_imprsn_id from dw_prod_imprsn_event_cc_f where link_type_cd = 'apply_link' 
and 
dw_eff_dt >= current_date-15
)
and dw_eff_dt >= current_date-15
and dw_src_sys_id = 1
and user_id <> 'guest' 
group by 1;



drop table if exists transactors;
create temp table transactors as
select a.user_id, coalesce(min(txn_ts),null) as txn_ts 
from users1 a
left join txns b on a.user_id=b.user_id 
group by 1;

drop table if exists allusers;
create temp table allusers as
select a.*,case when a.txn_ts is null then 0 else 1 end as transacted from transactors a;

drop table if exists users2;
CREATE TEMP TABLE users2 AS
SELECT a.*,
       b.reg_trk_flow_cd,
       b.reg_trk_vertical_tx,
       b.reg_trk_channel_cd,  
       b.reg_pfm_nm,
       b.reg_device,
       b.reg_traffic_source
--       ,b.tu_acct_status_cd
from allusers a
left join 
dw_pud_views.dw_user_snap_v b
on a.user_id=b.user_id;


--where b.tu_acct_status_cd = 'ACTIVE';
-- select count(*) from users where transacted =1;  

-- NOTE - Out of 105k desktop people with active TU, 7988 transacted ( means clicked on apply now) 

/*
-- 13 of them = reg_trk_flow_cd  (dit,other,smb-prequal ,signin-credit-
,credit-score,basic,signin-basic,register-basic,unkown,register-credit-score,cc-app,error,personal-loans-prequal) 
-- 22 of them = reg_trk_vertical_tx  = Shopping,Taxes,Budget Traveling,Personal Finance,Nerdwallet-Mobile,Investing,Other,Credit Cards,Mynerdwallet,Small Business,Homepage,Utilities,Banking,Press,Insurance,Loans,Health,Internal,Corporate News,Education,Mortgage)
-- 2 of them = reg_trk_channel_cd= (web,email)
-- 3 of them = reg_pfm_nm= (Other,Mobile Web,Web)
-- 9 of them = reg_traffic_source  (Referral, Social, Unknown,Internal,NA,Display,Branded-HP,Search,Email) 
-- 3 of them = reg_device (Tablet,Desktop,Native Mobile) 
*/
-- see for all people did they interact with the CC tool page before transacting or either ways in cases when they didnt transact at all

-- select * from users limit 5;

drop TABLE IF EXISTS form_change_data;
create TEMP TABLE form_change_data AS
select 
a.user_id,
a.transacted,
a.txn_ts,
coalesce(count(distinct b.form_input_chg_id),0) as form_input_change
from users2 a
left join dw_pv_form_input_chg_event_f b 
on a.user_id=b.user_id
where form_nm in('cc-tool-filters')
and b.dw_eff_dt  >= current_date-15
and transacted = 0
group by 1,2,3
union all
select a.user_id,
a.transacted,
a.txn_ts,
count(distinct b.form_input_chg_id) as form_input_change
from users2 a
left join dw_pv_form_input_chg_event_f b 
on a.user_id=b.user_id and a.txn_ts >=b.form_input_chg_utc_ts
where form_nm in('cc-tool-filters')
and b.dw_eff_dt  >= current_date-15
and transacted = 1
group by 1,2,3
union all
select a.user_id,
a.transacted,
a.txn_ts,
0 as form_input_change
from users2 a
where user_id not in (select user_id from dw_pv_form_input_chg_event_f
where form_nm in('cc-tool-filters')
and dw_eff_dt  >= current_date-15)
group by 1,2,3;


-- select * from form_change_data limit 10;

-- 2) why not cnt diftinct dates in a time period rather than actvy_id?
drop table if exists activity_table;
CREATE TEMP TABLE activity_table AS
SELECT a.user_id,
--       a.device,
--      a.transacted,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx LIKE 'card-details%' THEN actvy_id END) AS had_product_detail_visit,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_function_tx = 'Tool' THEN actvy_id end) AS had_tool_visit,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'recommend' THEN actvy_id end) AS started_personal_rec,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'recommend/result' THEN actvy_id end) AS sawresult_personal_rec,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'compare/credit-cards' THEN actvy_id end) AS visited_compare,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'the-best-credit-cards' THEN actvy_id end) AS visited_bcc,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/top-credit-cards/no-foreign-transaction-fee-credit-card',
       'blog/top-credit-cards/nerdwallets-best-travel-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-airline-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-balance-transfer-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-cash-back-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-rewards-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-college-student-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-small-business-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-low-interest-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-secured-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-credit-cards-for-bad-credit') 
       THEN actvy_id END) AS had_visit_to_CC_BestOfArticle_pages,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' THEN actvy_id END) AS PVs,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PRODUCT_INTERACTION' and actvy_sub_type_cd = 'ADD' THEN actvy_id END) AS add_to_cart_interaction,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'CLICK' THEN actvy_id END) AS clicks,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'FORM_INPUT_CHANGED' AND page_path_tx = 'prequalify/credit-cards' THEN actvy_id end) AS started_CCprequal,       
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'FORM_INPUT_CHANGED' AND page_path_tx = 'prequalify/credit-cards/offers' THEN actvy_id end) AS finished_CCprequal,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/credit-score' THEN actvy_id end) AS visiteddashboard_creditscorepage,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/home' THEN actvy_id end) AS visiteddashboard_creditdashboard_homepage,                         
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/transactions' THEN actvy_id end) AS visiteddashboard_transactions,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/accounts' THEN actvy_id end) AS visiteddashboard_accounts,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/alerts' THEN actvy_id end) AS visiteddashboard_alerts,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/credit-score/goal-and-tips/close_oldest' THEN actvy_id end) AS visiteddashboard_Creditscoretipspage,  
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx like '%yodlee/login%'  and field_nm like 'request:getProviderDetails:success' THEN actvy_id end) AS linked_bankaccount,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
      ('blog/finance/30-percent-credit-utilization-ratio-rule') THEN actvy_id END) AS visited_30percentcreditutilizationratiorule,--8k monthly pv's
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/authorized-user-credit-score') THEN actvy_id END) AS visited_blogfinanceauthorizedusercreditscore, -- 8-10k monthly pv's
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/consolidate-credit-card-debt-personal-loan') THEN actvy_id END) AS visited_blogfinanceconsolidatecreditcarddebtpersonalloan, -- 14k monthly pv's                   
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/credit-report-soft-hard-pull-difference') THEN actvy_id END) AS visited_blogfinancecreditreportsofthardpulldifference, -- 7k monthly pv's                   
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/credit-score-pay-debt') THEN actvy_id END) AS visited_blogfinancecreditscorepaydebt, -- 12k monthly pv's                   
        max(form_input_change) AS form_input_change
FROM form_change_data a
LEFT JOIN dw_views.dw_actvy_enriched b 
ON a.user_id = b.user_id
WHERE 
transacted = 0
AND   b.dw_eff_dt  >= current_date-15
GROUP BY 1 
UNION ALL
SELECT a.user_id,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx LIKE 'card-details%' THEN actvy_id END) AS had_product_detail_visit,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_function_tx = 'Tool' THEN actvy_id end) AS had_tool_visit,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'recommend' THEN actvy_id end) AS started_personal_rec,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'recommend/result' THEN actvy_id end) AS sawresult_personal_rec,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'compare/credit-cards' THEN actvy_id end) AS visited_compare,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'the-best-credit-cards' THEN actvy_id end) AS visited_bcc,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/top-credit-cards/no-foreign-transaction-fee-credit-card',
       'blog/top-credit-cards/nerdwallets-best-travel-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-airline-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-balance-transfer-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-cash-back-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-rewards-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-college-student-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-small-business-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-low-interest-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-secured-credit-cards',
       'blog/top-credit-cards/nerdwallets-best-credit-cards-for-bad-credit') 
       THEN actvy_id END) AS had_visit_to_CC_BestOfArticle_pages,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' THEN actvy_id END) AS PVs,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PRODUCT_INTERACTION' and actvy_sub_type_cd = 'ADD' THEN actvy_id END) AS add_to_cart_interaction,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'CLICK' THEN actvy_id END) AS clicks,
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'FORM_INPUT_CHANGED' AND page_path_tx = 'prequalify/credit-cards' THEN actvy_id end) AS started_CCprequal,       
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'FORM_INPUT_CHANGED' AND page_path_tx = 'prequalify/credit-cards/offers' THEN actvy_id end) AS finished_CCprequal,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/credit-score' THEN actvy_id end) AS visiteddashboard_creditscorepage,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/home' THEN actvy_id end) AS visiteddashboard_creditdashboard_homepage,                         
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/transactions' THEN actvy_id end) AS visiteddashboard_transactions,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/accounts' THEN actvy_id end) AS visiteddashboard_accounts,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/alerts' THEN actvy_id end) AS visiteddashboard_alerts,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'home/dashboard/credit-score/goal-and-tips/close_oldest' THEN actvy_id end) AS visiteddashboard_Creditscoretipspage,  
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx like '%yodlee/login%'  and field_nm like 'request:getProviderDetails:success' THEN actvy_id end) AS linked_bankaccount,             
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
      ('blog/finance/30-percent-credit-utilization-ratio-rule') THEN actvy_id END) AS visited_30percentcreditutilizationratiorule,--8k monthly pv's
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/authorized-user-credit-score') THEN actvy_id END) AS visited_blogfinanceauthorizedusercreditscore, -- 8-10k monthly pv's
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/consolidate-credit-card-debt-personal-loan') THEN actvy_id END) AS visited_blogfinanceconsolidatecreditcarddebtpersonalloan, -- 14k monthly pv's                   
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/credit-report-soft-hard-pull-difference') THEN actvy_id END) AS visited_blogfinancecreditreportsofthardpulldifference, -- 7k monthly pv's                   
       COUNT(DISTINCT CASE WHEN actvy_type_cd = 'PAGE_VIEW' AND page_path_tx IN 
       ('blog/finance/credit-score-pay-debt') THEN actvy_id END) AS visited_blogfinancecreditscorepaydebt, -- 12k monthly pv's                   
        max(form_input_change) AS form_input_change
FROM form_change_data a
LEFT JOIN dw_views.dw_actvy_enriched b
        ON a.user_id = b.user_id
        AND a.txn_ts >= actvy_ts
WHERE  
transacted = 1
AND   b.dw_eff_dt  >= current_date-15
GROUP BY 1;


drop table if exists tu_attributes;
CREATE TEMP TABLE tu_attributes AS
SELECT  a.user_id,
       a.transacted,
       b.vantage_cr_scr_3_nr,
       b.cr_scr_pop_rnk,
       b.acct_ct,
       b.clsd_acct_ct,
       b.dlqnt_acct_ct,
       b.drgtry_acct_ct,
       b.inqry_ct,
       b.open_acct_ct,
       b.pub_rec_ct,
       b.rcnt_inqry_ct,
       b.on_time_pmt_pct_nr,
       b.pct_utlzn_nr,
       b.tot_cr_age_nr,
       b.tot_avail_cr_nr,
       b.tot_bal_am,
       b.tot_mly_pmt_am
from users2 a
left join 
dw_pud_views.dw_identity_tu_credit_rprt_profile_d b
on a.user_id=b.user_id and date(a.txn_ts) >= b.dw_eff_dt and date(a.txn_ts) <=  b.dw_expr_dt
where transacted = 1
UNION ALL
SELECT  a.user_id,
       a.transacted,
       AVG(b.vantage_cr_scr_3_nr) as vantage_cr_scr_3_nr,
       AVG(b.cr_scr_pop_rnk) as cr_scr_pop_rnk,
       AVG(b.acct_ct) as acct_ct,
       AVG(b.clsd_acct_ct) as clsd_acct_ct,
       AVG(b.dlqnt_acct_ct) as dlqnt_acct_ct,
       AVG(b.drgtry_acct_ct) as drgtry_acct_ct,
       AVG(b.inqry_ct) as inqry_ct,
       AVG(b.open_acct_ct) as open_acct_ct,
       AVG(b.pub_rec_ct) as pub_rec_ct,
       AVG(b.rcnt_inqry_ct) as rcnt_inqry_ct,
       AVG(b.on_time_pmt_pct_nr) as on_time_pmt_pct_nr,
       AVG(b.pct_utlzn_nr) as pct_utlzn_nr,
       AVG(b.tot_cr_age_nr) as tot_cr_age_nr, 
       AVG(b.tot_avail_cr_nr) as tot_avail_cr_nr,
       AVG(b.tot_bal_am) as tot_bal_am,
       AVG(b.tot_mly_pmt_am) as tot_mly_pmt_am
from users2 a
left join 
dw_pud_views.dw_identity_tu_credit_rprt_profile_d b
on a.user_id=b.user_id and b.dw_eff_dt >= current_date-15 and b.dw_expr_dt >= current_date-15
where transacted = 0
group by 1,2;

/* 
Do all checks 
select *  from tu_attributes;
select count(*) from tu_attributes;
select count(user_id) from tu_attributes
where vantage_cr_scr_3_nr is not null and transacted =0;
-- 83,643
select count(user_id) from tu_attributes
where vantage_cr_scr_3_nr is not null and transacted =1;
-- get 5374 people
select user_id,count(*) from tu_attributes
group by 1
order by 2 desc;
*/

-- clicked apply now sample user = 577537a9-f9ed-41b1-bc1a-b6e10b5e62a3
-- NOT clicked apply now sample user = 7be49a0f-6d92-4473-b6f7-c4fe0b757f7c

--select * from tu_attributes where user_id = '29f85ff4-ca55-408c-b446-3fbc1418677f';
--
--select * from dw_pud_report.dw_identity_tu_credit_rprt_profile_d where user_id = '00206c5a-ecab-4862-b993-6ae870045a10';

/* distinct rcmnd_type_cd in sept 
AUTO_INSURANCE_RECOMMENDATION
BILLSHARK_SETUP_REC
BILLSHARK_STATUS_REC
GOAL_CONFIG_REC
GOAL_PROGRESS_REC
LOW_FEE_CHECKING_ACC
MORTGAGE_REFINANCE
NET_WORTH_CALCULATION
PERSONAL_LOAN
PERSONAL_LOAN_OFFER
STUDENT_LOAN_REFINANCE
*/

drop table if exists feedcards_imprressattributes;
CREATE TEMP TABLE feedcards_imprressattributes AS
SELECT 
a.user_id,
a.transacted,
a.txn_ts,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_MONITORING_ALERT' THEN dw_feed_elem_imprsn_id end) AS CREDITMONITORINGALERT_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_SCORE_SIMULATION' THEN dw_feed_elem_imprsn_id end) AS CREDITSCORESIMULATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARD_APPLICATION' THEN dw_feed_elem_imprsn_id end) AS CREDITCARDAPPLICATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARDS_QUIZ_RECOMMENDATION' THEN dw_feed_elem_imprsn_id end) AS CREDITCARDSQUIZRECOMMENDATION_Impression,            
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BLOG_CONTENT' THEN dw_feed_elem_imprsn_id end) AS BLOGCONTENTRECOMMENDATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'AUTO_INSURANCE_RECOMMENDATION' THEN dw_feed_elem_imprsn_id end) AS AUTOINSURANCE_RECOMMENDATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_SETUP_REC' THEN dw_feed_elem_imprsn_id end) AS BILLSHARKSETUP_REC_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_STATUS_REC' THEN dw_feed_elem_imprsn_id end) AS BILLSHARKSTATUS_REC_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_CONFIG_REC' THEN dw_feed_elem_imprsn_id end) AS GOALCONFIG_REC_Impression,            
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_PROGRESS_REC' THEN dw_feed_elem_imprsn_id end) AS GOALPROGRESS_REC_Impression,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'LOW_FEE_CHECKING_ACC' THEN dw_feed_elem_imprsn_id end) AS LOWFEE_CHECKINGACC_RECOMMENDATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'MORTGAGE_REFINANCE' THEN dw_feed_elem_imprsn_id end) AS MORTGAGE_REFINANCE_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'NET_WORTH_CALCULATION' THEN dw_feed_elem_imprsn_id end) AS NETWORTHCALCULATION_REC_Impression,            
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN' THEN dw_feed_elem_imprsn_id end) AS PERSONALLOAN_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN_OFFER' THEN dw_feed_elem_imprsn_id end) AS PERSONALLOAN_OFFER_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'STUDENT_LOAN_REFINANCE' THEN dw_feed_elem_imprsn_id end) AS GSTUDENTLOANREFINANCE_Impression
from users2 a
left join 
DW_REPORT.dw_feed_elem_imprsn_event_f b
on a.user_id=b.user_id and DATE(b.IMPRSN_UTC_TS) < a.txn_ts
where a.transacted = 1
AND   DATE(b.IMPRSN_UTC_TS)  >= current_date-15
group by 1,2,3
-- 839 PEOPLE
UNION ALL 
SELECT 
a.user_id,
a.transacted,
a.txn_ts,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_MONITORING_ALERT' THEN dw_feed_elem_imprsn_id end) AS CREDITMONITORINGALERT_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_SCORE_SIMULATION' THEN dw_feed_elem_imprsn_id end) AS CREDITSCORESIMULATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARD_APPLICATION' THEN dw_feed_elem_imprsn_id end) AS CREDITCARDAPPLICATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARDS_QUIZ_RECOMMENDATION' THEN dw_feed_elem_imprsn_id end) AS CREDITCARDSQUIZRECOMMENDATION_Impression,            
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BLOG_CONTENT' THEN dw_feed_elem_imprsn_id end) AS BLOGCONTENTRECOMMENDATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'AUTO_INSURANCE_RECOMMENDATION' THEN dw_feed_elem_imprsn_id end) AS AUTOINSURANCE_RECOMMENDATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_SETUP_REC' THEN dw_feed_elem_imprsn_id end) AS BILLSHARKSETUP_REC_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_STATUS_REC' THEN dw_feed_elem_imprsn_id end) AS BILLSHARKSTATUS_REC_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_CONFIG_REC' THEN dw_feed_elem_imprsn_id end) AS GOALCONFIG_REC_Impression,            
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_PROGRESS_REC' THEN dw_feed_elem_imprsn_id end) AS GOALPROGRESS_REC_Impression,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'LOW_FEE_CHECKING_ACC' THEN dw_feed_elem_imprsn_id end) AS LOWFEE_CHECKINGACC_RECOMMENDATION_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'MORTGAGE_REFINANCE' THEN dw_feed_elem_imprsn_id end) AS MORTGAGE_REFINANCE_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'NET_WORTH_CALCULATION' THEN dw_feed_elem_imprsn_id end) AS NETWORTHCALCULATION_REC_Impression,            
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN' THEN dw_feed_elem_imprsn_id end) AS PERSONALLOAN_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN_OFFER' THEN dw_feed_elem_imprsn_id end) AS PERSONALLOAN_OFFER_Impression,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'STUDENT_LOAN_REFINANCE' THEN dw_feed_elem_imprsn_id end) AS GSTUDENTLOANREFINANCE_Impression
from users2 a
left join 
DW_REPORT.dw_feed_elem_imprsn_event_f b
on a.user_id=b.user_id 
where a.transacted = 0
AND   DATE(b.IMPRSN_UTC_TS)  >= current_date-15
group by 1,2,3
-- 87,458 PEOPLE
UNION ALL
SELECT 
a.user_id,
a.transacted,
a.txn_ts,
0 AS CREDITMONITORINGALERT_Impression,             
0 AS CREDITSCORESIMULATION_Impression,             
0 AS CREDITCARDAPPLICATION_Impression,             
0 AS CREDITCARDSQUIZRECOMMENDATION_Impression,            
0 AS BLOGCONTENTRECOMMENDATION_Impression,             
0 AS AUTOINSURANCE_RECOMMENDATION_Impression,             
0 AS BILLSHARKSETUP_REC_Impression,             
0 AS BILLSHARKSTATUS_REC_Impression,             
0 AS GOALCONFIG_REC_Impression,            
0 AS GOALPROGRESS_REC_Impression,
0 AS LOWFEE_CHECKINGACC_RECOMMENDATION_Impression,             
0 AS MORTGAGE_REFINANCE_Impression,             
0 AS NETWORTHCALCULATION_REC_Impression,            
0 AS PERSONALLOAN_Impression,             
0 AS PERSONALLOAN_OFFER_Impression,             
0 AS GSTUDENTLOANREFINANCE_Impression         
from users2 a
WHERE USER_ID NOT IN (select user_id from DW_REPORT.dw_feed_elem_imprsn_event_f  where DATE(IMPRSN_UTC_TS)  >= current_date-15)
group by 1,2,3;

-- should give 226,188 people but getting 186889 people -- Check with John on what am i doing wrong possibly
-- 2 more reccos which im skipping for now in above -  BILLSHARK_SETUP_REC  , BLOG_CONTENT  

drop table if exists feedcards_interactattributes;
CREATE TEMP TABLE feedcards_interactattributes AS
SELECT 
a.user_id,
a.transacted,
a.txn_ts,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_MONITORING_ALERT' THEN dw_feed_elem_intactn_id end) AS CREDITMONITORINGALERT_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_SCORE_SIMULATION' THEN dw_feed_elem_intactn_id end) AS CREDITSCORESIMULATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARD_APPLICATION' THEN dw_feed_elem_intactn_id end) AS CREDITCARDAPPLICATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARDS_QUIZ_RECOMMENDATION' THEN dw_feed_elem_intactn_id end) AS CREDITCARDSQUIZRECOMMENDATION_Interaction,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BLOG_CONTENT' THEN dw_feed_elem_intactn_id end) AS BLOGCONTENTRECOMMENDATION_Interaction,                          
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'AUTO_INSURANCE_RECOMMENDATION' THEN dw_feed_elem_intactn_id end) AS AUTOINSURANCERECOMMENDATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_SETUP_REC' THEN dw_feed_elem_intactn_id end) AS BILLSHARKSETUP_REC_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_STATUS_REC' THEN dw_feed_elem_intactn_id end) AS BILLSHARKSTATUS_REC_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_CONFIG_REC' THEN dw_feed_elem_intactn_id end) AS GOALCONFIGREC_Interaction,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_PROGRESS_REC' THEN dw_feed_elem_intactn_id end) AS GOAL_PROGRESSREC_Interaction,    
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'LOW_FEE_CHECKING_ACC' THEN dw_feed_elem_intactn_id end) AS LOW_FEECHECKING_ACC_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'MORTGAGE_REFINANCE' THEN dw_feed_elem_intactn_id end) AS MORTGAGEREFINANCE_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'NET_WORTH_CALCULATION' THEN dw_feed_elem_intactn_id end) AS NETWORTHCALCULATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN' THEN dw_feed_elem_intactn_id end) AS PERSONALLOAN_Interaction,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN_OFFER' THEN dw_feed_elem_intactn_id end) AS PERSONALLOAN_OFFER_Interaction,  
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'STUDENT_LOAN_REFINANCE' THEN dw_feed_elem_intactn_id end) AS STUDENTLOANREFINANCE_Interaction   
from users2 a
left join 
DW_REPORT.dw_feed_elem_intactn_event_f b
on a.user_id=b.user_id and DATE(b.INTACTN_UTC_TS) < a.txn_ts
where a.transacted = 1
AND   DATE(b.INTACTN_UTC_TS)  >= current_date-15
group by 1,2,3
UNION ALL 
SELECT 
a.user_id,
a.transacted,
a.txn_ts,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_MONITORING_ALERT' THEN dw_feed_elem_intactn_id end) AS CREDITMONITORINGALERT_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_SCORE_SIMULATION' THEN dw_feed_elem_intactn_id end) AS CREDITSCORESIMULATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARD_APPLICATION' THEN dw_feed_elem_intactn_id end) AS CREDITCARDAPPLICATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'CREDIT_CARDS_QUIZ_RECOMMENDATION' THEN dw_feed_elem_intactn_id end) AS CREDITCARDSQUIZRECOMMENDATION_Interaction,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BLOG_CONTENT' THEN dw_feed_elem_intactn_id end) AS BLOGCONTENTRECOMMENDATION_Interaction,                          
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'AUTO_INSURANCE_RECOMMENDATION' THEN dw_feed_elem_intactn_id end) AS AUTOINSURANCERECOMMENDATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_SETUP_REC' THEN dw_feed_elem_intactn_id end) AS BILLSHARKSETUP_REC_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'BILLSHARK_STATUS_REC' THEN dw_feed_elem_intactn_id end) AS BILLSHARKSTATUS_REC_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_CONFIG_REC' THEN dw_feed_elem_intactn_id end) AS GOALCONFIGREC_Interaction,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'GOAL_PROGRESS_REC' THEN dw_feed_elem_intactn_id end) AS GOAL_PROGRESSREC_Interaction,    
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'LOW_FEE_CHECKING_ACC' THEN dw_feed_elem_intactn_id end) AS LOW_FEECHECKING_ACC_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'MORTGAGE_REFINANCE' THEN dw_feed_elem_intactn_id end) AS MORTGAGEREFINANCE_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'NET_WORTH_CALCULATION' THEN dw_feed_elem_intactn_id end) AS NETWORTHCALCULATION_Interaction,             
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN' THEN dw_feed_elem_intactn_id end) AS PERSONALLOAN_Interaction,
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'PERSONAL_LOAN_OFFER' THEN dw_feed_elem_intactn_id end) AS PERSONALLOAN_OFFER_Interaction,  
COUNT(DISTINCT CASE WHEN b.RCMND_TYPE_CD = 'STUDENT_LOAN_REFINANCE' THEN dw_feed_elem_intactn_id end) AS STUDENTLOANREFINANCE_Interaction   
from users2 a
left join 
DW_REPORT.dw_feed_elem_intactn_event_f b
on a.user_id=b.user_id 
where a.transacted = 0
AND   DATE(b.INTACTN_UTC_TS) >= current_date-15
group by 1,2,3
-- 35,678  PEOPLE
UNION ALL
SELECT 
a.user_id,
a.transacted,
a.txn_ts,
0 AS CREDITMONITORINGALERT_Interaction,             
0 AS CREDITSCORESIMULATION_Interaction,             
0 AS CREDITCARDAPPLICATION_Interaction,             
0 AS CREDITCARDSQUIZRECOMMENDATION_Interaction,
0 AS BLOGCONTENTRECOMMENDATION_Interaction,                          
0 AS AUTOINSURANCERECOMMENDATION_Interaction,             
0 AS BILLSHARKSETUP_REC_Interaction,             
0 AS BILLSHARKSTATUS_REC_Interaction,             
0 AS GOALCONFIGREC_Interaction,
0 AS GOAL_PROGRESSREC_Interaction,    
0 AS LOW_FEECHECKING_ACC_Interaction,             
0 AS MORTGAGEREFINANCE_Interaction,             
0 AS NETWORTHCALCULATION_Interaction,             
0 AS PERSONALLOAN_Interaction,
0 AS PERSONALLOAN_OFFER_Interaction,  
0 AS STUDENTLOANREFINANCE_Interaction   
from users2 a
WHERE USER_ID NOT IN (select user_id from DW_REPORT.dw_feed_elem_intactn_event_f  where DATE(INTACTN_UTC_TS) >= current_date-15) 
group by 1,2,3;



-- check for yodlee accounts
drop table if exists yodlee_integ;
CREATE TEMP TABLE yodlee_integ AS
select 
user_id, 
COUNT(DISTINCT CASE WHEN b.prvdr_stat_cd = 'ACTIVE' THEN b.PRVDR_ACCT_ID END) AS NUMOFYODLEEACCLINKED,
CASE WHEN COUNT(DISTINCT CASE WHEN b.prvdr_stat_cd = 'ACTIVE' THEN b.PRVDR_ACCT_ID END) >=1 THEN 1 ELSE 0 END AS YODLEEACCLINKED_INDICATOR
from dw_pud_views.dw_yd_prvdr_acct_d b
GROUP BY 1;

-- proxy for did the person refill pers reccs?
drop table if exists CCreccosinteraction;
CREATE TEMP TABLE CCreccosinteraction AS
select user_id, sum( case when repeatedReccosindicator >1 then 1 else 0 end) as RefilledPersReccos
from 
(
select  
USER_ID,
DW_EFF_DT,
sum (case when actvy_type_cd = 'PAGE_VIEW' AND page_path_tx = 'recommend/result' then 1 else 0 end) as repeatedReccosindicator
from dw_views.dw_actvy_enriched 
where 
dw_eff_dt >= current_date-15
group by 1,2
) 
group by 1;


-- combine ALL Data points
create temp table RecentMembers_DesktopUsers1 as
select 
       a.user_id,
       a.transacted,
       coalesce(a.reg_trk_flow_cd,'regtrkflowcd_Blank') as reg_trk_flow_cd,
       coalesce(a.reg_trk_vertical_tx,'RegVertical_Blank') as reg_trk_vertical_tx,
       coalesce(a.reg_trk_channel_cd, 'RegChannel_Blank') as reg_trk_channel_cd,
       coalesce(a.reg_pfm_nm,'RegPfm_Blank') as reg_pfm_nm,
       coalesce(a.reg_device,'RegDevice_Blank') as reg_device,
       coalesce(a.reg_traffic_source,'RegTrafficSrc_Blank') as reg_traffic_source, 
       b.had_product_detail_visit,
       b.had_tool_visit ,
       b.started_personal_rec,
       b.sawresult_personal_rec ,
       b.visited_compare,
       b.visited_bcc,
       b.had_visit_to_CC_BestOfArticle_pages,
       b.PVs,
       b.add_to_cart_interaction,
       b.clicks,
       started_CCprequal  ,
       b.finished_CCprequal         ,
       b.visiteddashboard_creditscorepage    ,         
       b.visiteddashboard_creditdashboard_homepage,
       b.visiteddashboard_transactions,
       b.visiteddashboard_accounts,
       b.visiteddashboard_alerts, 
       b.visiteddashboard_Creditscoretipspage,            
       b.visited_30percentcreditutilizationratiorule,
       b.visited_blogfinanceauthorizedusercreditscore, 
       b.visited_blogfinanceconsolidatecreditcarddebtpersonalloan,                  
       b.visited_blogfinancecreditreportsofthardpulldifference,                 
       b.visited_blogfinancecreditscorepaydebt,        
       b.form_input_change, 
       c.vantage_cr_scr_3_nr,
       c.cr_scr_pop_rnk,
       c.acct_ct,
       c.clsd_acct_ct,
       c.dlqnt_acct_ct,
       c.drgtry_acct_ct,
       c.inqry_ct,
       c.open_acct_ct,
       c.pub_rec_ct,
       c.rcnt_inqry_ct,
       c.on_time_pmt_pct_nr,
       c.pct_utlzn_nr,
       c.tot_cr_age_nr,
       c.tot_avail_cr_nr,
       c.tot_bal_am,
       c.tot_mly_pmt_am,
       d.CREDITMONITORINGALERT_Impression,             
       d.CREDITSCORESIMULATION_Impression,             
       d.CREDITCARDAPPLICATION_Impression,             
       d.CREDITCARDSQUIZRECOMMENDATION_Impression,            
       d.BLOGCONTENTRECOMMENDATION_Impression,             
       d.AUTOINSURANCE_RECOMMENDATION_Impression,             
       d.BILLSHARKSETUP_REC_Impression,             
       d.BILLSHARKSTATUS_REC_Impression,             
       d.GOALCONFIG_REC_Impression,            
       d.GOALPROGRESS_REC_Impression,
       d.LOWFEE_CHECKINGACC_RECOMMENDATION_Impression,             
       d.MORTGAGE_REFINANCE_Impression,             
       d.NETWORTHCALCULATION_REC_Impression,            
       d.PERSONALLOAN_Impression,             
       d.PERSONALLOAN_OFFER_Impression,             
       d.GSTUDENTLOANREFINANCE_Impression,
       e.CREDITMONITORINGALERT_Interaction,             
       e.CREDITSCORESIMULATION_Interaction,             
       e.CREDITCARDAPPLICATION_Interaction,             
       e.CREDITCARDSQUIZRECOMMENDATION_Interaction,
       e.BLOGCONTENTRECOMMENDATION_Interaction,                          
       e.AUTOINSURANCERECOMMENDATION_Interaction,             
       e.BILLSHARKSETUP_REC_Interaction,             
       e.BILLSHARKSTATUS_REC_Interaction,             
       e.GOALCONFIGREC_Interaction,
       e.GOAL_PROGRESSREC_Interaction,    
       e.LOW_FEECHECKING_ACC_Interaction,             
       e.MORTGAGEREFINANCE_Interaction,             
       e.NETWORTHCALCULATION_Interaction,             
       e.PERSONALLOAN_Interaction,
       e.PERSONALLOAN_OFFER_Interaction,  
       e.STUDENTLOANREFINANCE_Interaction,    
       f.NUMOFYODLEEACCLINKED,
       f.YODLEEACCLINKED_INDICATOR,
       g.RefilledPersReccos
from users2 a
left join activity_table b on a.user_id = b.user_id 
left join tu_attributes c on a.user_id = c.user_id
left join feedcards_imprressattributes d on a.user_id = d.user_id
left join feedcards_interactattributes e on a.user_id = e.user_id 
left join yodlee_integ f on a.user_id = f.user_id
left join CCreccosinteraction g on a.user_id = g.user_id  ;


-- now create a temp table to pick only those people who have the vantage score
create temp table RecentMembers_DesktopUsers_Non_blankfico1 as 
select * from RecentMembers_DesktopUsers1 where vantage_cr_scr_3_nr is not null;

-- create final table with only ~3 required attributes to give to the model to product predicted probability.
delete from dw_workarea.finaltabletogivetomodel;
insert into dw_workarea.finaltabletogivetomodel
SELECT 
user_id,
transacted,
had_product_detail_visit,
had_tool_visit,
started_personal_rec,
sawresult_personal_rec,
visited_compare,
visited_bcc,
had_visit_to_cc_bestofarticle_pages,
pvs,
add_to_cart_interaction,
clicks,
started_ccprequal,
finished_ccprequal,
visiteddashboard_creditscorepage,
visiteddashboard_creditdashboard_homepage,
visited_30percentcreditutilizationratiorule,
visited_blogfinanceauthorizedusercreditscore,
visited_blogfinanceconsolidatecreditcarddebtpersonalloan,
visited_blogfinancecreditreportsofthardpulldifference,
visited_blogfinancecreditscorepaydebt,
form_input_change,
vantage_cr_scr_3_nr,
acct_ct,
clsd_acct_ct,
dlqnt_acct_ct,
drgtry_acct_ct,
inqry_ct,
open_acct_ct,
on_time_pmt_pct_nr,
pct_utlzn_nr,
tot_cr_age_nr,
tot_avail_cr_nr,
tot_bal_am,
tot_mly_pmt_am,
creditmonitoringalert_impression,
creditscoresimulation_impression,
creditcardapplication_impression,
creditcardsquizrecommendation_impression,
blogcontentrecommendation_impression,
autoinsurance_recommendation_impression,
billsharksetup_rec_impression,
billsharkstatus_rec_impression,
goalconfig_rec_impression,
lowfee_checkingacc_recommendation_impression,
mortgage_refinance_impression,
networthcalculation_rec_impression,
personalloan_impression,
personalloan_offer_impression,
gstudentloanrefinance_impression,
creditmonitoringalert_interaction,
creditscoresimulation_interaction,
creditcardapplication_interaction,
creditcardsquizrecommendation_interaction,
blogcontentrecommendation_interaction,
autoinsurancerecommendation_interaction,
billsharksetup_rec_interaction,
billsharkstatus_rec_interaction,
goalconfigrec_interaction,
goal_progressrec_interaction,
low_feechecking_acc_interaction,
mortgagerefinance_interaction,
networthcalculation_interaction,
personalloan_interaction,
personalloan_offer_interaction,
studentloanrefinance_interaction,
numofyodleeacclinked,
yodleeacclinked_indicator,
refilledpersreccos,
case when reg_trk_flow_cd = 'basic' then 1 else 0 end as Regflow_basic,
case when reg_trk_flow_cd = 'cc-app' then 1 else 0 end as Regflow_cc_app,
case when reg_trk_flow_cd = 'credit-score' then 1 else 0 end as Regflow_credit_score,
case when reg_trk_flow_cd = 'dit' then 1 else 0 end as Regflow_dit,
case when reg_trk_flow_cd = 'error' then 1 else 0 end as Regflow_error,
case when reg_trk_flow_cd = 'other' then 1 else 0 end as Regflow_other,
case when reg_trk_flow_cd = 'personal-loans-prequal' then 1 else 0 end as personal_loans_prequal,
case when reg_trk_flow_cd = 'register-basic' then 1 else 0 end as Regflow_register_basic,
case when reg_trk_flow_cd = 'register-credit-score' then 1 else 0 end as Regflow_register_credit_score,
case when reg_trk_flow_cd = 'signin-basic' then 1 else 0 end as signin_basic,
case when reg_trk_flow_cd = 'signin-credit-score' then 1 else 0 end as Regflow_signin_credit_score,
case when reg_trk_flow_cd = 'smb-prequal' then 1 else 0 end as Regflow_smb_prequal,
case when reg_trk_flow_cd = 'unkown' then 1 else 0 end as Regflow_unkown,
case when reg_trk_vertical_tx = 'Banking' then 1 else 0 end as Regvertical_Banking,
case when reg_trk_vertical_tx = 'Credit Cards' then 1 else 0 end as Regvertical_CreditCards,
case when reg_trk_vertical_tx = 'Investing' then 1 else 0 end as Regvertical_Investing,
case when reg_trk_vertical_tx = 'Loans' then 1 else 0 end as Regvertical_Loans,
case when reg_trk_vertical_tx = 'Mortgage' then 1 else 0 end as Regvertical_Mortgage,
case when reg_trk_vertical_tx = 'Mynerdwallet' then 1 else 0 end as Regvertical_Mynerdwallet,
case when reg_trk_vertical_tx = 'Nerdwallet-Mobile' then 1 else 0 end as Regvertical_NerdwalletMobile,
case when reg_trk_vertical_tx = 'Personal Finance' then 1 else 0 end as Regvertical_PersonalFinance,
case when reg_trk_vertical_tx = 'RegVertical_Blank' then 1 else 0 end as RegVertical_Blank,
case when 
   reg_trk_vertical_tx <> 'Banking' 
or reg_trk_vertical_tx <> 'Credit Cards' 
or reg_trk_vertical_tx <> 'Investing' 
or reg_trk_vertical_tx <> 'Loans' 
or reg_trk_vertical_tx <> 'Mortgage' 
or reg_trk_vertical_tx <> 'Mynerdwallet' 
or reg_trk_vertical_tx <> 'Nerdwallet-Mobile' 
or reg_trk_vertical_tx <> 'Personal Finance' 
or reg_trk_vertical_tx <> 'RegVertical_Blank' then 1 else 0 end as Regvertical_OthersRemaining,
case when reg_device = 'Tablet' then 1 else 0 end as Regdevice_Tablet,
case when reg_trk_channel_cd = 'RegChannel_Blank' then 1 else 0 end as RegChannel_Blank,
case when reg_trk_channel_cd = 'email' then 1 else 0 end as reg_trk_channel_email,
case when reg_pfm_nm = 'Other' then 1 else 0 end as reg_pltfm_Other,
case when reg_pfm_nm = 'Web' then 1 else 0 end as reg_pltfm_Web,
case when reg_traffic_source = 'Branded-HP' then 1 else 0 end as reg_traffsrc_BrandedHP,
case when reg_traffic_source = 'Display' then 1 else 0 end as reg_traffsrc_Display,
case when reg_traffic_source = 'Email' then 1 else 0 end as reg_traffsrc_Email,
case when reg_traffic_source = 'Internal' then 1 else 0 end as reg_traffsrc_Internal,
case when reg_traffic_source = 'NA' then 1 else 0 end as reg_traffsrc_NA,
case when reg_traffic_source = 'Referral' then 1 else 0 end as reg_traffsrc_Referral,
case when reg_traffic_source = 'Search' then 1 else 0 end as reg_traffsrc_Search,
case when reg_traffic_source = 'Social' then 1 else 0 end as reg_traffsrc_Social
from 
RecentMembers_DesktopUsers_Non_blankfico1
WHERE vantage_cr_scr_3_nr >=180;


-- gran t all accesses
grant all on dw_workarea.finaltabletogivetomodel to group grp_etl;
grant all on dw_workarea.finaltabletogivetomodel to group grp_etl_secured;
grant all on dw_workarea.finaltabletogivetomodel to group grp_ba_users;
grant select on dw_workarea.finaltabletogivetomodel to group grp_redash;
grant select on dw_workarea.finaltabletogivetomodel to group grp_data_users;
grant select on dw_workarea.finaltabletogivetomodel to group grp_data_users_secured;
grant select on dw_workarea.finaltabletogivetomodel to group grp_meta_nerd;
grant select on dw_workarea.finaltabletogivetomodel to group grp_bi_tool_users;
