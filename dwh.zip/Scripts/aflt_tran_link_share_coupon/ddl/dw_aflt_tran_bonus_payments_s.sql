CREATE TABLE dw_stage.dw_aflt_tran_bonus_payments_s
(
   aflt_network_id        bigint,
   aflt_fin_tran_type_cd  varchar(3000),
   src_prod_nm            varchar(3000),
   prog_nm                varchar(3000),
   dw_eff_dt              date,
   commission_am          numeric(10,2)
);
GRANT SELECT ON dw_stage.dw_aflt_tran_bonus_payments_s TO group grp_data_users;
GRANT ALL ON dw_stage.dw_aflt_tran_bonus_payments_s TO group grp_etl;
