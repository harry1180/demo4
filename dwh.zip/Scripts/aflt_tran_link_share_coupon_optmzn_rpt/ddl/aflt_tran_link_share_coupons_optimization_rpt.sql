DROP TABLE IF EXISTS dw_stage.aflt_tran_link_share_coupons_optimization_rpt CASCADE;

CREATE TABLE dw_stage.aflt_tran_link_share_coupons_optimization_rpt
(
   member_id         varchar(256),
   merchant_id       varchar(256),
   merchant_name     varchar(256),
   order_id          varchar(256),
   transaction_date  varchar(256),
   transaction_time  varchar(256),
   sku_number        varchar(256),
   product_nm        varchar(256),
   sales             numeric(10,2),
   quntity           numeric(10,2),
   commissions       numeric(10,2)
);

GRANT REFERENCES, UNKNOWN, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_stage.aflt_tran_link_share_coupons_optimization_rpt TO group grp_etl;
GRANT INSERT, RULE, UNKNOWN, DELETE, TRIGGER, REFERENCES, SELECT, UPDATE ON dw_stage.aflt_tran_link_share_coupons_optimization_rpt TO nw_dwh_etl;
GRANT INSERT, SELECT, UNKNOWN, DELETE, TRIGGER, UPDATE, RULE, REFERENCES ON dw_stage.aflt_tran_link_share_coupons_optimization_rpt TO group grp_ba_users;

