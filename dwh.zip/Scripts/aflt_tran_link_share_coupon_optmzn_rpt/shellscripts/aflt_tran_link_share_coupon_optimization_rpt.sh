job_name='aflt_tran_link_share_coupon_optmzn_rpt'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source /etc/passwords.ctrl
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
source_bucket=$Events_dwh_bucket
DAYS=${1:-64}
end_date="$(date +'%Y-%m-%d')"
echo $end_date
start_date="$(date "+%Y-%m-%d" -d "$DAYS days ago")"
echo "start_date :- "$start_date
step=4
date_add=$step
temp_date="$(date "+%Y-%m-%d" -d "$start_date+$step days")"
aflt_tran_id=-15

echo 'start_date                :-   '${start_date}
echo 'end_date                  :-   '${end_date}
echo 'source_bucket             :-   '${source_bucket}
echo 'aflt_tran_id              :-   '${aflt_tran_id}
echo '+----------+----------+----------+----------+----------+----------+'



bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Removing Data Files" "Started"
find $Linux_Input -name \*.tmp -exec rm {} \; || true
find $Linux_Input -name \*.gz -exec rm {} \; || true
echo_processing_step ${job_name} "Removing Data Files" "Completed"

echo_processing_step ${job_name} "Removing S3 Files" "Started"
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Input','$source_bucket','*.gz')" || true
echo_processing_step ${job_name} "Removing S3 Files" "Completed"

echo_processing_step ${job_name} "Calling Python script to bring in the API Data" "Started"
if (("$DAYS" >= 4)); then
 while [ $step -le $DAYS ]
 do

python ${dwh_common_base_dir}/aflt_tran_link_share_optimization_rpt_api_pull.py $start_date $temp_date $linkshare_api_key $Linux_Input/post_lscoupons.csv
 
mv $Linux_Input/post_lscoupons.csv $Linux_Input/'post_lscoupons_'$start_date'.csv' || true
 start_date="$(date "+%Y-%m-%d" -d "$start_date+$(($date_add+1)) days")"
 step=$(($step+4))
 echo $step
 temp_date="$(date "+%Y-%m-%d" -d "$start_date+$date_add days")"
done
fi
echo_processing_step ${job_name} "Calling Python script to bring in the API Data" "Completed"


echo_processing_step ${job_name} "GZIP file and moving to S3" "Started"
for f in ${Linux_Input}*.csv
do
gzip $f
gzip_file=${f}'.gz'
python -c "from s3_modules import s3_file_upload; s3_file_upload('${gzip_file}', '$source_bucket', '$S3_Events_Input', s3_file_nm='default')" || true
done
echo_processing_step ${job_name} "GZIP file and moving to S3" "Completed"

echo_processing_step ${job_name} "Delete data from Stage table" "Started"
python ${dwh_common_base_dir}/redshift_purge_table.py "dw_stage.aflt_tran_link_share_coupons_optimization_rpt"
echo_processing_step ${job_name} "Delete data from Stage table" "Completed"

echo_processing_step ${job_name} "Copy Data to stage table" "Started"
bash ${dwh_common_base_dir}/redshift_copy_function.sh dw_stage.aflt_tran_link_share_coupons_optimization_rpt /aflt_tran_link_share_coupon_optmzn_rpt/input/ post_lscoupons  header
echo_processing_step ${job_name} "Copy Data to stage table" "Completed"

echo_processing_step ${job_name} "Delete data from post Stage table" "Started"
python ${dwh_common_base_dir}/redshift_purge_table.py "dw_stage.dw_aflt_tran_link_share_coupons_optimization_rpt_post_stg"
echo_processing_step ${job_name} "Delete data from post Stage table" "Completed"

echo_processing_step ${job_name} "Insert Data to post stage table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/insert_link_share_coupons_optmzn_rpt_post_stg.sql
echo_processing_step ${job_name} "Insert Data to post stage table" "Completed"

echo_processing_step ${job_name} "Loading data to fact table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/insert_link_share_coupons_fact_optmzn_rpt.sql
echo_processing_step ${job_name} "Loading data to fact table" "Completed"

echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Started"
python -c "from tran_log_modules import insert_log; insert_log($aflt_tran_id);"
echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

