job_name='bshrk_bills_s'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'

if [ -z $1 ] ; then
  from_date="$(date -d '-2 days' '+%Y-%m-%d')"
else
  from_date="$1"
fi 

if [ -z $2 ] ; then
  to_date="$(date -d '1 days' +'%Y-%m-%d')"
else
  to_date="$2"
fi

echo 'from_date                  :-   '${from_date}
echo 'to_date                    :-   '${to_date}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning dwh S3 files" "Started"
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Output','$Events_dwh_pud_bucket','bshrk_bills_s.csv.gz')" || true
echo_processing_step ${job_name} "Cleaning dwh S3 files" "Completed"

echo_processing_step ${job_name} "Cleaning local files" "Started"
find $Linux_Input   -name \*.csv.\* -exec rm {} \; || true
find $Linux_Output  -name \*.csv.\* -exec rm {} \; || true
find $Linux_Archive -name \*.csv.\* -exec rm {} \; || true
echo_processing_step ${job_name} "Cleaning local files" "Completed"

output_file="bshrk_bills_s.csv"

echo_processing_step ${job_name} "Copy data from Aurora to local" "Started"

query=`cat ${dwh_scripts_base_dir}/bshrk_bills_s/sqlfiles/bshrk_bills_s.sql | sed -e "s|:v1|$Linux_Output|g"`
echo "mysql_query is ["$query"]"

mysql --host "$aurora_dbetl_dbHost" --user "$aurora_dbetl_username" --password="$aurora_dbetl_password" --database "bills" --column-names=0 --connect_timeout=28800 --execute="$query" > ${Linux_Output}${output_file}

echo_processing_step ${job_name} "Copy data from Aurora to local" "Completed"

echo_processing_step ${job_name} "Compress and move data to s3" "Started"


gzip ${Linux_Output}${output_file} 
python -c "from s3_modules import s3_file_upload; s3_file_upload('${Linux_Output}${output_file}.gz', '$Events_dwh_pud_bucket', '$S3_Events_Output','${output_file}.gz')" || true
echo_processing_step ${job_name} "Compress and move data to s3" "Completed"


echo_processing_step ${job_name} "Loading data file into Redshift stage table" "Started"

python "${dwh_common_base_dir}/redshift_purge_table.py" "${pudstagedb}.bshrk_bills_s"

copy_query="copy dw_pud_stage.bshrk_bills_s
from 's3://"$Events_dwh_pud_bucket"/"$job_name"/output/"$job_name"' 
credentials '$s3_prod_load_creds' gzip delimiter '\t' dateformat 'auto' NULL AS 'NULL' 
ACCEPTINVCHARS 
COMPUPDATE OFF STATUPDATE OFF
BLANKSASNULL 
EMPTYASNULL;
"

psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$copy_query"


echo_processing_step ${job_name} "Loading data file into Redshift stage table" "Completed"

echo_processing_step ${job_name} "Cleaning local files" "Started"
find $Linux_Input   -name \*.csv.\* -exec rm {} \; || true
find $Linux_Output  -name \*.csv.\* -exec rm {} \; || true
find $Linux_Archive -name \*.csv.\* -exec rm {} \; || true
echo_processing_step ${job_name} "Cleaning local files" "Completed"


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
