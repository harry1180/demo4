UPDATE
:var_report_schema.dw_aflt_tran_clickmeter_f
SET dw_site_visitor_id = COALESCE(clicks_event_banking.dw_site_visitor_id,'-999999999')  ,
    dw_site_prod_sk=   COALESCE(clicks_event_banking.dw_site_prod_sk,'-999999999') ,
    dw_site_prod_nm =   COALESCE(clicks_event_banking.src_prod_nm,'Could not Identify the right product to this Transaction')  ,
    dw_click_id =  COALESCE(clicks_event_banking.dw_click_id,'Not Fount In Clicks')  ,
    dw_click_src_id = COALESCE(clicks_event_banking.dw_src_sys_id,-999999999)  ,
    src_clicks_utc_ts =  clicks_event_banking.click_utc_ts,
    dw_session_id =  clicks_event_banking.dw_session_id   ,
    dw_click_page_sk = COALESCE(clicks_event_banking.dw_page_sk,-1)   ,
    dw_click_user_agent_id = COALESCE(clicks_event_banking.dw_user_agent_id,1)
FROM
(
    SELECT min(click_utc_ts) as click_utc_ts, min(dw_session_id) as dw_session_id, min(dw_page_sk) as dw_page_sk, min(dw_user_agent_id) as dw_user_agent_id, min(dw_site_visitor_id) as dw_site_visitor_id, min(dw_site_prod_sk) as dw_site_prod_sk , min(src_prod_nm) as src_prod_nm, min(dw_click_id) as dw_click_id, min(dw_src_sys_id) as dw_src_sys_id, src_unique_click_id
    FROM dw_report.dw_clicks_event_f
    WHERE dw_src_sys_id = 8
    AND   dw_eff_dt BETWEEN :'start_date' AND :'end_date'
    GROUP BY src_unique_click_id
) clicks_event_banking
WHERE :var_report_schema.dw_aflt_tran_clickmeter_f.src_unique_click_id = clicks_event_banking.src_unique_click_id
AND :var_report_schema.dw_aflt_tran_clickmeter_f.dw_click_id = 'Not Fount In Clicks'
;
