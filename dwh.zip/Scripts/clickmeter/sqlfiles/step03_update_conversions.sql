CREATE TEMP TABLE conversions AS (
    WITH
        stage_conversions as (
            Select func_sha1(coalesce(click_id,'NA')||coalesce(accesstime,'9999-01-01')||coalesce(ip,'NA')||coalesce(browsername,'NA')||coalesce(datapointid,-9999999)||coalesce(isunique,-999999)) AS aflt_network_tran_id,
               accesstime,
               coalesce(conversion_in, False) as conversion_in
            FROM :var_stage_schema.clickmeter_s
        ),
        stage_conversions_dedup as (
            SELECT *, row_number() OVER (PARTITION BY aflt_network_tran_id ORDER BY accesstime) as dedup
            FROM stage_conversions
        )
    SELECT
        stg.aflt_network_tran_id,
        stg.conversion_in
    FROM stage_conversions_dedup stg
    WHERE stg.dedup = 1
    )
;

UPDATE :var_report_schema.dw_aflt_tran_clickmeter_f
   SET conversion_in = conversions.conversion_in
FROM conversions
WHERE :var_report_schema.dw_aflt_tran_clickmeter_f.aflt_network_tran_id = conversions.aflt_network_tran_id
AND   :var_report_schema.dw_aflt_tran_clickmeter_f.conversion_in <> conversions.conversion_in
;
