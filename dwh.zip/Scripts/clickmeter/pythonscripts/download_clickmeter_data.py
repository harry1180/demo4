import functools
import logging
import multiprocessing
import os
import pwd
import re
import requests
import sys
import ujson as json
import urllib
import urlparse

from datetime import datetime

from nw_retry import nw_retry, REQUEST_EXCEPTIONS

logging_format = '[%(levelname)-8s] %(name)s - %(message)s'
if pwd.getpwuid(os.geteuid())[0] != 'airflow':
    logging_format = '%(asctime)s ' + logging_format

logging.basicConfig(format=logging_format, level=logging.INFO)
logger = logging.getLogger(__name__)


def extract_click_cpc(queryparm):
    """
    Extract click_id and cpc from url query parameters
    """
    # Query string is URL-encoded. Decode it.
    decoded_queryparm = urllib.unquote_plus(queryparm)

    # Convert the query string into a Python dictionary
    qp_dict = dict(urlparse.parse_qsl(decoded_queryparm))

    click_id = qp_dict.get('click_id', '')
    cpc = qp_dict.get('cpc', None)
    if cpc in ['', 'NULL']:
        cpc = None

    # If the CPC starts with numbers but then has a non-numeric character, strip off everything after the
    # numbers.
    if cpc is not None and re.match('^[0-9.]+[^0-9.]', cpc):
        orig_cpc = cpc
        cpc = re.sub(r'^([0-9.]+)[^0-9.].*$', r'\1', cpc)
        logger.warning("Click ID '{}' has CPC with extraneous characters '{}', replacing it with '{}'".format(click_id, orig_cpc, cpc))

    if cpc is not None:
        try:
            cpc = float(cpc)
        except:
            logger.warning("Click ID '{}': Failed to convert CPC to a number: {}".format(click_id, cpc))
            cpc = None

    return click_id, cpc


@nw_retry(REQUEST_EXCEPTIONS)
def get_active_groups(api_key, offset):

    response = requests.get("http://apiv2.clickmeter.com/groups",
                            headers={"Content-Type": "text/json", "X-Clickmeter-Authkey": api_key},
                            params={"limit": 100, "status": "active", 'offset': offset})

    response.raise_for_status()
    return json.loads(response.text)


@nw_retry(REQUEST_EXCEPTIONS)
def get_active_datapoints(api_key, group_id, offset):

    response = requests.get("http://apiv2.clickmeter.com/groups/{id}/datapoints".format(id=group_id),
                            headers={"Content-Type": "text/json", "X-Clickmeter-Authkey": api_key},
                            params={"limit": 100, "status": "active", 'offset': offset})

    response.raise_for_status()
    return json.loads(response.text)


@nw_retry(REQUEST_EXCEPTIONS, logger=logger)
def get_hits(datapoint_id, api_key, offset, date_from, date_to):

    response = requests.get("http://apiv2.clickmeter.com/datapoints/{id}/hits".format(id=datapoint_id),
                            headers={"Content-Type": "text/json", "X-Clickmeter-Authkey": api_key},
                            params={"limit": 100, "timeframe": "custom", 'fromDay': date_from, 'toDay': date_to,
                                    'offset': offset})

    response.raise_for_status()
    return json.loads(response.text)


def collect_groups(api_key):
    """
    Paginate through all active groups
    """
    paginate = True
    offset = ''
    group_set = []
    while paginate:
        datapoints = get_active_groups(api_key, offset)
        for point in datapoints['entities']:
            group_set.append(point)
        if datapoints.get('lastKey', None):
            offset = datapoints['lastKey']
        else:
            paginate = False
    return group_set


def collect_datapoints(api_key, group_id):
    """
    Paginate through all active datapoints by group
    """
    paginate = True
    offset = ''
    datapoint_set = []
    while paginate:
        datapoints = get_active_datapoints(api_key, group_id, offset)
        for point in datapoints['entities']:
            datapoint_set.append(point['id'])
        if datapoints.get('lastKey', None):
            offset = datapoints['lastKey']
        else:
            paginate = False
    return datapoint_set


def collect_hits(datapoint_id, api_key, date_from, date_to):
    """
    Paginate through all hits per datapoint within date range
    """

    hit_list = []
    paginate = True
    offset = ''
    try:
        while paginate:
            hits = get_hits(datapoint_id, api_key, offset, date_from, date_to)
            if not hits.get('hits'):
                logger.warning('No HITS for Datapoint ID: {}'.format(datapoint_id))
            for one_record in hits['hits']:
                one_dict = {}

                one_dict['accessTime'] = one_record.get('accessTime', None)
                one_dict['ip'] = one_record.get('ip', None)
                one_dict['isSpider'] = one_record.get('isSpider', None)
                one_dict['isUnique'] = one_record.get('isUnique', None)

                one_dict['datapointId'] = one_record['entity'].get('datapointId')
                one_dict['creationDate'] = one_record['entity'].get('creationDate')
                one_dict['datapointName'] = one_record['entity'].get('datapointName')
                one_dict['datapointTitle'] = one_record['entity'].get('datapointTitle')
                one_dict['datapointType'] = one_record['entity'].get('datapointType')
                one_dict['destinationUrl'] = one_record['entity'].get('destinationUrl')
                one_dict['groupId'] = one_record['entity'].get('groupId')
                one_dict['groupName'] = one_record['entity'].get('groupName')
                one_dict['trackingCode'] = one_record['entity'].get('trackingCode')

                if one_record.get('browser'):
                    one_dict['browserType'] = one_record['browser'].get('browserType')
                    one_dict['browserName'] = one_record['browser'].get('name')

                if one_record.get('location'):
                    one_dict['city'] = one_record['location'].get('city')
                    one_dict['country'] = one_record['location'].get('country')
                    one_dict['postalcode'] = one_record['location'].get('postalcode')

                if one_record.get('os'):
                    one_dict['osName'] = one_record['os'].get('name')

                one_dict['queryParams'] = one_record.get('queryParams')
                if one_dict['queryParams']:
                    click_id, cpc_am = extract_click_cpc(one_dict['queryParams'])
                    one_dict['click_id'] = click_id
                    one_dict['cpc'] = cpc_am

                if one_record.get('conversions'):
                    one_dict['conversion_in'] = True

                hit_list.append(one_dict)

            if hits.get('lastKey', None):
                offset = hits['lastKey']
            else:
                paginate = False
    except:
        logger.warning('Something went wrong for Datapoint ID: {}'.format(datapoint_id))

    return hit_list


def main(api_key, output_file, date_from, date_to, num_processes):

    # Convert to clickmeter accepted timestamp string
    try:
        date_from = datetime.strptime(date_from, '%Y-%m-%d').strftime('%Y%m%d')
        date_to = datetime.strptime(date_to, '%Y-%m-%d').strftime('%Y%m%d')
    except:
        logger.error('Input date params must be of format YYYY-mm-dd')
        sys.exit(1)

    groups = collect_groups(api_key)
    datapoints = []
    for group_id in groups:
        for datapoint_id in collect_datapoints(api_key, group_id['id']):
            datapoints.append(datapoint_id)
    pool = multiprocessing.Pool(processes=num_processes)
    logger.info('Using multiprocessing with pool size={}'.format(num_processes))
    func = functools.partial(collect_hits, api_key=api_key, date_from=date_from, date_to=date_to)
    all_hits = pool.map(func, datapoints)
    pool.close()
    pool.join()
    with open(output_file, 'w') as json_out:
        for row in all_hits:
            for datapoint_dict in row:
                json.dump(datapoint_dict, json_out, escape_forward_slashes=False)
                json_out.write('\n')



if __name__ == '__main__':

    if len(sys.argv) < 5:
        print('Usage: download_clickmeter_data.py <api_key> <output_file> <from_date YYYY-mm-dd> <to_date YYYY-mm-dd>]')
        sys.exit(1)

    api_key = sys.argv[1]
    from_date = sys.argv[2]
    to_date = sys.argv[3]
    output_file = sys.argv[4]
    try:
        num_processes = sys.argv[5]
    except:
        num_processes = 4

    logger.info('Clickmeter API extract begins')
    logger.info('Processing API for dates {} to {}'.format(from_date, to_date))

    main(api_key, output_file, from_date, to_date, num_processes)

    logger.info('Clickmeter API extract ends')
