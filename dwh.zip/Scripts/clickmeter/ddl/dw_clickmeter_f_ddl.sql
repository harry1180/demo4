DROP TABLE IF EXISTS "dw_report"."dw_aflt_tran_clickmeter_f";
CREATE TABLE "dw_report"."dw_aflt_tran_clickmeter_f"
(
	"aflt_network_tran_id" VARCHAR(256)   ENCODE lzo
	,"aflt_network_id" INTEGER   ENCODE lzo
	,"aflt_fin_tran_type_cd" VARCHAR(256)   ENCODE lzo
	,"dw_eff_dt" DATE   ENCODE lzo
	,"tran_post_dt" DATE   ENCODE lzo
	,"tran_click_dt" DATE   ENCODE lzo
	,"tran_post_ts" TIMESTAMP WITHOUT TIME ZONE   ENCODE lzo
	,"tran_click_ts" TIMESTAMP WITHOUT TIME ZONE   ENCODE lzo
	,"src_clicks_utc_ts" TIMESTAMP WITHOUT TIME ZONE   ENCODE lzo
	,"src_prod_nm" VARCHAR(256)   ENCODE lzo
	,"dw_site_visitor_id" VARCHAR(256)   ENCODE lzo
	,"dw_site_prod_sk" VARCHAR(256)   ENCODE lzo
	,"dw_site_prod_nm" VARCHAR(256)   ENCODE lzo
	,"prog_nm" VARCHAR(256)   ENCODE lzo
	,"src_unique_click_id" VARCHAR(256)   ENCODE lzo
	,"aflt_catg_nm" VARCHAR(256)   ENCODE lzo
	,"dw_click_id" VARCHAR(500)   ENCODE lzo
	,"dw_click_src_id" INTEGER   ENCODE lzo
	,"src_sys_id" INTEGER   ENCODE lzo
	,"dw_session_id" VARCHAR(120)   ENCODE lzo
	,"dw_click_page_sk" BIGINT   ENCODE lzo
	,"dw_click_user_agent_id" INTEGER   ENCODE lzo
	,"dw_catg_nm" VARCHAR(256)   ENCODE lzo
	,"commission_am" NUMERIC(10,2)   ENCODE lzo
	,"src_commission_am" NUMERIC(10,2)   ENCODE lzo
	,"merchant_am" NUMERIC(10,2)   ENCODE lzo
	,"conversion_in" BOOLEAN
	,"src_browser_nm" VARCHAR(256)   ENCODE lzo
	,"src_browser_type" VARCHAR(256)   ENCODE lzo
	,"src_city_name" VARCHAR(56)   ENCODE lzo
	,"src_postal_code" VARCHAR(56)   ENCODE lzo
	,"src_country_cd" VARCHAR(56)   ENCODE lzo
	,"src_data_point_id" INTEGER   ENCODE lzo
	,"src_data_point_title" VARCHAR(256)   ENCODE lzo
	,"src_data_point_type" VARCHAR(256)   ENCODE lzo
	,"src_destnation_url" VARCHAR(256)   ENCODE lzo
	,"src_group_id" INTEGER   ENCODE lzo
	,"src_group_nm" VARCHAR(256)   ENCODE lzo
	,"src_ip_address" VARCHAR(256)   ENCODE lzo
	,"src_is_unique_ind" VARCHAR(5)   ENCODE lzo
	,"src_is_spider_ind" VARCHAR(5)   ENCODE lzo
	,"src_query_params_txt" VARCHAR(256)   ENCODE lzo
	,"src_os_name" VARCHAR(256)   ENCODE lzo
	,"src_tracking_cd" VARCHAR(256)   ENCODE lzo
	,"dw_load_ts" TIMESTAMP WITHOUT TIME ZONE   ENCODE lzo
)
DISTSTYLE KEY
DISTKEY(aflt_network_tran_id)
SORTKEY(dw_eff_dt)
;

GRANT ALL    ON dw_report.dw_aflt_tran_clickmeter_f       TO GROUP grp_etl;
GRANT SELECT ON dw_report.dw_aflt_tran_clickmeter_f       TO GROUP grp_data_users;
ALTER TABLE     dw_report.dw_aflt_tran_clickmeter_f owner TO nw_dwh_etl;
