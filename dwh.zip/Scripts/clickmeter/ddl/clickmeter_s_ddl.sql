DROP TABLE IF EXISTS :stagedb."clickmeter_s";
CREATE TABLE :stagedb."clickmeter_s"
(
	"accesstime" TIMESTAMP WITHOUT TIME ZONE
	,"browsername" VARCHAR(300)
	,"browsertype" VARCHAR(300)
	,"city" VARCHAR(300)
	,"click_id" VARCHAR(300)
	,"conversion_in" BOOLEAN
	,"country" VARCHAR(100)
	,"cpc" NUMERIC(8,2)
	,"datapointid" BIGINT
	,"datapointtitle" VARCHAR(300)
	,"datapointtype" VARCHAR(300)
	,"destinationurl" VARCHAR(3000)
	,"groupid" BIGINT
	,"groupname" VARCHAR(300)
	,"ip" VARCHAR(30)
	,"isspider" BIGINT
	,"isunique" BIGINT
	,"osname" VARCHAR(300)
	,"postalcode" VARCHAR(30)
	,"queryparams" VARCHAR(300)
	,"trackingcode" VARCHAR(300)
)
DISTSTYLE EVEN
;

GRANT ALL    ON :stagedb.clickmeter_s       TO GROUP grp_etl;
GRANT SELECT ON :stagedb.clickmeter_s       TO GROUP grp_data_users;
ALTER TABLE     :stagedb.clickmeter_s owner TO nw_dwh_etl;
