
job_name='aflt_tran_process_cc_file'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source /etc/passwords.ctrl
#source pas.ctrl
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
# 'redshift_override' flag is controls the generation of redshift file in addition to the Hive partitions.
# if 'redshift_override' = 'no': redshift file will only be generated if no other redshift file has been generated for the day.
# if 'redshift_override' = 'yes': redshift file will always be generated.
# Defaults to 'no'
if [ -z $1 ] ; then
  redshift_override='no'
else
  redshift_override=`echo "$1" | tr '[:upper:]' '[:lower:]'`
fi

# 'sql_engine' flag is used to select between redshift/Hive file generation.
# if 'sql_engine' = 'all': both Redshift file & Hive partitions are generated.
# if 'sql_engine' = 'redshift': only Redshift file is generated (behavior similar to 'redshift_override' = 'yes')
# if 'sql_engine' = 'nerdlake': only Nerdlake/Hive partitions are generated.
# Defaults to 'all'
if [ -z $2 ] ; then
  sql_engine='all'
else
  sql_engine=`echo "$2" | tr '[:upper:]' '[:lower:]'`
fi

# 'hive_write_mode' controls whether to append or over-write existing partitions.
# if 'hive_write_mode' = 'append' : new partitions will be appended to existing partitions.
# if 'hive_write_mode' = 'overwrite' : new partitions will overwrite same existing partitions.
# Defaults to 'append'
if [ -z $3 ] ; then
   hive_write_mode='append'
else
  hive_write_mode=`echo "$3" | tr '[:upper:]' '[:lower:]'`
fi

if [ -z $4 ] ; then
  from_dt="$(date -d '-2 days' '+%Y-%m-%d')"
else
  from_dt="$4"
fi

if [ -z $5 ] ; then
  to_dt="$(date -d '1 days' +'%Y-%m-%d')"
else
  to_dt="$5"
fi

s3bucketFolder="aflt_process_email_attachments/output/"
s3ArchivePath="aflt_process_email_attachments/archive/"
aflt_tran_id=43
hivefile_format="orc"
vertical="cc"
s3_dir=$(echo $S3_Events_Input | cut -f 1 -d '/')	

echo 's3_dir			       :-   '${s3_dir}
echo 's3bucketFolder                   :-   '${s3bucketFolder}
echo 's3ArchivePath                    :-   '${s3ArchivePath}
echo 'from_dt			       :-   '${from_dt}
echo 'to_dt			       :-   '${to_dt}
echo 'aflt_tran_id 		       :-   '${aflt_tran_id}
echo 'hivefile_format		       :-   '${hivefile_format}
echo 'vertical			       :-   '${vertical}
echo 'Events_dwh_bucket                :-   '${Events_dwh_bucket}
echo 'hive_write_mode		       :-   '${hive_write_mode}
echo 'redshift_override		       :-   '${redshift_override}
echo 'sql_engine		       :-   '${sql_engine}

echo '+----------+----------+----------+----------+----------+----------+'
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning data directories:" "Started"
find $Linux_Input -type f -delete || true
find $Linux_Output -type f -delete || true
echo_processing_step ${job_name} "Cleaning data directories:" "Completed"

echo_processing_step ${job_name} "Setting up variables for downloading the files locally" "Started"
echo "S3bucket:"$s3_bucketname" S3folder:"$s3bucketFolder" s3ArchivePath:"$s3ArchivePath" Linux_Input:"$Linux_Input
echo_processing_step ${job_name} "Setting up variables for downloading the files locally" "Completed"

echo_processing_step ${job_name} "Getting all the CC lenders with data source - email_reports" "Started"
query="select distinct lender_dwnld_wildcard from dw_report.ctl_dw_aflt_tran_growth_f where lower(vertical) like 'cc' and lower(data_source) like 'email_reports';"
query_result=`psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query"`
file_lenders_string=$(echo $query_result | cut -f3- -d' ' | rev | cut -f3- -d ' ' | rev)
file_lenders_arr=($file_lenders_string)
echo ${file_lenders_arr[@]}
echo_processing_step ${job_name} "Getting all the CC lenders with data source - email_reports" "Completed"

echo_processing_step ${job_name} "Running python script to download the files" "Started"
for var in "${file_lenders_arr[@]}"
do
	python -c "from s3_modules import s3_file_download_wildcard_search; s3_file_download_wildcard_search('$s3_bucketname','$s3bucketFolder','$var','$Linux_Input','$s3ArchivePath')" || true
done
echo_processing_step ${job_name} "Running python script to download the files" "Completed"

echo_processing_step ${job_name} "Getting all the CC lenders with data source - API" "Started"
query="select distinct lender_dwnld_wildcard from dw_report.ctl_dw_aflt_tran_growth_f where lower(vertical) like 'cc' and lower(data_source) like 'api';"
query_result=`psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query"`
api_lenders_string=$(echo $query_result | cut -f3- -d' ' | rev | cut -f3- -d ' ' | rev)
api_lenders_arr=($api_lenders_string);
echo ${api_lenders_arr[@]}
echo_processing_step ${job_name} "Getting all the CC lenders with data source - API" "Completed"

echo_processing_step ${job_name} "Running python script to call the lender APIs" "Started"
for lender in "${api_lenders_arr[@]}"
do
	echo $lender $from_dt $to_dt
	if [ "$lender" == "impact_radius" ]
	then
		api_sid=$impact_radius_sid
		api_key=$impact_radius_nw_token
	elif [ "$lender" == "amex_ir" ]
	then
		api_sid=$impact_radius_amex_sid
		api_key=$impact_radius_amex_nw_token
	elif [ "$lender" == "linkshare_coupons" ]
	then
		api_key=$linkshare_api_key
	elif [ "$lender" == "linkshare_prequal" ]
	then
		api_key=$linkshare_prequal_key
	fi
	python ${dwh_scripts_base_dir}/aflt_tran_process_cc/pythonscripts/process_api.py $Linux_Input $lender $from_dt $to_dt $api_key $api_sid|| true
done
echo_processing_step ${job_name} "Running python script to call the lender APIs" "Completed"

echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Started"
python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/process_raw_to_confirmed_files.py $Linux_Input $Events_dwh_bucket $s3_dir ${dwh_scripts_base_dir}/aflt_tran_nerdlake/pythonscripts/email_info.json $vertical $aflt_tran_id true $hivefile_format $hive_write_mode $redshift_override $sql_engine
echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

