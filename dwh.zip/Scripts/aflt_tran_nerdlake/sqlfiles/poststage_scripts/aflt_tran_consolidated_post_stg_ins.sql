INSERT INTO hive.${hivevar:stagedb}.aflt_tran_post_s_non_spark
(
    aflt_network_tran_id,
    aflt_network_id,
    aflt_fin_tran_type_cd,
    aflt_catg_nm,  
    tran_acc_create_dt,
    tran_app_st_dt,
    tran_preapproval_dt,
    tran_click_dt,
    tran_click_ts,
    tran_post_dt,
    tran_post_ts,
    src_prod_nm,
    prog_nm,
    log_id,
    commission_am,
    merchant_am,
    src_order_discnt_am,
    src_unique_click_id,
    src_transaction_id,
    src_application_id,
    src_decline_reason_tx,
    src_brwr_yrly_incm,
    src_status_tx,
    src_state_tx,
    txn_cnt,
    src_filename,
    src_file_received_dt,
    dw_last_updt_ts,
    dw_last_updt_tx,
    src_fico_tx,
    src_apr_tx,
    src_term_tx,
    src_data,
    src_sys_id,
    mrtg_src_downpayment,
    mrtg_src_homevalue,
    mrtg_src_category_tx,
    mrtg_src_type_tx,
    edu_src_dgr_type_tx,
    edu_src_dgr_field_tx,
    revenue_tran_in,
    src_column_1,
    src_column_2,
    src_column_3,
    src_column_4,
    src_column_5,
    src_column_6,
    src_column_7,
    src_column_8,
    src_column_9,
    src_column_10,
    src_column_11,
    src_column_12,
    src_column_13,
    src_column_14,
    src_column_15,
    src_column_16,
    src_column_17,
    src_column_18,
    src_column_19,
    src_column_20,
    dw_load_ts,
    dw_eff_dt
)

WITH stg AS (SELECT *
      	     FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY prog_nm, src_unique_click_id, src_transaction_id, src_status_tx) AS row_num
	    	   FROM (SELECT DISTINCT *
		  	 FROM hive.dwnl_rcd_aflt_tran_stage.aflt_tran_s_non_spark
	   	    	 WHERE ((src_transaction_id IS NOT NULL AND src_transaction_id <> '') OR (src_unique_click_id IS NOT NULL AND src_unique_click_id <> ''))
        	   	     AND dw_eff_dt IS NOT NULL
	    	    	     AND CAST(dw_eff_dt AS DATE) >= CAST(CURRENT_TIMESTAMP AS DATE) - interval '30' day
		   	)
	    	  )
      	     WHERE row_num=1
	   ),
dedup_stg AS
  (SELECT DISTINCT aflt_network_tran_id, txn_cnt, prog_nm, src_unique_click_id, src_transaction_id
  FROM hive.dwnl_rcd_aflt_tran_stage.aflt_tran_s_non_spark
  WHERE ((src_transaction_id IS NOT NULL AND src_transaction_id <> '') OR (src_unique_click_id IS NOT NULL AND src_unique_click_id <> ''))
          AND dw_eff_dt IS NOT NULL
  ),
click_status_dedup AS 
	(SELECT *
	 FROM (SELECT aflt_network_tran_id, txn_cnt, ROW_NUMBER() OVER (PARTITION BY prog_nm, src_transaction_id, txn_cnt ORDER BY LENGTH(src_unique_click_id) desc) AS row_num
	       FROM dedup_stg
	      )
	WHERE row_num <> 1 AND txn_cnt <> 0
	)

SELECT DISTINCT
    stg.aflt_network_tran_id,
    stg.aflt_network_id,
    stg.aflt_fin_tran_type_cd,
    stg.aflt_catg_nm,
    CAST(stg.tran_acc_create_dt AS DATE),
    CAST(stg.tran_app_st_dt AS DATE),
    CAST(stg.tran_preapproval_dt AS DATE),
    CAST(stg.tran_click_dt AS DATE) AS tran_click_dt,
    CAST(stg.tran_click_ts AS TIMESTAMP) AS tran_click_ts,
    CAST(stg.tran_post_dt AS DATE),
    CAST(stg.tran_post_ts AS TIMESTAMP),
    stg.src_prod_nm,
    stg.prog_nm,
    stg.log_id,
    CASE WHEN click_status_dedup.aflt_network_tran_id IS NULL THEN commission_am ELSE 0 END AS commission_am,
    stg.merchant_am,
    stg.src_order_discnt_am,
    stg.src_unique_click_id,
    stg.src_transaction_id,
    stg.src_application_id,
    stg.src_decline_reason_tx,
    stg.src_brwr_yrly_incm,
    stg.src_status_tx,
    stg.src_state_tx,
    CASE WHEN click_status_dedup.aflt_network_tran_id IS NULL THEN stg.txn_cnt ELSE 0 END AS txn_cnt,
    stg.src_filename,
    CAST(stg.src_file_received_dt AS DATE),
    CAST(CURRENT_TIMESTAMP AS TIMESTAMP) AS dw_last_updt_ts,
    'Normal ETL Load' AS dw_last_updt_tx,
    stg.src_fico_tx,
    stg.src_apr_tx,
    stg.src_term_tx,
    stg.src_data,
    stg.src_sys_id,
    stg.mrtg_src_downpayment,
    stg.mrtg_src_homevalue,
    stg.mrtg_src_category_tx,
    stg.mrtg_src_type_tx,
    stg.edu_src_dgr_type_tx,
    stg.edu_src_dgr_field_tx,
    CASE WHEN stg.commission_am <> 0 AND click_status_dedup.aflt_network_tran_id IS NULL THEN True ELSE False END AS revenue_tran_in,
    stg.src_column_1,
    stg.src_column_2,
    stg.src_column_3,
    stg.src_column_4,
    stg.src_column_5,
    stg.src_column_6,
    stg.src_column_7,
    stg.src_column_8,
    stg.src_column_9,
    stg.src_column_10,
    stg.src_column_11,
    stg.src_column_12,
    stg.src_column_13,
    stg.src_column_14,
    stg.src_column_15,
    stg.src_column_16,
    stg.src_column_17,
    stg.src_column_18,
    stg.src_column_19,
    stg.src_column_20,
    CAST(CURRENT_TIMESTAMP AS TIMESTAMP) AS dw_load_ts,
    CAST(stg.dw_eff_dt AS DATE) AS dw_eff_dt
FROM stg
LEFT JOIN click_status_dedup 
ON stg.aflt_network_tran_id = click_status_dedup.aflt_network_tran_id;
