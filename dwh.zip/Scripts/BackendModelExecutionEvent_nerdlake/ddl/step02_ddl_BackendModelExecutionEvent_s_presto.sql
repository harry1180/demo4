CREATE OR REPLACE VIEW hive.dwnl_stage.BackendModelExecutionEvent_s AS
SELECT  payload.model_execution_event_id AS model_execution_event_id
       ,payload.header.guid AS guid
       ,FROM_UNIXTIME(payload.header."timestamp" / 1000.0, 'UTC') AS event_ts
       ,payload.parent_event_id AS parent_event_id
       ,payload.parent_event_type AS parent_event_type
       ,payload.meta AS meta
       ,payload.inputs AS inputs
       ,payload.outputs AS outputs
       ,payload.header.eventname AS event_name
       ,envelope.exchangeId AS event_name_header
       ,payload.header.environment AS environment
       ,payload.header.serviceCallHeader.callerClientId as caller_client_id
       ,payload.header.serviceCallHeader.referringCallerClientId as referring_caller_client_id
  FROM hive.dwnl_stage.BackendModelExecutionEvent_raw_s;

CREATE OR REPLACE VIEW hive.dwnl_stage_stageenv.BackendModelExecutionEvent_s AS
SELECT  payload.model_execution_event_id AS model_execution_event_id
       ,payload.header.guid AS guid
       ,FROM_UNIXTIME(payload.header."timestamp" / 1000.0, 'UTC') AS event_ts
       ,payload.parent_event_id AS parent_event_id
       ,payload.parent_event_type AS parent_event_type
       ,payload.meta AS meta
       ,payload.inputs AS inputs
       ,payload.outputs AS outputs
       ,payload.header.eventname AS event_name
       ,envelope.exchangeId AS event_name_header
       ,payload.header.environment AS environment
       ,payload.header.serviceCallHeader.callerClientId as caller_client_id
       ,payload.header.serviceCallHeader.referringCallerClientId as referring_caller_client_id
  FROM hive.dwnl_stage_stageenv.BackendModelExecutionEvent_raw_s;
