import os
import sys

from datetime import datetime, timedelta

from s3_modules import check_if_key_exist, list_s3_keys_enhanced, s3_key_copy

S3_SRC_BUCKET = 'nw-event-data-stage'
S3_DEST_BUCKET = 'east1-prod-nerdlake-0'
S3_SRC_FOLDER = 'BackendModelExecutionEvent'
S3_DEST_FOLDER = 'dwnl_stage_stageenv/BackendModelExecutionEvent_s'
PARTITION_NAME = 'dw_eff_dt'


def main():
    """
    Copy BackendModelExecutionEvent files from nw-event-data-prod to east1-prod-nerdlake-0. The s3 path needs to be renamed to
    fit the hive partition format ("2018/01/01/*" --> "dw_eff_dt=2018-01-01/*").
    """

    date_from = sys.argv[1]
    date_to = sys.argv[2]

    datetime_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
    datetime_to_obj = datetime.strptime(date_to, '%Y-%m-%d')

    current_date = datetime_from_obj
    while current_date <= datetime_to_obj:

        # in shadowrealm src files are stored under date subdirectories (i.e. /2018/01/01/*)
        src_s3_sub_folder = os.path.join(S3_SRC_FOLDER, datetime.strftime(current_date, '%Y/%m/%d'))
        partition_date = '-'.join(src_s3_sub_folder.split('/')[-3:])

        # iterate through all source files in date folder and move to nerdlake
        for src_key in list_s3_keys_enhanced(src_s3_sub_folder, s3_bucket=S3_SRC_BUCKET):
            partition_path = '{}={}'.format(PARTITION_NAME, partition_date)
            dest_key = os.path.join(S3_DEST_FOLDER, partition_path, os.path.split(src_key)[-1])
            print dest_key
            if not check_if_key_exist(S3_DEST_BUCKET, dest_key):
                s3_key_copy(src_key, dest_key, S3_SRC_BUCKET, S3_DEST_BUCKET)

        current_date += timedelta(days=1)


if __name__ == '__main__':

    main()
