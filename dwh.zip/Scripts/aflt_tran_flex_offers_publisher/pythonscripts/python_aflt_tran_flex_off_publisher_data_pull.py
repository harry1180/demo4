import sys
import requests
import xmltodict
import json
import os.path

def get_json_list(d, lst):
        for k,v in d.items():
                if k == 'item': lst.append(v)
                elif isinstance(v, dict): return get_json_list(v, lst)
        return lst

requests.packages.urllib3.disable_warnings()

start_date = sys.argv[1]
end_date = sys.argv[2]
file_dir = sys.argv[3]
file_name = os.path.join(file_dir, start_date + ".json")

print "*****************************"
print start_date
print end_date
print file_name

url = "https://publisher.flexoffers.com/public/report.aspx?gui=aa4240af-5b1b-4fe0-b836-13d464ed0270&d1="+start_date+"&d2="+end_date+"&t=S&o=3&p=1"
r = requests.get(url,allow_redirects=True,timeout=1000, stream=True, verify=False)
xml_dict = xmltodict.parse(r.text)
json_lst = get_json_list(xml_dict, []) 
with open(file_name, 'w') as f:
	for row in json_lst:
		json.dump(row, f)
		f.write('\n')	
