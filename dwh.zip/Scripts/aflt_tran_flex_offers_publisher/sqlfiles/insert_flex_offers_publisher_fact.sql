INSERT INTO dw_report.dw_aflt_tran_flex_offers_publisher_f
SELECT
aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
case when lower(prog_nm) like '%e*trade%' then 'Etrade'
     when lower(prog_nm) like 'optionsxpress' then 'OptionsXpress'
     when lower(prog_nm) like 'trademonster' then 'TradeMonster'
     else prog_nm end as prog_nm,
src_unique_click_id,
catg_nm,
commision_am,
merchant_am,
click_domain_nm,
other_catg,
campaign_tx,
user_agent_tx,
ip_addr,
aflt_referer_url,
order_num,
program_id,
dw_load_ts
FROM (
SELECT  a.*,
                b.aflt_network_tran_id  as record_check
FROM dw_stage.dw_aflt_tran_flex_offers_publisher_post_stg a
LEFT OUTER JOIN
dw_report.dw_aflt_tran_flex_offers_publisher_f b
ON a.aflt_network_tran_id = b.aflt_network_tran_id
AND a.aflt_network_id = b.aflt_network_id)
WHERE
record_check is null;
