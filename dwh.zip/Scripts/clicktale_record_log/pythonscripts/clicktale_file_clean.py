import os
import csv
import codecs
import re
from urlparse import urlparse

# in file layout
# "RecordingDate","URL",  "UID",  "MouseMoves","MouseClick","EngagementTimeInSec","LoadTimeInMillisec","ScrollReach","Referrer","CountryName","Bounce","Events"
# row[0]          row[1] row[2]    row[3]        [4]          [5]                   [6]                  [7]           [8]         [9]             [10]  [11]

# out file layout
# Delimiter: Tab
# all columns from the source file 
# "RecordingDate","URL",  "UID",  "MouseMoves","MouseClick","EngagementTimeInSec","LoadTimeInMillisec","ScrollReach","Referrer","CountryName","Bounce","Events"
# <row layout continued> additional columns parsed out  --> 
#  nw_url_netloc, nw_url_path, nw_url_param, nw_url_query, ref_url_netloc, ref_url_path, ref_url_param, ref_url_query, jserr_flag, homepage_flag, nw_uv_id

def parse_url(url_in):
    parseout=urlparse(url_in)
    parse=[parseout.netloc, parseout.path, parseout.params, parseout.query]
    return parse

def parse_nw_events(event_in):
    if 'jserr' in event_in: 
        jserr = 1 
    else:
        jserr =0

    if 'Non Homepage' in event_in: 
        if 'Homepage' in event_in: homepage = 1 
    else: 
        homepage =0
    nw_uvs=re.findall('Contact ID ([\S]+);', event_in)
    if len(nw_uvs) == 0:
        nw_uv=''
    else: nw_uv = nw_uvs[0]
    return [jserr,homepage,nw_uv] 
      
print 'Starting Python steps'
indir='/data/etl/Data/clicktale_record_log/input/'
outdir='/data/etl/Data/clicktale_record_log/output/'
for files in os.listdir(indir):
    if 'csv' in files:     
        print "Processing input file:"+files
        with open(indir+files,'r') as rhandle:
            inreader=csv.reader(rhandle, delimiter=',', quotechar='"')
            outfilename=outdir+files.split('.')[0]+'output.csv' 
            with open(outfilename,'wb+') as whandle:
                print "Writing to file:"+outfilename
                csvwriter=csv.writer(whandle,delimiter='\t')
                for inrow in inreader:
                    nw_parse=parse_url(inrow[1])
                    ref_parse=parse_url(inrow[8])
                    outrow = [column for column in inrow] + [column  for column in nw_parse] + [column for column in ref_parse] + [column for column in parse_nw_events(inrow[11])] 
                    csvwriter.writerow(outrow)


