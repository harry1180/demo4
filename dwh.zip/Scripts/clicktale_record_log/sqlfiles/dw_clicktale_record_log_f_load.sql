/* Script to load data into the dw_clicktale_record_log_f table

nPK = clicktale_recording_dt, clicktale_User_ID. This is a soft nPK as there is a possbility of mutiple recorgins at exact same time.

Load type: Append Insert

*/


insert into dw_report.dw_clicktale_record_log_f 
 (clicktale_recording_ts, clicktale_user_id, dw_site_visitor_id ,
nw_site_uv_id, dw_page_sk, src_url_tx, dw_referral_sk, ref_url_tx,
mouse_move_ct, mouse_click_ct, engagement_time_in_sec_tm, load_time_in_ms_tm,
scroll_reach_pc, user_country_nm, bounce_type_tx, had_jserr_in, homepage_in,
nw_event_tx, nw_url_netloc_tx, nw_url_path_tx, nw_url_param_tx, nw_url_query_tx,
ref_url_netloc_tx, ref_url_path_tx, ref_url_param_tx, ref_url_query_tx, dw_load_ts)
select 
 convert_timezone('CST','UTC', cast (s.recording_dt as timestamp)) as clicktale_recording_ts,
 s.clicktale_UID	as clicktale_User_ID,
 sv.dw_site_visitor_id, 
 s.nw_uv_id,	
 PD.dw_page_sk,	
 S.url_tx	AS src_url_tx,
 RD.dw_referral_sk, 
 S.ref_url_tx,
 S.mouse_move_ct,
 s.mouse_click_ct,
 s.engagement_time_in_sec_tm,
 s.load_time_in_ms_tm,
 s.scroll_reach_pc,
 s.user_country_nm,
 s.bounce_type_tx,
 s.jserr_flag, 
 s.homepage_flag, 
 s.nw_event_tx	,
 s.nw_url_netloc,
 s.nw_url_path ,
 s.nw_url_param	, 
 s.nw_url_query	, 
 s.ref_url_netloc, 
 s.ref_url_path, 
 s.ref_url_param, 
 s.ref_url_query, 
 getdate()
from dw_stage.dw_clicktale_record_log_s s
 left join dw_report.dw_clicktale_record_log_f trgt
 on convert_timezone('CST','UTC', cast (s.recording_dt as timestamp)) = trgt.clicktale_recording_ts
 	and s.clicktale_UID	= trgt.clicktale_User_ID
 left join dw_report.site_visitor_d sv
 on trim(s.nw_uv_id) = sv.site_uv_id
 left join dw_report.dw_page_d pd
 on s.nw_url_netloc = pd.page_site_nm
 and s.nw_url_path = pd.page_path_tx
 left join dw_report.dw_referral_d rd
 on s.ref_url_netloc = rd.referral_site_nm  
 and s.ref_url_path = rd.referral_path_tx
where 
  trgt.clicktale_User_ID is NULL
  ;



