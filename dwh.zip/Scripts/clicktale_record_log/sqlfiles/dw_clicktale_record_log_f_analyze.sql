
analyze  dw_report.dw_clicktale_record_log_f ;

vacuum dw_report.dw_clicktale_record_log_f ;


