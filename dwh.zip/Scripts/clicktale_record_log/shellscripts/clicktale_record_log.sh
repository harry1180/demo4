source /data/etl/Scripts/clicktale_record_log/shellscripts/parm_clicktale_record_log.ctrl

#######################################
#Main Script
######################################
input_date="$(date +'%Y%m%d%H%M%S')"
#Delete Files if files exist in Directory. The below deletes are for safety if the script fails in between then we dont need any manual deletions
rm -f $Linux_Input*Clicktale*
rm -f $Linux_Output*Clicktale*
rm -f $S3_Output*.gz

#for all files in the clicktale S3 bucket: copy them to linux input folder for python processing and move them to archive for backup
for f in $S3_Input*zip
do
cp $f $Linux_Input
#chmod 775 $Linux_Input*
#chgrp etl $Linux_Input*
cp $f $S3_Archive
mv $f $S3_Input/archive/
done

# Unzip the input file from clicktale 
#for f in $Linux_Input*.zip
#do
#unzip -uo $f
#done

#unzip all the files in linux input folder for python processing
chmod 775 $Linux_Input*
chgrp etl $Linux_Input*
unzip  -o $Linux_Input'*.zip' -d $Linux_Input

# pythong process the files in linux input. Output files are in linux output
#decrypting the url
python /data/etl/Scripts/clicktale_record_log/pythonscripts/clicktale_file_clean.py

#gz all the files in linux output and move them to s3 for loading
for f in $Linux_Output*output.csv
do
#gzip the output file
gzip $f
#move the gzip file to the s3 input
mv $f*.gz $S3_Output
done

#changing the permissions of the gz file
chmod 775 $S3_Output/*.gz
chgrp etl $S3_Output/*.gz

#delete the data from the staging table before reloading it
query_stage_delete="delete from dw_stage.dw_clicktale_record_log_s;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"

#copy command to move the processed file to the redshift staging table
# header is ignored
bash /data/etl/Common/redshift_copy_function.sh dw_stage.dw_clicktale_record_log_s /clicktale_record_log/output/ Clicktale 1 


# load data from stage to target table 
bash /data/etl/Common/redshift_sql_function.sh /data/etl/Scripts/clicktale_record_log/sqlfiles/dw_clicktale_record_log_f_load.sql
bash /data/etl/Common/redshift_sql_function.sh /data/etl/Scripts/clicktale_record_log/sqlfiles/dw_clicktale_record_log_f_analyze.sql

for f in $S3_Output*.gz
do
mv $f $S3_Archive'clicktale_python_output_'$input_date'.gz'
done

