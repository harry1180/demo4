UPDATE dw_report.dw_aflt_tran_flex_offers_client_f
   SET commission_am = b.commision_am, merchant_am = b.merchant_am
  FROM dw_stage.dw_aflt_tran_flex_offers_client_post_stg b
 WHERE     dw_report.dw_aflt_tran_flex_offers_client_f.aflt_network_tran_id =
              b.aflt_network_tran_id
       AND dw_report.dw_aflt_tran_flex_offers_client_f.aflt_network_id =
              b.aflt_network_id
		and dw_report.dw_aflt_tran_flex_offers_client_f.commission_am <> 
		      b.commision_am
		and dw_report.dw_aflt_tran_flex_offers_client_f.merchant_am <> 
		      b.merchant_am;
