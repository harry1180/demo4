DROP TABLE IF EXISTS dw_stage.deactivation_event_s;

CREATE TABLE dw_stage.deactivation_event_s
(
  userId                      VARCHAR(256)   ENCODE LZO ,
  userType                    VARCHAR(50)   ENCODE LZO ,
  guid                        VARCHAR(6000)   ENCODE LZO ,
  "timestamp"                 TIMESTAMP   ENCODE LZO ,
  environment                 VARCHAR(10)   ENCODE LZO ,
  cookieId                    VARCHAR(6000)   ENCODE LZO ,
  url                         VARCHAR(6000)   ENCODE LZO ,
  ip                          VARCHAR(6000)   ENCODE LZO ,
  userAgent                   VARCHAR(6000)   ENCODE LZO ,
  pageviewId                  VARCHAR(6000)   ENCODE LZO ,
  eventName                   VARCHAR(100)   ENCODE LZO ,
  errorMessages               VARCHAR(6000)   ENCODE LZO ,
  referrer                    VARCHAR(6000)   ENCODE LZO ,
  userRoles                   VARCHAR(100)   ENCODE LZO ,
  browserSessionId            VARCHAR(6000)   ENCODE LZO ,
  requestId                   VARCHAR(3000)   ENCODE LZO ,
  applicationId               VARCHAR(3000)   ENCODE LZO ,
  geoResolved                 BOOLEAN    ENCODE RUNLENGTH ,
  latitude                    VARCHAR(100)   ENCODE LZO ,
  longitude                   VARCHAR(100)   ENCODE LZO ,
  city                        VARCHAR(100)   ENCODE LZO ,
  postalCode                  VARCHAR(100)   ENCODE LZO ,
  country                     VARCHAR(100)   ENCODE LZO ,
  region                      VARCHAR(100)   ENCODE LZO ,
  metroCode                   BIGINT   ENCODE LZO ,
  timezone                    VARCHAR(100)   ENCODE LZO ,
  geoId                       BIGINT   ENCODE LZO ,
  browserType                 VARCHAR(100)   ENCODE LZO ,
  browserTypeReason           VARCHAR(1000)   ENCODE LZO ,
  nwSessionId                  VARCHAR(1000)   ENCODE LZO ,
  callerClientId               varchar(2000)   ENCODE LZO ,
  referringCallerClientId   varchar(2000)   ENCODE LZO ,
  globalTaxonomyVertical     VARCHAR(500)   ENCODE LZO ,
  globalTaxonomyTopic            VARCHAR(500)   ENCODE LZO ,
  globalTaxonomyPageType           VARCHAR(500)   ENCODE LZO ,
  globalTaxonomyNldt            VARCHAR(500)   ENCODE LZO ,
  globalTaxonomyContentType            VARCHAR(500)   ENCODE LZO ,
  appVersion                      VARCHAR(100)   ENCODE LZO ,
  appBinaryVersion              VARCHAR(100)   ENCODE LZO ,
  platform                      VARCHAR(500)   ENCODE LZO ,
  osName                        VARCHAR(500)   ENCODE LZO ,
  osVersion                     VARCHAR(100)   ENCODE LZO ,
  deviceId                      VARCHAR(500)   ENCODE LZO ,
  deviceManufacturer            VARCHAR(500)   ENCODE LZO ,
  deviceBrand                   VARCHAR(500)   ENCODE LZO ,
  deviceModel                   VARCHAR(500)   ENCODE LZO ,
  deactivatedFeature              VARCHAR(100)   ENCODE LZO ,
  DeactivateReason               VARCHAR(100)   ENCODE LZO ,
  targetUserId                  VARCHAR(256)   ENCODE LZO 
)
distkey (userId);

GRANT ALL  ON dw_stage.deactivation_event_s TO GROUP grp_etl;

GRANT SELECT  ON dw_stage.deactivation_event_s TO GROUP grp_data_users;


