import sys
import datetime
import json
import time

#datdog res
from datadog import initialize, api
import ConfigParser

from redshift_modules import *

metrics_list = [
    {'metric_nm':'nw.dwh.page_view_count','sql':'select count(1) from dw_report.dw_page_view_event_f'},
    {'metric_nm':'nw.dwh.pv_ua_join_31d',
                'sql':'select count(1) from dw_report.dw_page_view_event_f pv join dw_report.user_agent_d ua on pv.dw_user_agent_id = ua.dw_user_agent_id where ua.curr_in = 1 and ua.is_mobile_in = \'True\' and pv.dw_eff_dt > trunc(getdate()-31)'},
    {'metric_nm':'nw.dwh.page_view_enriched_count','sql':'select count(1) from dw_views.dw_page_view_enriched'}
    ]

class DataDog:
    def __init__(self, auto_config=True):
        # from datadog import initialize, api
        self.api = api
        self.initialize = initialize
        self.options = {}
        if auto_config:
            self.get_api_key()

    def get_api_key(self, path = '/etc/dd-agent/datadog.conf'):
        config = ConfigParser.RawConfigParser()
        config.read(path)
        options = {
            'api_key': config.get('Main', 'api_key')
        }
        self.options = options
        self.initialize(**self.options)

def main():
    dog = DataDog()
    for metric in metrics_list:
        print 'Executing SQL for metric %s. \n SQL is %s' %(metric['metric_nm'],metric['sql'])
        sql= metric['sql']
        start_time = time.time()
        exec_query(sql)
        end_time = time.time()
        seconds =  (end_time - start_time)
        dog.api.Metric.send(metric=metric['metric_nm'], points=seconds)

if __name__ == '__main__':
    sys.exit(main())
