
create table dw_stage.ctl_counts_json_s 
(
  platform     varchar(300)
, event_name   varchar(300)
, key          varchar(1000)
, record_count integer
)
distkey(key)
;
