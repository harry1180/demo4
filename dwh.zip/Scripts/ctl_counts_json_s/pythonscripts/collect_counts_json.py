
import sys, os
from redshift_modules import generate_specific_manifest_file

####################################       main          ####################################

def main():
    #task_name='ctl_counts_json_s'
    #src_s3_bucket='nw-event-data-prod'
    #dest_s3_bucket='east1-prod-dwh-s3-0'
    #search_file='counts.json'
    #start_date_time = '2016-04-01'
    #end_date_time = '2016-12-31'
    
    task_name           = sys.argv[1] 
    src_s3_bucket       = sys.argv[2] 
    dest_s3_bucket      = sys.argv[3] 
    search_file         = sys.argv[4]
    start_date_time     = sys.argv[5] 
    end_date_time       = sys.argv[6] 
    
    #print task_name + ' ' + src_s3_bucket + ' ' + dest_s3_bucket + ' ' + search_file + ' ' + start_date_time + ' ' + end_date_time
    
    generate_specific_manifest_file('Prod', src_s3_bucket, search_file, dest_s3_bucket, task_name+'/manifest', start_date_time, end_date_time, 'created')

if __name__ == '__main__':
    main()
