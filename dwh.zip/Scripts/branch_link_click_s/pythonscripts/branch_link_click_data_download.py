import sys
from branch_api_download  import get_branch_data

key=sys.argv[1]
skey=sys.argv[2]
report_to_download_date=sys.argv[3]
file_path=sys.argv[4]
dim=sys.argv[5]
job_name=sys.argv[6]
source_bucket=sys.argv[7]
json_file=sys.argv[8]
extra_json_file=sys.argv[9]


url='https://api.branch.io/v2/export/'

#column header in the downloaded csv file.
field_name_list='click_timestamp,branch_link_click_id,branch_browser_fingerprint_id,os,os_version,model,browser,user_agent,ip_address,stage,sms_from_desktop,phone_number,redirect_method,link_creation_timestamp,link_channel,link_feature,link_campaign,link_stage,link_tags,link_data,link_creation_source,link_url,link_branch_identity_id,link_id,query_params,branch_device_fingerprint_id,hardware_id,google_advertising_id,device_metadata'


# defining various dictionary for different json objects.
json_dict={  
          'query_params':{'__branch_amp_json':'query_param_branch_amp_json','__amp_source_origin':'query_param_amp_source_origin','gclid':'query_param_gclid','referrer':'query_param_referrer','_t':'query_param_t','_branch_match_id':'query_param_branch_match_id'}
        , 'link_data':{'$android_deeplink_path':'link_data_android_deeplink_path','$ios_deeplink_path':'link_data_ios_deeplink_path','$deeplink_path':'link_data_deeplink_path','post_id':'link_data_post_id','__branch_amp_json':'link_data_branch_amp_json','__amp_source_origin':'link_data_amp_source_origin','+match_guaranteed':'link_data_match_guaranteed','+clicked_branch_link':'link_data_clicked_branch_link','+is_first_session':'link_data_is_first_session','~referring_link':'link_data_referring_link','_t':'link_data_t','_branch_match_id':'link_data_branch_match_id','$og_description': 'link_data_og_description','$og_image_url': 'link_data_link_og_image_url','$og_title': 'link_data_og_title','$og_video': 'link_data_og_video','$canonical_url': 'link_data_canonical_url','+referrer':'link_data_plus_referrer','~campaign':'link_data_campaign','~channel':'link_data_channel','referrer':'link_data_referrer','+click_timestamp': 'link_data_click_timestamp','+url': 'link_data_click_url','~marketing': 'link_data_marketing','+app_short_identifier': 'link_data_app_short_identifier','~creation_source': 'link_data_creation_source','~feature': 'link_data_feature','~id': 'link_data_id','~tags': 'link_data_tags','+domain': 'link_data_domain','$marketing_title': 'link_data_marketing_title','$one_time_use': 'link_data_one_time_use','test-key' : 'link_data_test_key','google_search' :'link_data_google_search','gclid':'link_data_gclid'}
          }


final_url=url+key+'?branch_secret='+skey+'&export_date='+report_to_download_date

print "Call function to download the data"
if get_branch_data (final_url,file_path,dim, json_dict,field_name_list,job_name,source_bucket,json_file,extra_json_file)== -1 :
   print "Error in processing. Existing"
   sys.exit(1)
else :
   print 'processing completed successfully for %s '   %report_to_download_date 

