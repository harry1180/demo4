
drop   table dw_stage.click_event_generic_s ;

create table dw_stage.click_event_generic_s
(
  affiliateId            varchar(6000) encode lzo
, browserSessionId       varchar(6000) encode lzo
, category               varchar(6000) encode lzo
, cookieId               varchar(6000) encode lzo
, environment            varchar(6000) encode lzo
, errorMessages          varchar(6000) encode lzo
, eventName              varchar(6000) encode lzo
, guid                   varchar(6000) encode lzo
, impressionId           varchar(6000) encode lzo
, ip                     varchar(6000) encode lzo
, linkType               varchar(6000) encode lzo
, monetizing             varchar(6000) encode lzo
, pageNumber             varchar(6000) encode lzo
, pageviewId             varchar(6000) encode lzo
, productId              varchar(6000) encode lzo
, productInstance        varchar(6000) encode lzo
, productLocation        varchar(6000) encode lzo
, productPosition        varchar(6000) encode lzo
, productSlug            varchar(6000) encode lzo
, referrer               varchar(6000) encode lzo
, requestId              varchar(6000) encode lzo
, sectionPosition        varchar(6000) encode lzo
, sponsored              varchar(6000) encode lzo
, "timestamp"            timestamp     encode lzo
, uniqueClickId          varchar(6000) encode lzo
, url                    varchar(6000) encode lzo
, userAgent              varchar(6000) encode lzo
, userId                 varchar(6000) encode lzo
, userRoles              varchar(6000) encode lzo
, userType               varchar(6000) encode lzo
, zdw_user_agent         varchar(6000) encode lzo
, zzz_is_valid           varchar(6000) encode lzo
, zzz_new_url            varchar(6000) encode lzo
, zzz_parse_netloc       varchar(6000) encode lzo
, zzz_parse_path         varchar(6000) encode lzo
, zzz_parse_scheme       varchar(6000) encode lzo
, zzz_validated_netloc   varchar(6000) encode lzo
, zzz_validated_path     varchar(6000) encode lzo
, zzz_validated_query    varchar(6000) encode lzo
, zzz_validated_scheme   varchar(6000) encode lzo
, zzz_validated_url      varchar(6000) encode lzo
) 
distkey(uniqueClickId) 
sortkey(affiliateId) 
;
GRANT REFERENCES, TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_stage.click_event_generic_s TO group grp_etl;
GRANT SELECT ON dw_stage.click_event_generic_s TO group grp_data_users;
