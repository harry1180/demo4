drop   table dw_stage.dw_cookie_user_bot_all ;
create table dw_stage.dw_cookie_user_bot_all 
(
  site_uv_id           varchar(60)   encode lzo
, user_id              varchar(256)  encode lzo
, dw_suspected_bot_in  varchar(10)   encode lzo
, last_activity_ts     timestamp     encode lzo
, dw_snapshot_dt       date          encode lzo
, incremental_in       smallint      encode lzo
)
distkey(site_uv_id)
sortkey(dw_snapshot_dt)
;
GRANT ALL  ON dw_stage.dw_cookie_user_bot_all TO GROUP grp_etl;

