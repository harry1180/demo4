insert into dw_stage.dw_cookie_user_bot_all 
(
  site_uv_id         
, user_id            
, dw_suspected_bot_in
, last_activity_ts
, dw_snapshot_dt
, incremental_in
)
select 
  substring(site_uv_id,1,60)         
, user_id            
, dw_suspected_bot_in
, last_activity_ts
, trunc(sysdate) as dw_snapshot_dt
, 1 as incremental_in
from 
(
select src_site_visitor_tx as site_uv_id, user_id, dw_suspected_bot_in, page_view_utc_ts as last_activity_ts
, row_number() over (partition by src_site_visitor_tx order by page_view_utc_ts desc) as dedup_flag
from dw_report.dw_page_view_event_f 
where dw_suspected_bot_in = 'True' 
  and src_site_visitor_tx not in (select site_uv_id from dw_stage.dw_cookie_user_bot_all group by 1)
)
where dedup_flag=1
;
