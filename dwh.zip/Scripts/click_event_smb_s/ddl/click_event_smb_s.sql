
--drop   table dw_stage.click_event_smb_s ;
--create table dw_stage.click_event_smb_s 
(
   B2BFilter                        boolean             encode raw
 , affiliateId                      varchar(300)        encode lzo
 , bankruptcyFilter                 boolean             encode raw
 , browserSessionId                 varchar(300)        encode lzo
 , businessAgeFilterMax             bigint              encode lzo
 , businessAgeFilterMin             bigint              encode lzo
 , category                         varchar(300)        encode lzo
 , cookieId                         varchar(60)         encode lzo
 , creditScoreFilterMax             bigint              encode lzo
 , creditScoreFilterMin             bigint              encode lzo
 , environment                      varchar(60)         encode lzo
 , errorMessages                    varchar(60000)      encode lzo
 , eventName                        varchar(60)         encode lzo
 , guid                             varchar(300)        encode lzo
 , impressionId                     varchar(300)        encode lzo
 
 , invoicesFilter                   boolean             encode raw
 
 , ip                               varchar(60)         encode lzo
 , linkType                         varchar(300)        encode lzo
 , loanAmountFilter                 bigint              encode lzo
 , loanCollateralFilter             boolean             encode raw
 , loanTermFilterMax                bigint              encode lzo
 , loanTermFilterMin                bigint              encode lzo
 
 , loanUrgencyFilterMax             bigint              encode lzo
 , loanUrgencyFilterMin             bigint              encode lzo
    
 , monetizing                       boolean             encode raw
 , monthlyRevenueFilterMax          bigint              encode lzo
 , monthlyRevenueFilterMin          bigint              encode lzo
 , offerVersionId                   integer             encode lzo
 , pageNumber                       bigint              encode lzo
 , pageviewId                       varchar(120)        encode lzo
 , personalGuaranteeFilter          boolean             encode raw
 , productId                        varchar(120)        encode lzo
 , productInstance                  varchar(300)        encode lzo
 , productLocation                  varchar(300)        encode lzo
 , productPosition                  bigint              encode lzo
 , productSlug                      varchar(300)        encode lzo
 
 , profitabilityFilter              bigint              encode lzo
 , qualificationScore               numeric(30,16)      encode lzo

 , referrer                         varchar(3000)       encode lzo
 , requestId                        varchar(300)        encode lzo
 , sectionPosition                  bigint              encode lzo
 , sortColumn                       varchar(3000)       encode lzo
 , sponsored                        boolean             encode raw
 , stateFilter                      varchar(3000)       encode lzo
 , "timestamp"                      timestamp           encode lzo
 , uniqueClickId                    varchar(300)        encode lzo
 , url                              varchar(60000)      encode lzo
 , userAgent                        varchar(60000)      encode lzo
 , userId                           varchar(300)        encode lzo
 , userRoles                        varchar(300)        encode lzo
 , userType                         varchar(300)        encode lzo
 , zdw_user_agent                   varchar(6000)       encode lzo
 , zzz_is_valid                     varchar(6000)       encode lzo
 , zzz_new_url                      varchar(6000)       encode lzo
 , zzz_parse_netloc                 varchar(6000)       encode lzo
 , zzz_parse_path                   varchar(6000)       encode lzo
 , zzz_parse_scheme                 varchar(6000)       encode lzo
 , zzz_validated_netloc             varchar(6000)       encode lzo
 , zzz_validated_path               varchar(6000)       encode lzo
 , zzz_validated_query              varchar(6000)       encode lzo
 , zzz_validated_scheme             varchar(6000)       encode lzo
 , zzz_validated_url                varchar(6000)       encode lzo 
)
distkey(uniqueClickId) 
sortkey(affiliateId) 
;

GRANT all    ON dw_stage.click_event_smb_s TO group grp_etl;
GRANT SELECT ON dw_stage.click_event_smb_s TO group grp_data_users;
