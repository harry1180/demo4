('SELECT dw_eff_dt
	, src_site_visitor_tx
	, dw_session_id
	, wp_post_id
FROM dw_report.ContentRecommendation_f
WHERE dw_eff_dt >= trunc( sysdate - 1)
')
