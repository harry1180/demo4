INSERT INTO dw_stage.ContentRecommendation_s
(
SELECT dw_eff_dt
	, src_site_visitor_tx
	, dw_session_id
	, wp_post_id
FROM dw_report.dw_page_view_event_f
WHERE dw_eff_dt >= trunc( sysdate - 7)
	AND src_site_visitor_tx IS NOT NULL
	AND dw_session_id IS NOT NULL
  	AND wp_post_id IS NOT NULL
GROUP BY 1, 2, 3, 4
);
