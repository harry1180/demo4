INSERT INTO dw_report.ContentRecommendation_f
(
dw_eff_dt
, src_site_visitor_tx
, dw_session_id
, wp_post_id
, dw_load_ts
)
SELECT  stg.dw_eff_dt              		AS dw_eff_dt
	, stg.src_site_visitor_tx			AS src_site_visitor_tx
	, stg.dw_session_id					AS dw_session_id
	, stg.wp_post_id					AS wp_post_id
	, sysdate							AS dw_load_ts
FROM dw_stage.ContentRecommendation_s stg
LEFT OUTER JOIN dw_report.ContentRecommendation_f tgt
	ON stg.dw_eff_dt = tgt.dw_eff_dt
		AND stg.src_site_visitor_tx = tgt.src_site_visitor_tx
		AND stg.dw_session_id = tgt.dw_session_id
		AND stg.wp_post_id = tgt.wp_post_id
WHERE tgt.dw_eff_dt IS NULL
	AND tgt.src_site_visitor_tx IS NULL
	AND tgt.dw_session_id IS NULL
	AND tgt.wp_post_id IS NULL
;
