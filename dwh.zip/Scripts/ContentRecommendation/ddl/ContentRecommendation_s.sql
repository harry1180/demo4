CREATE TABLE dw_stage.ContentRecommendation_s
(
	dw_eff_dt					DATE ENCODE LZO,
	src_site_visitor_tx			VARCHAR(6000) ENCODE LZO,
	dw_session_id				VARCHAR(120) ENCODE LZO,
	wp_post_id					BIGINT ENCODE LZO
)
DISTKEY(src_site_visitor_tx)
SORTKEY(dw_eff_dt)
;
