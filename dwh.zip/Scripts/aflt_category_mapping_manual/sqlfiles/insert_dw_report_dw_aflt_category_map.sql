INSERT INTO dw_report.dw_aflt_category_map
(
src_aflt_prod_nm,
src_aflt_prog_nm,
src_aflt_catg_nm,
src_sys_id,
validated_catg_nm,
validated_in,
valiadated_by_nm,
dw_load_ts,
page_hier_lvl1_nm,
page_hier_lvl2_nm
)
SELECT p.src_prod_nm,
       p.prog_nm,
       p.aflt_catg_nm,
       src_sys_id,
       p.aflt_catg_nm,
       'NO',
       NULL,
       sysdate,
       NULL,
       NULL
FROM (SELECT *
      FROM (SELECT a.src_prod_nm,
                   a.prog_nm,
                   a.aflt_catg_nm,
                   b.src_aflt_catg_nm
            FROM (SELECT DISTINCT src_prod_nm,
                         prog_nm,
                         aflt_catg_nm
                  FROM dw_report.dw_aflt_tran_consolidated_f
                  WHERE src_prod_nm <> ''
                  AND   prog_nm <> '') a
              LEFT OUTER JOIN dw_report.dw_aflt_category_map b
                           ON a.src_prod_nm = b.src_aflt_prod_nm
                          AND a.prog_nm = b.src_aflt_prog_nm
                          AND a.aflt_catg_nm = b.src_aflt_catg_nm)
      WHERE src_aflt_catg_nm IS NULL) p
  LEFT OUTER JOIN dw_report.src_sys_d q ON p.aflt_catg_nm = q.srce_sys_detail_tx;
