CREATE EXTERNAL TABLE dwnl_stage.ApiResponseEvent_raw_s (
    envelope STRUCT<exchangeId:STRING, id:STRING, type:STRING, subtype:STRING>,
    payload STRUCT<
        header:STRUCT<
          eventName:STRING,
          `timestamp`:BIGINT,
          guid:STRING,
          environment:STRING,
          serviceCallHeader:STRUCT<
            callerClientId:STRING,
            referringCallerClientId:STRING
          >
        >,
        api_response_event_id:STRING,
        duration_ms:BIGINT,
        endpoint:STRING,
        request_payload:STRING,
        response_data:STRING,
        response_meta:STRING
    >
    )
PARTITIONED BY (dw_eff_dt DATE)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES (
  "ignore.malformed.json" = "true"
)
LOCATION 's3://east1-prod-nerdlake-0/dwnl_stage/ApiResponseEvent_s/';

MSCK REPAIR TABLE dwnl_stage.ApiResponseEvent_raw_s;


CREATE EXTERNAL TABLE dwnl_stage_stageenv.ApiResponseEvent_raw_s (
    envelope STRUCT<exchangeId:STRING, id:STRING, type:STRING, subtype:STRING>,
    payload STRUCT<
        header:STRUCT<
          eventName:STRING,
          `timestamp`:BIGINT,
          guid:STRING,
          environment:STRING,
          serviceCallHeader:STRUCT<
            callerClientId:STRING,
            referringCallerClientId:STRING
          >
        >,
        api_response_event_id:STRING,
        duration_ms:BIGINT,
        endpoint:STRING,
        request_payload:STRING,
        response_data:STRING,
        response_meta:STRING
    >
    )
PARTITIONED BY (dw_eff_dt DATE)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES (
  "ignore.malformed.json" = "true"
)
LOCATION 's3://east1-prod-nerdlake-0/dwnl_stage_stageenv/ApiResponseEvent_s/';

MSCK REPAIR TABLE dwnl_stage_stageenv.ApiResponseEvent_raw_s;
