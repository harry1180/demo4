
--drop   table dw_stage.click_event_personal_loans_s ;

--create table dw_stage.click_event_personal_loans_s
(
  affiliateId            varchar(6000) encode lzo
, browserSessionId       varchar(6000) encode lzo
, category               varchar(6000) encode lzo
, cookieId               varchar(6000) encode lzo
, creditScoreFilterMax   bigint        encode lzo
, creditScoreFilterMin   bigint        encode lzo
, environment            varchar(6000) encode lzo
, errorMessages          varchar(6000) encode lzo
, eventName              varchar(6000) encode lzo
, guid                   varchar(6000) encode lzo
, impressionId           varchar(6000) encode lzo
, ip                     varchar(6000) encode lzo
, linkType               varchar(6000) encode lzo
, loanAmountFilter       bigint        encode lzo
, loanTermFilter         varchar(6000) encode lzo
, loanTermFilter_12      boolean       encode raw
, loanTermFilter_24      boolean       encode raw
, loanTermFilter_30      boolean       encode raw
, loanTermFilter_36      boolean       encode raw
, loanTermFilter_48      boolean       encode raw
, loanTermFilter_60      boolean       encode raw
, loanTermFilter_72      boolean       encode raw
, loanTermFilter_84      boolean       encode raw
, monetizing             boolean       encode raw
, offerVersionId         integer       encode lzo
, pageNumber             integer       encode lzo
, pageviewId             varchar(6000) encode lzo
, productId              varchar(6000) encode lzo
, productInstance        varchar(6000) encode lzo
, productLocation        varchar(6000) encode lzo
, productPosition        integer       encode lzo
, productSlug            varchar(6000) encode lzo
, referrer               varchar(6000) encode lzo
, requestId              varchar(6000) encode lzo
, sectionPosition        integer       encode lzo
, sortColumn             varchar(6000) encode lzo
, sponsored              boolean       encode raw
, stateFilter            varchar(6000) encode lzo
, "timestamp"            timestamp     encode lzo
, uniqueClickId          varchar(6000) encode lzo
, url                    varchar(6000) encode lzo
, userAgent              varchar(6000) encode lzo
, userId                 varchar(6000) encode lzo
, userRoles              varchar(6000) encode lzo
, userType               varchar(6000) encode lzo
, zdw_user_agent         varchar(6000) encode lzo
, zzz_is_valid           varchar(6000) encode lzo
, zzz_new_url            varchar(6000) encode lzo
, zzz_parse_netloc       varchar(6000) encode lzo
, zzz_parse_path         varchar(6000) encode lzo
, zzz_parse_scheme       varchar(6000) encode lzo
, zzz_validated_netloc   varchar(6000) encode lzo
, zzz_validated_path     varchar(6000) encode lzo
, zzz_validated_query    varchar(6000) encode lzo
, zzz_validated_scheme   varchar(6000) encode lzo
, zzz_validated_url      varchar(6000) encode lzo
, pqid                   varchar(6000)
, loanUseFilter          varchar(6000)
, annualIncomeFilter     varchar(6000)
, borrowerEmploymentStatus varchar(6000)
, borrowerZip            varchar(6000)
, borrowerResidency      varchar(6000)
, borrowerAge            varchar(6000)
) 
distkey(uniqueClickId) 
sortkey(affiliateId) 
;

GRANT ALL    ON dw_stage.click_event_personal_loans_s TO group grp_etl;
GRANT SELECT ON dw_stage.click_event_personal_loans_s TO group grp_data_users;
