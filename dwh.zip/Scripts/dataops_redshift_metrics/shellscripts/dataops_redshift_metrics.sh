job_name='dataops_redshift_metrics'


job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
        bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'


echo_processing_step ${job_name} "Collecting Query Log summary" "Started"
python -c "from redshift_modules import exec_query; import os,sys; query1=open('${dwh_scripts_base_dir}/${job_name}/sqlfiles/redshift_qrylog_metrics_smry_i.sql','r').read(); exec_query(query1, DB='redshift', user='superuser')"
echo_processing_step ${job_name} "Collecting Query Log summary" "Completed"

echo_processing_step ${job_name} "Collecting tables space summary" "Started"
python -c "from redshift_modules import exec_query; import os,sys; query1=open('${dwh_scripts_base_dir}/${job_name}/sqlfiles/redshift_tablespace_smry_i.sql','r').read(); exec_query(query1, DB='redshift', user='superuser')"
echo_processing_step ${job_name} "Collecting tables space summary" "Completed"


echo_processing_step ${job_name} "Collecting tables usage detail" "Started"
python -c "from redshift_modules import exec_query; import os,sys; query1=open('${dwh_scripts_base_dir}/${job_name}/sqlfiles/redshift_tableusage_i.sql','r').read(); exec_query(query1, DB='redshift', user='superuser')"
echo_processing_step ${job_name} "Collecting tables usage detail" "Completed"

echo_processing_step ${job_name} "Collecting tables usage summary" "Started"
python -c "from redshift_modules import exec_query; import os,sys; query1=open('${dwh_scripts_base_dir}/${job_name}/sqlfiles/redshift_tableusage_smry_i.sql','r').read(); exec_query(query1, DB='redshift', user='superuser')"
echo_processing_step ${job_name} "Collecting tables usage summary" "Completed"


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"
job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
***************************************
*** '$job_name' LOAD COMPLETED  ***
***************************************
'

