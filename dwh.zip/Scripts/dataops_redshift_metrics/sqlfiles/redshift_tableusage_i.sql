--#!
--# Intial Version Created: 05/17/2017 KM
--# Insert script to populate the dw_admin.redshift_tableusage table
--# 


--# Make sure the records don't exist hence use a LOJ with the target table.
--# All table scans are recorded into the stl_scans table. So we could leverage it for table use.

insert into dw_admin.redshift_tableusage
(
  
  query
  ,query_start_date
  ,databasename
  ,schemaname
  ,table_id
  ,tablename
  ,LogDate
)

SELECT
       
       s.query
       ,s.query_start_date
       ,DATABASE as databasename
       ,SCHEMA AS schemaname
       ,t.table_id::INTEGER
       ,"table" AS tablename
       ,CURRENT_DATE::DATE LogDate

FROM svv_table_info t
 INNER JOIN
 (
 select
  tbl
  ,query
  ,perm_table_name
  ,min(starttime::date) as query_start_date
 from stl_scan
 where
  userid > 1
AND perm_table_name NOT IN ('Internal Worktable','S3')
group by 1,2,3
  )s
  ON s.tbl = t.table_id
 AND t."schema" NOT IN ('pg_internal')
 LEFT OUTER JOIN
  dw_admin.redshift_tableusage tu
 ON
   tu.query=s.query
   and tu.query_start_date=s.query_start_date
 WHERE tu.query is null
 AND tu.query_start_date is null
; 
