--#!
--# Intial Version Created: 04/17/2017 KM
--# Insert script to populate the dw_admin.redshift_tablespace_smry table
--# 

delete from dw_admin.redshift_tablespace_smry where logdate =current_date::date;

--Cleans the table of current days records so that we don't have dups or account
-- for data twice.

insert into dw_admin.redshift_tablespace_smry
 (
  logdate
  ,ownername
  ,databasename
  ,schemaname
  ,tablename
  ,table_id
  ,spacemb
  ,effectivespacemb
  ,skewoverheadmb
  ,spaceuseefficiency
  ,slicecount
  ,encoded
  ,diststyle
  ,sortkey1
  ,max_varchar
  ,sortkey1_enc
  ,sortkey_num
  ,tblsize
  ,pct_used
  ,unsorted
  ,stats_off
  ,tbl_rows
  ,skew_sortkey1
  ,skew_rows
)

select 
  current_date::date as LogDate
  ,cast(use.usename as varchar(50)) as OwnerName
  ,trim(pgdb.datname) as DatabaseName
  ,trim(pgn.nspname) as SchemaName
  ,trim(a.name) as TableName
  ,a.id as Table_Id
  ,b.SpaceMB
  ,b.EffectiveSpaceMB
  ,b.SkewOverheadMB
  ,b.SpaceUseEfficiency
  ,b.slicecount
  ,c.encoded
  ,c.diststyle
  ,c.sortkey1
  ,c.max_varchar
  ,c.sortkey1_enc
  ,c.sortkey_num
  ,c.size as TBLSize
  ,c.pct_used
  ,c.unsorted
  ,c.stats_off
  ,c.tbl_rows
  ,c.skew_sortkey1
  ,c.skew_rows
from 
(select 
   db_id
   ,id
   ,name
   ,sum(rows) as RowCount
  from stv_tbl_perm group by 1,2,3 ) a
INNER JOIN
(
select 
    tbl
    ,max(mbytes) - min(mbytes) as MaxMinDiffMB
    ,max(mbytes) as MaxSliceMB
    ,min(mbytes) as MinSliceMB
    ,(max(mbytes)*slicecount)-sum(mbytes)as SkewOverheadMB
    ,max(mbytes)*slicecount as EffectiveSpaceMB
    ,sum(mbytes) SpaceMB
    ,slicecount 
    ,sum(mbytes)::Float/(max(mbytes)*slicecount) as SpaceUseEfficiency
  
  from 
   (
      select 
          tbl,
          slice,
          count(*) as mbytes
         from stv_blocklist
         where tbl > 0
         group by tbl, slice
    ) derv
  ,(select count(slice) as slicecount from stv_slices)derv_slice
  group by 
    tbl
    ,slicecount  
) b
on a.id=b.tbl
join pg_database as pgdb 
on pgdb.oid = a.db_id
JOIN SVV_TABLE_INFO c
ON c.table_id=a.id
 join pg_class as pgc on pgc.oid = a.id
 left join pg_user use on (pgc.relowner = use.usesysid)
 join pg_namespace as pgn on pgn.oid = pgc.relnamespace
 -- of we want to leave out system schemas comment the line below.
 --  and pgn.nspowner > 1
;

 
