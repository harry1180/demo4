--#!
--# Intial Version Created: 04/27/2017 KM
--# Insert script to populate the dw_admin.redshift_tableusage_smry table
--# 

delete from dw_admin.redshift_tableusage_smry where logdate =current_date::date;

--Cleans the table of current days records so that we don't have dups or account
-- for data twice.

insert into dw_admin.redshift_tableusage_smry
 (
   LogDate
  ,databasename
  ,schemaname
  ,table_id
  ,tablename
  ,size
  ,sortkey1
  ,QueryCount
)
SELECT 
       CURRENT_DATE::DATE LogDate
       ,DATABASE as databasenam
       ,SCHEMA AS schemaname
       ,table_id::INTEGER
       ,"table" AS tablename
       ,size
       ,sortkey1
       ,NVL(s.num_qs,0) QueryCount
FROM svv_table_info t
  LEFT JOIN (SELECT tbl,
                    perm_table_name,
                    COUNT(DISTINCT query) num_qs
             FROM stl_scan s
             WHERE s.userid > 1
             AND   s.perm_table_name NOT IN ('Internal Worktable','S3')
             GROUP BY tbl,
                      perm_table_name) s
         ON s.tbl = t.table_id
        AND t."schema" NOT IN ('pg_internal'); 
