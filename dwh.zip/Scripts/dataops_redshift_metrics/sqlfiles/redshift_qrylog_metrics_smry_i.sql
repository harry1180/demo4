--#!
--# Intial Version Created: 04/27/2017 KM
--# Insert script to populate the dw_admin.redshift_qrylog_metrics_smry table
--#

insert into dw_admin.redshift_qrylog_metrics_smry
(  
   query
  ,query_start_date 
  ,usename 
  ,userid
  ,db
  ,querytxt
  ,queue_start_time
  ,class
  ,slots
  ,queue_seconds
  ,exec_seconds
  ,total_seconds
  ,gating_efficiency
  ,gating_bin
  ,aborted
  ,pid
  ,xid
  ,query_starttime
  ,query_start_min
  ,query_start_hour
  ,diskbased
  ,rrscan
  ,delayed_scan
  ,stepscount
  ,totalbyteschurngb
  ,maxmemheldgb
  ,event
  ,slicesused
  ,query_cpu_time
  ,query_blocks_read
  ,query_execution_time
  ,burnrate
  ,burnratebin
  ,query_temp_blocks_to_disk
  ,segment_execution_time
  ,cpu_skew
  ,parallelefficiency
  ,parallelefficiencydisk
  ,effectivecpu
  ,skewoverhead
  ,scan_row_count
  ,join_row_count
  ,nested_loop_join_row_count
  ,totalrowsreturned
  ,totalrowchurn
  ,pebin
  ,LogDate
)
select
  query
  ,query_start_date
  ,usename
  ,userid::integer as userid
  ,DB
  ,querytxt
  ,queue_start_time
  ,class
  ,slots
  ,queue_seconds
  ,exec_seconds
  ,total_seconds
  ,gating_efficiency
  ,CASE 
        WHEN gating_efficiency > 0.8 THEN 5
        WHEN gating_efficiency > 0.6 THEN 4
        WHEN gating_efficiency > 0.4 THEN 3
        WHEN gating_efficiency > 0.2 THEN 2
        ELSE 1
   END AS gating_bin
  ,aborted
  ,pid
  ,xid
  ,query_starttime
  ,query_start_min
  ,query_start_hour
  ,diskbased
  ,rrscan
  ,delayed_scan
  ,StepsCount
  ,TotalBytesChurnGB
  ,MaxMemHeldGB
  ,event
  ,SlicesUsed
  ,query_cpu_time
  ,query_blocks_read
  ,query_execution_time
  ,BurnRate
  ,CASE 
        WHEN BurnRate >0.08 THEN 5 
        WHEN BurnRate >0.06 THEN 4 
        WHEN BurnRate >0.04 THEN 3 
        WHEN BurnRate >0.02 THEN 2 
        ELSE 1 
   END AS BurnRateBin
  ,query_temp_blocks_to_disk
  ,segment_execution_time
  ,cpu_skew
  ,ParallelEfficiency
  ,ParallelEfficiencyDisk
  ,EffectiveCPU
  ,SkewOverhead 
  ,scan_row_count
  ,join_row_count
  ,nested_loop_join_row_count
  ,TotalRowsReturned
  ,TotalRowChurn
  ,CASE 
  WHEN (SkewOverhead-query_cpu_time/3) <=50 THEN 5 
  WHEN (SkewOverhead-query_cpu_time/1.5) <=150 THEN 4 
  WHEN (SkewOverhead-query_cpu_time) <=500 THEN 3 
  WHEN (SkewOverhead-query_cpu_time*1.5) <=1500 THEN 2 
  ELSE 1 
  END AS PEBin  
 ,(current_date)::date as LogDate
from
(
SELECT 
        u.usename::CHAR(100) as usename
       ,q.userid
       ,TRIM(DATABASE) AS DB
       ,w.query
       ,SUBSTRING(q.querytxt,1,100) AS querytxt
       ,w.queue_start_time
       ,w.service_class AS class
       ,w.slot_count AS slots
       ,w.total_queue_time / 1000000 AS queue_seconds
       ,w.total_exec_time / 1000000 exec_seconds
       ,(w.total_queue_time + w.total_Exec_time) / 1000000 AS total_seconds
       ,coalesce((w.total_exec_time / 1000000 )::Float/Nullif(((w.total_queue_time + w.total_Exec_time) / 1000000),0),1.00) AS gating_efficiency
       ,q.aborted
       ,q.pid
       ,q.xid
       ,q.starttime as query_starttime
       ,DATE_PART(minute,q.starttime) AS query_start_min
       ,DATE_PART(hour,q.starttime) AS query_start_hour
       ,q.starttime::DATE AS query_start_date
       ,qrysumm.diskbased
       ,qrysumm.rrscan
       ,qrysumm.delayed_scan
       ,coalesce(qrysumm.StepCount,0)As StepsCount
       ,coalesce(qrysumm.MaxMemHeldGB,0)MaxMemHeldGB
       ,coalesce(qrysumm.TotalBytesChurnGB,0)TotalBytesChurnGB
       ,DECODE(alrt.event,'Very selective query filter','Filter','Scanned a large number of deleted rows','Deleted','Nested Loop Join in the query plan','Nested Loop','Distributed a large number of rows across the network','Distributed','Broadcasted a large number of rows across the network','Broadcast','Missing query planner statistics','Stats',alrt.event) AS event
       ,PE.slicecount SlicesUsed
       ,PE.query_cpu_time
       ,PE.query_blocks_read
       ,PE.query_execution_time
       ,PE.BurnRate
       ,PE.query_temp_blocks_to_disk
       ,PE.segment_execution_time
       ,PE.cpu_skew
       ,PE.ParallelEfficiency
       ,PE.ParallelEfficiencyDisk
       ,PE.EffectiveCPU
       ,PE.SkewOverhead 
       ,PE.scan_row_count
       ,PE.join_row_count
       ,PE.nested_loop_join_row_count
       ,coalesce(PE.return_row_count,0) TotalRowsReturned
       ,coalesce(PE.TotalRowChurn,0) TotalRowChurn

FROM stl_query q
  INNER JOIN pg_user u 
        ON q.userid = u.usesysid
  LEFT JOIN dw_admin.redshift_qrylog_metrics_smry smry
  ON q.query=smry.query
  AND q.starttime::DATE=smry.query_start_date
  LEFT JOIN 
(
  select
    query
    ,query_cpu_time
    ,query_blocks_read
    ,query_execution_time
    ,query_cpu_usage_percent::Float/100 as BurnRate
    ,query_temp_blocks_to_disk
    ,segment_execution_time
    ,cpu_skew
    ,100/cpu_skew as ParallelEfficiency
    ,100/io_skew as ParallelEfficiencyDisk
    ,query_cpu_time*cpu_skew as EffectiveCPU
    ,(query_cpu_time*cpu_skew - query_cpu_time) as SkewOverhead 
    ,scan_row_count
    ,join_row_count
    ,nested_loop_join_row_count
    ,return_row_count
    ,(scan_row_count+join_row_count+nested_loop_join_row_count+return_row_count) as TotalRowChurn
    ,slicecount
  from 
    SVL_QUERY_METRICS_SUMMARY 

  ,(select count(slice) as slicecount from stv_slices)derv_slice 
) AS PE
ON q.query=PE.query

  LEFT JOIN
  (
    SELECT q.query, q.event
    FROM (SELECT e.query, trim(split_part(event,':',1)) AS event, 
                 ROW_NUMBER() OVER (PARTITION BY e.query ORDER BY event_time DESC) as RowNum
              FROM STL_ALERT_EVENT_LOG e where event_time::DATE >= CURRENT_DATE- 7) q
    WHERE q.RowNum = 1

    ) AS alrt
  ON 
    alrt.query = q.query
  LEFT JOIN
        (
        select 
          userid
          ,query
          ,max(is_diskbased) diskbased
          ,max(is_rrscan) rrscan
          ,max(is_delayed_scan) delayed_scan
          ,count(step) StepCount
          ,max(workmem)/(1000*1000*1000) as MaxMemHeldGB
          ,sum(bytes)/(1000*1000*1000) as TotalBytesChurnGB
        from 
           svl_query_summary
        group by 
            userid
            ,query
        )  qrysumm
         ON q.userid=qrysumm.userid
         and q.query= qrysumm.query   
  LEFT JOIN stl_wlm_query w
         ON q.query = w.query
        AND q.userid = w.userid
WHERE w.queue_start_Time::DATE > CURRENT_DATE- 7
  --and w.total_queue_Time > 0
  --and w.userid >1
  and smry.query is null
  and smry.query_start_date is null
) derv
