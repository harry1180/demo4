#!
# Initial 04/17/2017 KM.
# DDL for the table usage table.
#
--DROP TABLE IF EXISTS dw_admin.redshift_tableusage CASCADE;
CREATE TABLE dw_admin.redshift_tableusage
(
   
   query         integer distkey,
   query_start_date       date,
   databasename  varchar(128) ENCODE raw,
   schemaname    varchar(128) ENCODE raw,
   table_id      integer        ENCODE raw,
   tablename     varchar(128) ENCODE raw,
   logdate       date         ENCODE raw
 )
sortkey (query,query_start_date)
;
