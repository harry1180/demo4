#!
# Initial 04/27/2017 KM.
# DDL for the table usage summary table.
#
DROP TABLE IF EXISTS dw_admin.redshift_tableusage_smry CASCADE;

CREATE TABLE dw_admin.redshift_tableusage_smry 
(
  logdate      DATE sortkey ENCODE raw,
  databasename VARCHAR(128) ENCODE raw,
  schemaname   VARCHAR(128) ENCODE raw,
  table_id     INTEGER distkey ENCODE raw,
  tablename    VARCHAR(128) ENCODE raw,
  size         BIGINT ENCODE raw,
  sortkey1     VARCHAR(128) ENCODE raw,
  querycount   BIGINT ENCODE raw,
  PRIMARY KEY (logdate,table_id)
)
diststyle KEY;
