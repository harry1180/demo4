#!
# Initial 04/27/2017 KM.
# DDL for the space summary table.
#
DROP TABLE IF EXISTS dw_admin.redshift_qrylog_metrics_smry CASCADE;
CREATE TABLE dw_admin.redshift_qrylog_metrics_smry
(
   query                       integer distkey,
   query_start_date            date,
   usename                     char(100)ENCODE raw,
   userid                      integer ENCODE raw,
   db                          varchar(32) ENCODE raw,
   querytxt                    varchar(400) ENCODE raw,
   queue_start_time            timestamp ENCODE raw,
   class                       integer ENCODE raw,
   slots                       integer ENCODE raw,
   queue_seconds               bigint ENCODE raw,
   exec_seconds                bigint ENCODE raw,
   total_seconds               bigint ENCODE raw,
   gating_efficiency           float8 ENCODE raw,
   gating_bin                  integer  ENCODE raw,
   aborted                     integer ENCODE raw,
   pid                         integer ENCODE raw,
   xid                         bigint ENCODE raw,
   query_starttime             timestamp ENCODE raw,
   query_start_min             float8 ENCODE raw,
   query_start_hour            float8 ENCODE raw,
   diskbased                   varchar(1) ENCODE raw,
   rrscan                      varchar(1) ENCODE raw,
   delayed_scan                varchar(1) ENCODE raw,
   stepscount                  bigint ENCODE raw,
   totalbyteschurngb           bigint ENCODE raw,
   maxmemheldgb                bigint ENCODE raw,
   event                       varchar(1024)  ENCODE raw,
   slicesused                  bigint ENCODE raw,
   query_cpu_time              bigint ENCODE raw,
   query_blocks_read           bigint ENCODE raw,
   query_execution_time        bigint ENCODE raw,
   burnrate                    float8 ENCODE raw,
   burnratebin                 integer ENCODE raw,
   query_temp_blocks_to_disk   bigint ENCODE raw,
   segment_execution_time      bigint ENCODE raw,
   cpu_skew                    numeric(38,2) ENCODE raw,
   parallelefficiency          numeric(38,33) ENCODE raw,
   parallelefficiencydisk      numeric(38,33) ENCODE raw,
   effectivecpu                numeric(38,2) ENCODE raw,
   skewoverhead                numeric(38,2) ENCODE raw,
   scan_row_count              bigint ENCODE raw,
   join_row_count              bigint ENCODE raw,
   nested_loop_join_row_count  bigint ENCODE raw,
   totalrowsreturned           bigint ENCODE raw,
   totalrowchurn               bigint ENCODE raw,
   pebin                       integer ENCODE raw,
   LogDate                     date ENCODE raw
)
diststyle key
sortkey (query,query_start_date)
;
