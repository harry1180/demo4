#!
# Initial 04/17/2017 KM.
# DDL for the space summary table.
#

DROP TABLE IF EXISTS dw_admin.redshift_tablespace_smry CASCADE;

CREATE TABLE dw_admin.redshift_tablespace_smry
(
   logdate             date sortkey ENCODE raw,
   ownername           varchar(50)ENCODE raw,
   databasename        varchar(128)ENCODE raw,
   schemaname          varchar(128)ENCODE raw,
   tablename           varchar(72)ENCODE raw,
   table_id            integer distkey ENCODE raw,
   spacemb             bigint ENCODE raw,
   effectivespacemb    bigint ENCODE raw,
   skewoverheadmb      bigint ENCODE raw,
   spaceuseefficiency  float8 ENCODE raw,
   slicecount          bigint ENCODE raw,
   encoded             varchar(1) ENCODE raw,
   diststyle           varchar(133) ENCODE raw,
   sortkey1            varchar(128) ENCODE raw,
   max_varchar         integer ENCODE raw,
   sortkey1_enc        char(32) ENCODE raw,
   sortkey_num         integer ENCODE raw,
   tblsize             bigint ENCODE raw,
   pct_used            numeric(10,4) ENCODE raw,
   unsorted            numeric(5,2) ENCODE raw,
   stats_off           numeric(5,2) ENCODE raw,
   tbl_rows            numeric(38) ENCODE raw,
   skew_sortkey1       numeric(19,2) ENCODE raw,
   skew_rows           numeric(19,2) ENCODE raw,
   primary key(logdate,table_id)
   )

   diststyle key 
;
