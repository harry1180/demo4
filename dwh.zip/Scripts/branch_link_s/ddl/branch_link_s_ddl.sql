
CREATE TABLE dw_stage.branch_link_export_s
(
  ios_deeplink_path       VARCHAR(3000),
  android_deeplink_path   VARCHAR(3000),
  deeplink_path           VARCHAR(3000),
  post_id                 VARCHAR(3000),
  link_url                VARCHAR(3000),
  link_campaign           VARCHAR(3000),
  canonical_url           VARCHAR(3000),
  link_creation_source    VARCHAR(3000),
  link_feature            VARCHAR(3000),
  id                      VARCHAR(3000),
  one_time_use            boolean,
  link_tags               VARCHAR(3000),
  og_image_url            VARCHAR(3000),
  og_description          VARCHAR(3000),
  og_title                VARCHAR(3000),
  og_video                VARCHAR(3000),
  creation_timestamp      TIMESTAMP,
  link_id                 VARCHAR(300),
  branch_identity_id      VARCHAR(300),
  channel                 VARCHAR(3000),
  feature                 VARCHAR(3000),
  campaign                VARCHAR(3000),
  stage                   VARCHAR(3000),
  tags                    VARCHAR(3000),
  data                    VARCHAR(10000) ,
  creation_source         VARCHAR(3000),
  ALIAS VARCHAR(3000),
  DOMAIN VARCHAR(3000),
  url                     VARCHAR(3000)
);

GRANT ALL    ON dw_stage.branch_link_export_s       TO GROUP grp_etl;
GRANT SELECT ON dw_stage.branch_link_export_s       TO GROUP grp_data_users;
ALTER TABLE     dw_stage.branch_link_export_s owner TO nw_dwh_etl;
