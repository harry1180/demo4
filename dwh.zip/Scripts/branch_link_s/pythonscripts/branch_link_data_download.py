import sys
from branch_api_download  import get_branch_data

key=sys.argv[1]
skey=sys.argv[2]
report_to_download_date=sys.argv[3]
file_path=sys.argv[4]
dim=sys.argv[5]
job_name=sys.argv[6]
source_bucket=sys.argv[7]
json_file=sys.argv[8]
extra_json_file=sys.argv[9]


url='https://api.branch.io/v2/export/'

field_name_list='creation_timestamp,link_id,branch_identity_id,channel,feature,campaign,stage,tags,data,creation_source,alias,domain,url'

# defining various dictionary for different json objects.
json_dict={      
            'data' :{'$ios_deeplink_path':'ios_deeplink_path','$android_deeplink_path':'android_deeplink_path','$deeplink_path':'deeplink_path','post_id':'post_id', '+url': 'link_url', '~campaign': 'link_campaign' ,'$canonical_url': 'canonical_url', '~creation_source': 'link_creation_source' ,'~feature': 'link_feature' ,'~id': 'id', '$one_time_use': 'one_time_use', '~tags': 'link_tags' ,'$og_image_url': 'og_image_url', '$og_description': 'og_description', '$og_title': 'og_title', '$og_video' : 'og_video' }

          }


final_url=url+key+'?branch_secret='+skey+'&export_date='+report_to_download_date

print "Call function to download the data"
if get_branch_data (final_url,file_path,dim, json_dict,field_name_list,job_name,source_bucket,json_file,extra_json_file)== -1 :
   print "Error in processing. Existing"
   sys.exit(1)
else :
   print 'processing completed successfully for %s '   %report_to_download_date 
   

