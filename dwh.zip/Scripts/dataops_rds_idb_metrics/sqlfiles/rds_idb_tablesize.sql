\copy (SELECT 
 current_date as log_date
 ,nspname as Schemaname
 ,relname AS Tablename
 ,usename AS Ownername
 ,'nwallet_identity' as DataBaseName
 ,relam
 ,relfilenode
 ,reltablespace
 ,relpages
 ,reltuples
 ,relallvisible
 ,reltoastrelid
 ,relhasindex
 ,relisshared
 ,relpersistence
 ,relkind
 ,relnatts
 ,relchecks
 ,relhasoids
 ,relhaspkey
 ,relhasrules
 ,relhastriggers
 ,relhassubclass
 ,relispopulated
 ,pg_total_relation_size(C.oid) AS TableSize
FROM pg_class C
LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
LEFT JOIN pg_user U ON (C.relowner=U.usesysid)
WHERE nspname NOT IN ('pg_catalog', 'information_schema')) to ':v1rds_idb_tablesize.csv' with NULL 'NULL';;
