UPDATE dw_report.dw_aflt_fin_tran_f
SET 
			dw_eff_dt = b.dw_eff_dt,
			aflt_fin_tran_id = b.aflt_fin_tran_id,
			tran_click_dt = b.tran_click_dt,
			tran_post_dt = b.tran_post_dt,
			tran_click_ts = b.tran_click_ts,
			tran_post_ts = b.tran_post_ts,
			aflt_fin_actn_type_cd = b.aflt_fin_actn_type_cd,
			dw_site_visitor_id = b.dw_site_visitor_id,
			src_site_visitor_tx = b.src_site_visitor_tx,
			prod_src_sys_id = b.prod_src_sys_id,
			dw_site_prod_sk = b.dw_site_prod_sk,
			src_prod_nm = b.src_prod_nm,
			src_app_status_tx = b.src_app_status_tx,
			prog_nm = b.prog_nm,
			catg_nm = b.catg_nm,
			commision_am = b.commision_am,
			merchant_am = b.merchant_am
FROM 
dw_stage.aflt_tran_post_s b
WHERE dw_report.dw_aflt_fin_tran_f.network_tran_id = b.network_tran_id
AND dw_report.dw_aflt_fin_tran_f.aflt_network_id = b.aflt_network_id;
