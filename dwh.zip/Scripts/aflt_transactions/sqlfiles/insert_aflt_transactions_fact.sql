INSERT INTO dw_report.dw_aflt_fin_tran_f
	SELECT 	network_tran_id,
			aflt_network_id,
			coalesce(dw_eff_dt,tran_post_dt) as dw_eff_dt,
			aflt_fin_tran_id,
			tran_click_dt,
			tran_post_dt,
			tran_click_ts,
			tran_post_ts,
			aflt_fin_actn_type_cd,
			dw_site_visitor_id,
			src_site_visitor_tx,
			prod_src_sys_id,
			dw_site_prod_sk,
			src_prod_nm,
			src_app_status_tx,
			prog_nm,
			catg_nm,
			commision_am,
			merchant_am,
			dw_load_ts 
FROM (
SELECT 	a.*, 
		b.network_tran_id  as record_check 
FROM dw_stage.aflt_tran_post_s  a 
LEFT OUTER JOIN 
dw_report.dw_aflt_fin_tran_f b
ON a.network_tran_id = b.network_tran_id
AND a.aflt_network_id = b.aflt_network_id)
WHERE 
record_check is null;
