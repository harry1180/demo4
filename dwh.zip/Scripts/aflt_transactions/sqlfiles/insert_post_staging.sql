INSERT INTO dw_stage.aflt_tran_post_s
   (SELECT a.network_transaction_id,
           coalesce (b.aflt_network_id, -999999999),
           trunc (a.click_date),
           a.id,
           trunc (a.click_date),
           trunc (a.post_date),
           a.click_date,
           a.post_date,
           a.action_type,
           coalesce (d.dw_site_visitor_id, -999999999),
           a.session_id,
           coalesce (d.dw_src_sys_id, -999999999),
           coalesce (d.dw_site_prod_sk, '-999999999'),
           coalesce (d.src_prod_nm, 'Not Fount In Clicks'),
           a.application_status_tx,
           a.program_name,
           a.category_name,
           a.commission_amount,
           a.merchant_amount,
           sysdate
      FROM dw_stage.aflt_tran_s a
           LEFT OUTER JOIN dw_report.dw_aflt_network_d b
              ON coalesce (a.network, 'NA') =
                    coalesce (b.aflt_network_shrt_nm, 'UNKNOWN')
           LEFT OUTER JOIN
           (  SELECT src_unique_click_id,
                     dw_site_visitor_id,
                     src_prod_nm,
                     dw_src_sys_id,
                     dw_site_prod_sk
                FROM 
                     dw_report.dw_clicks_event_f  ) d
              ON coalesce (a.session_id, 'NA') =
                    coalesce (d.src_unique_click_id, 'UNKNOWN'));
