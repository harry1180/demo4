INSERT INTO dw_stage.identity_event_post_s
(
  src_guid_tx	      
, actvy_type_cd       
, dw_eff_dt	          
, user_id	          
, identity_event_utc_ts	  
, dw_page_view_id	  	
, geo_loc_id	      
, site_uv_id	      
, src_env_id	      
, logged_ip           
, src_event_nm	      
, url_tx	          
, rfr_tx	          
, user_agent_long_tx	
, src_user_role_tx	  
, src_brwsr_sesn_id   
, req_id	          
, client_app_id	      
, caller_client_id	  
, rfr_caller_client_id
)
SELECT
  guid                    as src_guid_tx	      
, 'DEACTIVATE'            as actvy_type_cd       
, trunc("timestamp")      as dw_eff_dt	          
, userid                  as user_id	          
, "timestamp"             as identity_event_utc_ts	  
, pageviewid              as dw_page_view_id	  	
, geoId                   as geo_loc_id	      
, cookieid                as site_uv_id	      
, (
    case 
      when lower(environment) = 'dev'   then 1
      when lower(environment) = 'prod'  then 2
      when lower(environment) = 'stage' then 3
    end
  )                       as src_env_id	      
, ip                      as logged_ip           
, eventname               as src_event_nm	      
, url                     as url_tx	          
, referrer                as rfr_tx	          
, useragent               as user_agent_long_tx	
, userroles               as src_user_role_tx	  
, browsersessionid        as src_brwsr_sesn_id   
, requestid               as req_id	          
, applicationid           as client_app_id	      
, callerclientid          as caller_client_id	  
, referringcallerclientid as rfr_caller_client_id
FROM  dw_stage.deactivate_identity_event_s
where length(coalesce(trim(guid), ''))        < 45
  and length(coalesce(trim(cookieid), ''))    < 45
  and length(coalesce(trim(pageviewid), ''))  < 45
;
