
drop   table dw_stage.brain_user_s;

CREATE TABLE dw_stage.brain_user_s  
(  
id             BIGINT , 
role           BIGINT , 
role_tx        VARCHAR(50),
created_at     TIMESTAMP , 
updated_at     TIMESTAMP 
)  
distkey (id) ;

GRANT ALL  ON dw_stage.brain_user_s TO GROUP grp_etl;


