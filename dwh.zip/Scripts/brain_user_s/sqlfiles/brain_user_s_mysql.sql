SELECT 
  id            
, role       
, case    when role=0 then 'User'
          when role=1 then 'Admin'
          when role=2 then 'Biz'
          when role=3 then 'Compliance'
          when role=4 then 'Expert'
          when role=5 then 'Janitor'
          when role=6 then 'Cron'
          when role=7 then 'Finpro'
          when role=8 then 'Brain'
          when role=9 then 'Dwh'
          when role is null then 'Null'
          else 'Unknown'         
          end as role_tx
, created_at     
, updated_at     
FROM
  bcc_app.users;
;

