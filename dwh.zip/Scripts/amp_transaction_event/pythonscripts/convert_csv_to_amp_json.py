import sys

from amplitude_modules import convert_csv_to_amp_json, send_data_to_amplitude

field_name_list = [
 "site_uv_id"
,"user_id"
,"aflt_network_tran_id"
,"event_type_nm"
,"quantity_nr"
,"aflt_network_id"
,"aflt_fin_tran_type_cd"
,"dw_eff_dt"
,"nw_click_dt"
,"tran_rev_rlzd_dt"
,"tran_post_dt"
,"tran_click_dt"
,"tran_post_utc_ts_epoch"
,"tran_post_ts"
,"tran_click_ts"
,"src_clicks_utc_ts"
,"src_prod_nm"
,"dw_site_visitor_id"
,"dw_site_prod_sk"
,"dw_site_prod_nm"
,"prog_nm"
,"src_unique_click_id"
,"aflt_catg_nm"
,"dw_click_id"
,"dw_click_src_id"
,"src_sys_id"
,"dw_session_id"
,"dw_page_view_id"
,"dw_suspected_bot_in"
,"logged_ip"
,"dw_page_sk"
,"url"
,"page_vertical_tx"
,"page_topic_tx"
,"dw_click_user_agent_id"
,"dw_catg_nm"
,"commission_am"
,"revenue_tran_in"
,"src_revenue_tran_in"
]

amp_event_dict = {
 "user_id":"user_id"
,"device_id":"site_uv_id"
,"event_type":"event_type_nm"
,"time":"tran_post_utc_ts_epoch"
,"event_properties":
{
 "aflt_network_tran_id":"aflt_network_tran_id"
,"aflt_network_id":"aflt_network_id"
,"dw_eff_dt":"dw_eff_dt"
,"nw_click_dt":"nw_click_dt"
,"tran_rev_rlzd_dt":"tran_rev_rlzd_dt"
,"tran_post_dt":"tran_post_dt"
,"tran_click_dt":"tran_click_dt"
,"tran_post_ts":"tran_post_ts"
,"tran_click_ts":"tran_click_ts"
,"src_clicks_utc_ts":"src_clicks_utc_ts"
,"dw_site_prod_sk":"dw_site_prod_sk"
,"dw_site_visitor_id":"dw_site_visitor_id"
,"dw_site_prod_nm":"dw_site_prod_nm"
,"prog_nm":"prog_nm"
,"src_unique_click_id":"src_unique_click_id"
,"aflt_catg_nm":"aflt_catg_nm"
,"dw_click_id":"dw_click_id"
,"dw_click_src_id":"dw_click_src_id"
,"src_sys_id":"src_sys_id"
,"dw_session_id":"dw_session_id"
,"dw_page_view_id":"dw_page_view_id"
,"dw_page_sk":"dw_page_sk"
,"url":"url"
,"page_vertical_tx":"page_vertical_tx"
,"page_topic_tx":"page_topic_tx"
,"dw_click_user_agent_id":"dw_click_user_agent_id"
,"dw_catg_nm":"dw_catg_nm"
,"revenue_tran_in":"revenue_tran_in"
,"src_revenue_tran_in":"src_revenue_tran_in"
}
,"user_properties":
{
 "is_bot":"dw_suspected_bot_in"
,"user_click_utc_ts":"src_clicks_utc_ts"
}
,"price":"0"
,"quantity":"quantity_nr"
,"revenue":"0"
,"productId":"src_prod_nm"
,"revenueType":"aflt_fin_tran_type_cd"
,"ip":"logged_ip"
}


def main():
    """
    called by transaction_event only to post data to Amplitude
    """
    if len(sys.argv) != 5:
        print 'Input %d arguments:\n%s' % (len(sys.argv), str(sys.argv))
        print main.__doc__
        print "Exit."
        return

    amp_api_key      = {'api_key': sys.argv[1]}
    amp_api_url      = sys.argv[2]

    input_csv_file   = sys.argv[3]
    output_json_file = sys.argv[4]
    
    convert_csv_to_amp_json(input_csv_file, field_name_list, output_json_file, amp_event_dict)
    
    send_data_to_amplitude(amp_api_url, amp_api_key, output_json_file, 'event', output_json_file + '.unsent')

if __name__ == '__main__':
    main()
