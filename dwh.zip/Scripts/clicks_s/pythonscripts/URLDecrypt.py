# Libraries
# Normal
from datetime import date, timedelta
from base64 import b64decode
from dateutil.relativedelta import relativedelta
from urlparse import parse_qs, urlparse
from nw_url_check import *

import csv
import urllib
import sys
import re
import base64
import datetime
import binascii
import string

# Other Libraries
from dateutil import tz
from Crypto.Cipher import Blowfish


# Find the Redirect term in the referrer
def clean_uv(referrer):
	word = "/redirect.php"
	if word in referrer:
		loc = referrer.find(word)
		referrer = referrer[:loc]
	return referrer

# Test if the referrer is encoded and return the result
def encoded(path):
	try:
		output=base64.decodestring(path)
		return output
	except binascii.Error:
		return path

#Decryption function for the referrer
def decrypt(path):
	# Code
	path=breakpath(path)
	path = path.replace(" ","+")
	if path.startswith("-1") or "?xml" in path: return ""
	if path == '/' or path == '-' or len(path) < 2 or "homepage" in path: 
		plaintext = '/'
	else:
		if path==encoded(path) or "prepaid" in path or "pre-paid" in path or "pre-approved" in path or "-" in path:
			plaintext = path
		else:
			# Inputs for decrypting
			cipher_key = '1337tanner'
			path = base64.b64decode(path)
			initialization_vector = '\x00' * 8
			padding = '\x00' * (8-(len(path) % 8)) 
			cipher = Blowfish.new(cipher_key, Blowfish.MODE_CFB, initialization_vector,segment_size=8)
			# decrypting
			ciphertext = path+padding
			plaintext = cipher.decrypt(ciphertext)
			plaintext = plaintext[:len(path)]
			# Cut off hex shit at beginning
			plaintext = re.split(r'(/[a-z])',plaintext)[1:]
			plaintext = ''.join(plaintext)
	# Test if the decryption was necessary
	# Output
	if "NULL" in path or r"-1'" == path: return ""
	try:
		plaintext = plaintext if plaintext[0]=='/' or plaintext[0]=='-' else '/'+plaintext
		#plaintext = plaintext if plaintext[0]=='/' or plaintext[0]=='-' or len(plaintext)==0 else '/'+plaintext
	except: plaintext
	return plaintext.lower()

def rss_check(path):
	if "rss-http://www.nerdwallet.com" in path: 
		output = path.replace("rss-http://www.nerdwallet.com","")
		return output
	elif "RSS-http://www.nerdwallet.com" in path: 
		output = path.replace("RSS-http://www.nerdwallet.com","")
		return output
	else: return path

def breakpath(path):
	path = rss_check(path)
	words = ["Full-time","Part-time","Home","No","Yes","Other","discover","Renter"]
	for i in range(len(words)):
		if words[i] in path:
			output = re.split(words[i],path)[:1]
			return output[0]
	return path

#'/data/etl/Data/clicks_s_hist/post_clicks.csv'
input_file  = sys.argv[1] 
#"/data/etl/Data/clicks_s_hist/clicks_decrypt_output.csv"
output_file = sys.argv[2] 

with open(input_file, 'rU') as csvfile:
 writer=csv.writer(open(output_file,'wb'), delimiter='\t')
 #with open('/data/clicks_data/clicks_consolidated_Decrypt.csv', 'w') as outfile: 
 lines = csv.reader(csvfile, delimiter='\t')
 for row in lines:
  try:
     input_url= row[5]
     clean_url = clean_uv(input_url)
     replace_space = string.replace(clean_url,' ','+')
     decrypt_url = decrypt(replace_space)
     decode_url = decrypt_url.decode('utf8','ignore').encode('utf8','ignore')
     Final_url = decrypt_url if decrypt_url == decode_url else 'Error'
     Final_clean_url = string.replace(Final_url,'\n','')
     Final_clean_url = string.replace(Final_clean_url,'\t','')
     Final_clean_url = string.replace(Final_clean_url,' ','')
     Final_clean_url = url_strip(Final_clean_url)
     parse_url = urlparse(Final_clean_url)
     parse_scheme = parse_url.scheme
     parse_netloc = parse_url.netloc
     parse_path = parse_url.path
     new_url=nw_url_join(parse_scheme,parse_netloc,url_strip(parse_path))
     validated_url = url_strip(fix_nw_url(new_url))
     validated_parsed = urlparse(validated_url)
     validated_scheme = validated_parsed.scheme
     validated_netloc = validated_parsed.netloc
     validated_path = validated_parsed.path
     is_valid = validate_url_struct(validated_url)
  except:
     outline = [row[0], row[1],row[2],row[3], row[4],row[5],row[6], row[7],row[8],row[9], row[10],row[11],row[12], row[13],row[14],row[15], row[16],row[17],row[18],row[19], row[20],row[21],'','','','','','','','','','']
     writer.writerow(outline)
     pass
   #outline = row[0]+'|'+decrypt_url+'|'+row[5]
  outline = [row[0], row[1],row[2],row[3], row[4],row[5],row[6], row[7],row[8],row[9], row[10],row[11],row[12], row[13],row[14],row[15], row[16],row[17],row[18],row[19], row[20],row[21],Final_clean_url,url_strip(parse_url.path),parse_url.query,parse_url.netloc,parse_url.scheme,new_url,validated_scheme,validated_netloc,validated_path,validated_url]
  #outline = [row[0], row[5],decrypt_url, decode_url,Final_url]
  #outline=[row,decrypt_url]
  writer.writerow(outline)
#outfile.close()

