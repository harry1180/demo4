

job_name='clicks_s'



job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


Linux_Input=${dwh_data_base_dir}/${job_name}/input/
Linux_Output=${dwh_data_base_dir}/${job_name}/output/
Linux_Archive=${dwh_data_base_dir}/${job_name}/archive/
S3_Input=/s3mnt-dwh-staging/${job_name}/input/
S3_Output=/s3mnt-dwh-staging/${job_name}/output/
S3_Archive=/s3mnt-dwh-staging/${job_name}/archive/
S3_Events_Input=${job_name}/input/
S3_Events_Output=${job_name}/output/
S3_Events_Archive=${job_name}/archive/
echo '+----------+----------+----------+----------+----------+----------+'
echo 'dwh_credentials_file_dir   :-   '${dwh_credentials_file_dir}
echo 'dwh_scripts_base_dir       :-   '${dwh_scripts_base_dir}
echo 'dwh_common_base_dir        :-   '${dwh_common_base_dir}
echo 'dwh_data_base_dir          :-   '${dwh_data_base_dir}
echo 'Linux_Input                :-   '${Linux_Input}
echo 'Linux_Output               :-   '${Linux_Output}
echo 'Linux_Archive              :-   '${Linux_Archive}
echo 'S3_Input                   :-   '${S3_Input}
echo 'S3_Output                  :-   '${S3_Output}
echo 'S3_Archive                 :-   '${S3_Input}
echo 'S3_Events_Input            :-   '${S3_Events_Input}
echo 'S3_Events_Output           :-   '${S3_Events_Output}
echo 'S3_Events_Archive          :-   '${S3_Events_Archive}
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
input_date=input_date="$(date +'%Y%m%d%H%M%S')"
echo 'input_date                 :-   '${input_date}
echo '+----------+----------+----------+----------+----------+----------+'



bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name} 's3'
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'


echo_processing_step ${job_name} "Cleanup files and archive files at s3" "Started"
find $Linux_Input/ -name "*clicks*" -exec rm {} \; || true
for f in ${S3_Input}/*.csv.gz
do
mv $f ${S3_Archive}/'clicks_decrypt_'$input_date'.csv.gz' || true
done
echo_processing_step ${job_name} "Cleanup files and archive files at s3" "Completed"

echo_processing_step ${job_name} "Extract click data of Credit Card" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks.sql ${Linux_Input}/pre_clicks_1.csv
echo_processing_step ${job_name} "Extract click data of Credit Card" "Completed"

echo_processing_step ${job_name} "Extract click data of Brokeage" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_brokers_decrypted.sql ${Linux_Input}/pre_clicks_2.csv
echo_processing_step ${job_name} "Extract click data of Brokeage" "Completed"

echo_processing_step ${job_name} "Extract click data of Coupons" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_coupons.sql ${Linux_Input}/pre_clicks_3.csv
echo_processing_step ${job_name} "Extract click data of Coupons" "Completed"

echo_processing_step ${job_name} "Extract click data of Credit Scores" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_credit_scores.sql ${Linux_Input}/pre_clicks_4.csv
echo_processing_step ${job_name} "Extract click data of Credit Scores" "Completed"

echo_processing_step ${job_name} "Extract click data of Insurance Provider" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_insurance_provider.sql ${Linux_Input}/pre_clicks_5.csv
echo_processing_step ${job_name} "Extract click data of Insurance Provider" "Completed"

echo_processing_step ${job_name} "Extract click data of Investing/Network Link" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_investing.sql ${Linux_Input}/pre_clicks_6.csv
echo_processing_step ${job_name} "Extract click data of Investing/Network Link" "Completed"

echo_processing_step ${job_name} "Extract click data of PrePaid Card" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_prepaid_cards.sql ${Linux_Input}/pre_clicks_7.csv
echo_processing_step ${job_name} "Extract click data of PrePaid Card" "Completed"

echo_processing_step ${job_name} "Extract click data of Rates" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_rates.sql ${Linux_Input}/pre_clicks_8.csv
echo_processing_step ${job_name} "Extract click data of Rates" "Completed"

echo_processing_step ${job_name} "Extract click data of Taxes" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_taxes.sql ${Linux_Input}/pre_clicks_9.csv
echo_processing_step ${job_name} "Extract click data of Taxes" "Completed"

echo_processing_step ${job_name} "Extract click data of Insurance Product" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_insurance_product.sql ${Linux_Input}/pre_clicks_11.csv
echo_processing_step ${job_name} "Extract click data of Insurance Product" "Completed"

echo_processing_step ${job_name} "Extract click data of Shopping" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_shopping.sql ${Linux_Input}/pre_clicks_12.csv
echo_processing_step ${job_name} "Extract click data of Shopping" "Completed"

echo_processing_step ${job_name} "Merge all click data" "Started"
rm -f ${Linux_Input}/*clicks*.cnt || true
#consolidating the files into one
cat ${Linux_Input}/*pre_cl*.csv > ${Linux_Input}/"post_clicks.csv" || true
echo_processing_step ${job_name} "Merge all click data" "Completed"

echo_processing_step ${job_name} "Decrypt URL" "Started"
input_file=${Linux_Input}/"post_clicks.csv"
output_file=${Linux_Input}/"clicks_decrypt_output.csv"
python /data/etl/Scripts/clicks_s/pythonscripts/URLDecrypt.py $input_file $output_file
echo_processing_step ${job_name} "Decrypt URL" "Completed"

echo_processing_step ${job_name} "Compress and move click data to s3" "Started"
gzip ${output_file} || true
mv   ${output_file}.gz ${S3_Input}/ || true
chmod 775 ${S3_Input}/clicks_decrypt_output.csv.gz || true
chgrp etl ${S3_Input}/clicks_decrypt_output.csv.gz || true
echo_processing_step ${job_name} "Compress and move click data to s3" "Completed"

echo_processing_step ${job_name} "Delete data from stage table" "Started"
query_stage_delete="delete from dw_stage.clicks_decrypt_s;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Delete data from stage table" "Completed"

echo_processing_step ${job_name} "Load data into stage table" "Started"
bash ${dwh_common_base_dir}/redshift_copy_function.sh "dw_stage.clicks_decrypt_s" "/clicks_s/" "clicks_decrypt_output"
echo_processing_step ${job_name} "Load data into stage table" "Completed"

echo_processing_step ${job_name} "Update homepage data at stage table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/update_stage.sql
echo_processing_step ${job_name} "Update homepage data at stage table" "Completed"


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"
job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
