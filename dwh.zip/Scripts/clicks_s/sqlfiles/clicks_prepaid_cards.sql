SELECT 
    id,
    7 AS srce_sys_id,
    REPLACE(ip, '"', ' '),
    REPLACE(name, '"', ' ') AS prod_name,
    uv,
    REPLACE(REPLACE(url,
            '
            ',
            ''),
        '"',
        ' ') AS url,
    NULL AS fico,
    NULL AS Spend,
    CAST(sponsored AS CHAR) AS sponsored,
    CONVERT_TZ(timestamp,'US/Pacific','utc') as timestamp,
    network,
    REPLACE(nid, '"', ' ') AS nid,
    CONVERT_TZ(timestamp_utc,'US/Pacific','utc') as timestamp_utc,
    unique_click_id,
    user_agent,
    NULL AS PROFILE,
    NULL AS FORWARD,
    NULL AS coupon_id,
    duration,
    CAST(direct_deposit AS CHAR) AS direct_deposit,
    NULL AS position,
    NULL AS zip
FROM
    nwallet_analytics.clicks_prepaid_cards_decrypted
where timestamp_utc  > DATE_SUB(current_date, INTERVAL 15 DAY);
