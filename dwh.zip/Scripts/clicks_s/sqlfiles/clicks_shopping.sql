
select
    id as id ,
    12 AS srce_sys_id,
    REPLACE(ip, '"', ' '),
    REPLACE(store, '"', ' ') AS prod_name,
    uv,
       REPLACE(REPLACE(url,
            '
            ',
            ''),
        '"',
        ' ') AS url,
    NULL AS fico,
    price AS Spend,
    NULL AS sponsored,
    timestamp,
    NULL as network,
    NULL AS nid,
    timestamp AS timestamp_utc,
    unique_click_id AS unique_click_id,
    user_agent AS user_agent,
    NULL AS PROFILE,
    NULL as FORWARD,
    NULL coupon_id,
    NULL AS DURATION,
    NULL AS direct_deposit,
    position AS position,
    NULL AS zip
FROM nwallet_analytics.clicks_shopping_decrypted
where timestamp > DATE_SUB(current_date, INTERVAL 15 DAY)
;
