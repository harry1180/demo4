update dw_stage.clicks_decrypt_s
set
url_decrypt = '/',
url_decrypt_path = '/',
url_new_configured = '/'
where lower(url) = 'homepage';
