SELECT 
    id,
    3 AS srce_sys_id,
    REPLACE(ip, '"', ' '),
    REPLACE(name, '"', ' ') AS prod_name,
    uv,
    REPLACE(REPLACE(url,
            '
            ',
            ''),
        '"',
        ' ') AS url,
    NULL AS fico,
    NULL AS Spend,
    CAST(sponsored AS CHAR) AS sponsored,
    timestamp,
    network,
    REPLACE(nid, '"', ' ') AS nid,
    timestamp AS timestamp_utc,
    NULL AS unique_click_id,
    NULL AS user_agent,
    NULL AS PROFILE,
    FORWARD,
    coupon_id,
    NULL AS DURATION,
    NULL AS direct_deposit,
    NULL AS position,
    NULL AS zip
FROM
    nwallet_analytics.clicks_coupons_decrypted
where timestamp > DATE_SUB(current_date, INTERVAL 15 DAY);
