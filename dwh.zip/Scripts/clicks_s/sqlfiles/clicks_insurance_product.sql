SELECT 
    id,
    11 AS srce_sys_id, 
    REPLACE(ip, '"', ' '),
    cast(product_id as char) AS prod_name,
    uv,
    REPLACE(REPLACE(url,
            '
            ',
            ''),
        '"',
        ' ') AS url,
    NULL AS fico,
    NULL AS Spend,
    CAST(sponsored AS CHAR) AS sponsored,
    timestamp,
    network,
    REPLACE(nid, '"', ' ') AS nid,
    timestamp AS timestamp_utc,
    coalesce(unique_click_id,uv) AS unique_click_id,
    NULL AS user_agent,
    NULL AS PROFILE,
    NULL AS FORWARD,
    NULL AS coupon_id,
    NULL AS DURATION,
    NULL AS direct_deposit,
    NULL AS position,
    NULL AS zip
FROM
    nwallet_analytics.clicks_insurance_decrypted
where 
    product_id is NOT NULL 
AND timestamp > DATE_SUB(current_date, INTERVAL 15 DAY)
;
