SELECT 
    id,
    8 AS srce_sys_id,
    REPLACE(ip, '"', ' '),
    case when UUID is NOT NULL and length(uuid) > 0 then trim(replace(UUID, '"', ' '))
	     else trim(REPLACE(CONCAT(trim(InstitutionName),
                             trim(CertNumber),
                             trim(InstitutionType),
                             trim(InstrumentType),
                             trim(LengthOfTerm)),
                   '"',
                   ' ')
                  )
    end AS prod_name,
    uv,
    REPLACE(REPLACE(url,
            '
            ',
            ''),
        '"',
        ' ') AS url,
    NULL AS fico,
    NULL AS Spend,
    CAST(sponsored AS CHAR) AS sponsored,
    timestamp,
    network,
    REPLACE(nid, '"', ' ') AS nid,
    timestamp AS timestamp_utc,
    unique_click_id,
    NULL AS user_agent,
    NULL AS PROFILE,
    NULL AS FORWARD,
    NULL AS coupon_id,
    NULL AS duration,
    NULL AS direct_deposit,
    position,
    zip
FROM
    nwallet_analytics.clicks_rates_decrypted
where timestamp  > DATE_SUB(current_date, INTERVAL 15 DAY); 
