SELECT
    id                    ,    
    offer_id              ,    
    external_category_id  ,    
    credit_card_id        ,    
    category_rank         ,    
    credit_card_rank      ,    
    position              ,    
    monetizing            ,    
    created_at            ,    
    updated_at               
FROM 
bcc_app.offer_details
where updated_at > DATE_SUB(current_date, INTERVAL 15 DAY)
;
