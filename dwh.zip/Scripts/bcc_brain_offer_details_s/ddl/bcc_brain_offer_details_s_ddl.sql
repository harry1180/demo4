
DROP TABLE IF EXISTS dw_stage.bcc_brain_offer_details_s;

CREATE TABLE dw_stage.bcc_brain_offer_details_s 
(  
id                  BIGINT , 
offer_id             BIGINT , 
external_category_id BIGINT , 
credit_card_id      BIGINT , 
category_rank       BIGINT , 
credit_card_rank    BIGINT , 
position            BIGINT , 
monetizing          smallint , 
created_at          TIMESTAMP , 
updated_at          TIMESTAMP 
);
  
GRANT ALL ON dw_stage.bcc_brain_offer_details_s TO group grp_etl;

GRANT SELECT ON dw_stage.bcc_brain_offer_details_s TO group grp_data_users;

