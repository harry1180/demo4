('SELECT
  floor(((dw_prod_pos_seq_nr - 1)/3)) + 1 as position,
  COUNT(DISTINCT dw_page_view_id) as impressions_count
FROM dw_report.dw_prod_imprsn_event_cc_f
WHERE dw_page_sk = 19006
  AND dw_suspected_bot_in=\'False\'
  AND dw_eff_dt >= trunc(sysdate - 91)
GROUP BY position')