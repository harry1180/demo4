('SELECT COUNT(1) 
FROM dw_report.dw_page_view_event_f
WHERE view_dw_page_sk = 19006
  AND dw_suspected_bot_in=\'False\'
  AND dw_eff_dt >= trunc(sysdate - 91)')
