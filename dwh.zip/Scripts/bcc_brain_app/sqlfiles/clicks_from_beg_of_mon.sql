('SELECT b.src_prod_id AS credit_card_id,
  a.dw_click_id, a.dw_eff_dt, a.click_utc_ts, a.dw_site_visitor_id, a.src_site_visitor_tx
FROM dw_report.dw_clicks_event_f a
  JOIN dw_report.dw_prod_d b
    ON a.dw_site_prod_sk = b.dw_site_prod_sk
       AND b.curr_in = 1
  JOIN dw_report.dw_page_d c
    ON a.dw_page_sk = c.dw_page_sk
       AND c.curr_in = 1
WHERE a.dw_src_sys_id = 1
      AND a.click_utc_ts >= date_trunc(\'month\', sysdate - 1)
      AND a.dw_suspected_bot_in = \'False\'')
