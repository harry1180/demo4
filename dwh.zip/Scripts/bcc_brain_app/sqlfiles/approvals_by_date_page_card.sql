('SELECT 
  a.dw_eff_dt, a.dw_click_page_sk = \'19006\' as bcc_page, b.src_prod_id as credit_card_id, count(1) as approvals_count
FROM dw_report.dw_aflt_tran_consolidated_f a
  JOIN dw_report.dw_prod_d b
    ON a.dw_site_prod_sk = b.dw_site_prod_sk
      AND b.curr_in = 1
  JOIN dw_report.dw_page_d c
    ON a.dw_click_page_sk = c.dw_page_sk
      AND c.curr_in = 1
WHERE 
  a.tran_click_ts >= trunc(sysdate - 91)
  AND a.revenue_tran_in = \'True\'
GROUP BY a.dw_eff_dt, bcc_page, credit_card_id')