('SELECT b.src_prod_id as credit_card_id, count(1) as external_clicks_count
FROM dw_report.dw_clicks_event_f a
  JOIN dw_report.dw_prod_d b
    ON a.dw_site_prod_sk = b.dw_site_prod_sk
      AND b.curr_in = 1
  JOIN dw_report.dw_page_d c
    ON a.dw_page_sk = c.dw_page_sk
      AND c.curr_in = 1
      AND c.page_path_tx <> \'the-best-credit-cards\'
WHERE a.dw_src_sys_id = 1
  AND a.dw_eff_dt >= date_trunc(\'month\', sysdate - 1)
  --AND a.dw_eff_dt <= trunc(sysdate - 1)
  AND a.dw_suspected_bot_in = \'False\'
GROUP by b.src_prod_id')

