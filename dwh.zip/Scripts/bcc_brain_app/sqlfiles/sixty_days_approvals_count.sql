('SELECT b.src_prod_id AS credit_card_id, count(1) AS approvals_count
FROM dw_report.dw_aflt_tran_consolidated_f a
  JOIN dw_report.dw_prod_d b
    ON a.dw_site_prod_sk = b.dw_site_prod_sk
       AND b.curr_in = 1
  JOIN dw_report.dw_page_d c
    ON a.dw_click_page_sk = c.dw_page_sk
       AND c.curr_in = 1
WHERE a.src_sys_id = 1
  AND a.revenue_tran_in = \'True\'
  AND a.dw_eff_dt >= trunc(sysdate - 61)
  --AND a.dw_eff_dt <= trunc(sysdate - 1)
GROUP BY b.src_prod_id')




