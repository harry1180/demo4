('SELECT a.tran_post_dt, a.tran_click_dt, b.src_prod_id AS credit_card_id, a.dw_eff_dt, a.commission_am
FROM dw_report.dw_aflt_tran_consolidated_f a
  JOIN dw_report.dw_prod_d b
    ON a.dw_site_prod_sk = b.dw_site_prod_sk
       AND b.curr_in = 1
  JOIN dw_report.dw_page_d c
    ON a.dw_click_page_sk = c.dw_page_sk
       AND c.curr_in = 1
       AND c.page_path_tx = \'the-best-credit-cards\'
WHERE a.src_sys_id = 1
      AND a.dw_eff_dt >= trunc(sysdate - 61)
      AND a.dw_eff_dt <= trunc(sysdate - 1)
      AND a.revenue_tran_in = \'True\'')
