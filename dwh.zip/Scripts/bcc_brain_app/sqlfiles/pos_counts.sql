('SELECT floor(((position_on_page-1)/3))+1 AS position, count(1)
FROM dw_report.dw_clicks_event_f
WHERE dw_suspected_bot_in = \'False\'
  AND dw_page_sk = 19006
  AND dw_eff_dt >= trunc(sysdate - 91)
GROUP BY position')
