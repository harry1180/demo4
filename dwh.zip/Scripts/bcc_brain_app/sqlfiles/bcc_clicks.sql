('SELECT dw_eff_dt, brain_success_in , count(1)
FROM  dw_report.dw_clicks_event_f 
WHERE dw_page_sk=19006
  AND dw_suspected_bot_in=\'False\'
  AND dw_eff_dt >= \'2015-06-01\'
GROUP BY dw_eff_dt, brain_success_in')
