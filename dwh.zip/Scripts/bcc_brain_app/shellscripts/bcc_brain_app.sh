

job_name='bcc_brain_app'



job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
input_date=input_date="$(date +'%Y%m%d%H%M%S')"
S3_BUCKET_NM=${Events_dwh_bucket}
echo 'input_date                 :-   '${input_date}
echo 'S3_BUCKET_NM               :-   '${S3_BUCKET_NM}
echo '+----------+----------+----------+----------+----------+----------+'


bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Deleting old files" "Started"
find ${Linux_Input}  -name sixty_days_clicks_count.txt  -exec rm {} \;|| true
find ${Linux_Input} -name sixty_days_approvals_count.txt -exec rm {} \; || true
#find ${Linux_Input} -name approval_transactions.txt -exec rm {} \; || true
find ${Linux_Input} -name external_clicks_count.txt  -exec rm {} \;|| true
find ${Linux_Input} -name clicks_count.txt -exec rm {} \; || true
find ${Linux_Input} -name approvals_count.txt  -exec rm {} \;|| true
find ${Linux_Input} -name best_credit_cards.txt   -exec rm {} \;|| true
find ${Linux_Input} -name approval_transactions_from_beg_mon.txt   -exec rm {} \;|| true
find ${Linux_Input} -name clicks_from_beg_of_mon.txt   -exec rm {} \;|| true
find ${Linux_Input} -name approval_estimates.txt -exec rm {} \; || true
find ${Linux_Input} -name total_pvs.txt -exec rm {} \; || true
find ${Linux_Input} -name pos_counts.txt -exec rm {} \; || true
find ${Linux_Input} -name ext_pvs.txt -exec rm {} \; || true
find ${Linux_Input} -name ext_clicks.txt -exec rm {} \; || true
find ${Linux_Input} -name bcc_pvs.txt -exec rm {} \; || true
find ${Linux_Input} -name bcc_clicks.txt -exec rm {} \; || true
find ${Linux_Input} -name clicks_by_card.txt -exec rm {} \; || true
find ${Linux_Input} -name impressions_by_card.txt -exec rm {} \; || true
find ${Linux_Input} -name impressions_by_position.txt -exec rm {} \; || true
find ${Linux_Input} -name approvals_by_date_page_card.txt -exec rm {} \; || true

echo_processing_step ${job_name} "Deleting old files" "Completed"

echo_processing_step ${job_name} "unloading_data_for sixty days clicks count" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/sixty_days_clicks_count.sql /${S3_Events_Input} unload_sixty_days_clicks_count_
echo_processing_step ${job_name} "unloading_data_for sixty days clicks count" "Completed"

echo_processing_step ${job_name} "unloading_data_for sixty days approvals count" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/sixty_days_approvals_count.sql /${S3_Events_Input} unload_sixty_days_approvals_count_
echo_processing_step ${job_name} "unloading_data_for sixty days approvals count" "Completed"

#echo_processing_step ${job_name} "unloading_data_for approval transactions" "Started"
#bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/approval_transactions.sql /${S3_Events_Input} unload_approval_transactions_
#echo_processing_step ${job_name} "unloading_data_for approval transactions" "Completed"

echo_processing_step ${job_name} "unloading_data_for External Clicks" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/external_clicks_count.sql /${S3_Events_Input} unload_external_clicks_count_
echo_processing_step ${job_name} "unloading_data_for External Clicks" "Completed"

echo_processing_step ${job_name} "unloading_data_for Clicks" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_count.sql /${S3_Events_Input} unload_clicks_count_
echo_processing_step ${job_name} "unloading_data_for Clicks" "Completed"

echo_processing_step ${job_name} "unloading_data_for approvals Clicks" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/approvals_count.sql /${S3_Events_Input} unload_approvals_count_
echo_processing_step ${job_name} "unloading_data_for approvals Clicks" "Completed"

echo_processing_step ${job_name} "unloading_data_for approval_transactions_from_beg_month" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/approval_transactions_from_beg_mon.sql /${S3_Events_Input} unload_approval_transactions_from_beg_mon_
echo_processing_step ${job_name} "unloading_data_for approval_transactions_from_beg_month" "Completed"

echo_processing_step ${job_name} "unloading_data_for clicks_from_beg_of_month" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_from_beg_of_mon.sql /${S3_Events_Input} unload_clicks_from_beg_of_mon_
echo_processing_step ${job_name} "unloading_data_for clicks_from_beg_of_month" "Completed"

echo_processing_step ${job_name} "unloading_data_for best_credit_cards" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/best_credit_cards.sql /${S3_Events_Input} unload_best_credit_cards_
echo_processing_step ${job_name} "unloading_data_for best_credit_cards" "Completed"

echo_processing_step ${job_name} "unloading_data_for total_pvs" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/total_pvs.sql /${S3_Events_Input} unload_total_pvs_
echo_processing_step ${job_name} "unloading_data_for total_pvs" "Completed"

echo_processing_step ${job_name} "unloading_data_for pos_counts" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/pos_counts.sql /${S3_Events_Input} unload_pos_counts_
echo_processing_step ${job_name} "unloading_data_for pos_counts" "Completed"

echo_processing_step ${job_name} "unloading_data_for best_credit_cards" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/ext_pvs.sql /${S3_Events_Input} unload_ext_pvs_
echo_processing_step ${job_name} "unloading_data_for best_credit_cards" "Completed"

echo_processing_step ${job_name} "unloading_data_for ext_pvs" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/ext_clicks.sql /${S3_Events_Input} unload_ext_clicks_
echo_processing_step ${job_name} "unloading_data_for ext_pvs" "Completed"

echo_processing_step ${job_name} "unloading_data_for bcc_pvs" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/bcc_pvs.sql /${S3_Events_Input} unload_bcc_pvs_
echo_processing_step ${job_name} "unloading_data_for bcc_pvs" "Completed"

echo_processing_step ${job_name} "unloading_data_for bcc_clicks" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/bcc_clicks.sql /${S3_Events_Input} unload_bcc_clicks_
echo_processing_step ${job_name} "unloading_data_for bcc_clicks" "Completed"

echo_processing_step ${job_name} "unloading_data_for clicks_by_card" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/clicks_by_card.sql /${S3_Events_Input} unload_clicks_by_card_
echo_processing_step ${job_name} "unloading_data_for clicks_by_card" "Completed"


echo_processing_step ${job_name} "unloading_data_for impressions_by_card" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/impressions_by_card.sql /${S3_Events_Input} unload_impressions_by_card_
echo_processing_step ${job_name} "unloading_data_for impressions_by_card" "Completed"


echo_processing_step ${job_name} "unloading_data_for impressions_by_position" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/impressions_by_position.sql /${S3_Events_Input} unload_impressions_by_position_
echo_processing_step ${job_name} "unloading_data_for impressions_by_position" "Completed"

echo_processing_step ${job_name} "unloading_data_for approvals_by_date_page_card" "Started"
bash ${dwh_common_base_dir}/redshift_unload_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/approvals_by_date_page_card.sql /${S3_Events_Input} unload_approvals_by_date_page_card_
echo_processing_step ${job_name} "unloading_data_for approvals_by_date_page_card" "Completed"

echo_processing_step ${job_name} "Moving the downloaded files to local" "Started"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_sixty_days_clicks_count_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_sixty_days_approvals_count_000', '${dwh_data_base_dir}', to_file=True)"

#python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_approval_transactions_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_external_clicks_count_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_clicks_count_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_approvals_count_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_approval_transactions_from_beg_mon_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_clicks_from_beg_of_mon_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_best_credit_cards_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_total_pvs_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_pos_counts_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_ext_pvs_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_ext_clicks_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_bcc_pvs_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_bcc_clicks_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_clicks_by_card_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_impressions_by_card_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_impressions_by_position_000', '${dwh_data_base_dir}', to_file=True)"

python -c "from s3_modules import s3_file_download; s3_file_download('${S3_BUCKET_NM}','', '${job_name}/input/unload_approvals_by_date_page_card_000', '${dwh_data_base_dir}', to_file=True)"


python -c "from s3_modules import delete_key; delete_key('${job_name}/input/','${S3_BUCKET_NM}','unload_*')" || true


echo_processing_step ${job_name} "Moving the downloaded files to local" "Completed"

echo_processing_step ${job_name} "Renaming the files" "Started"
mv ${Linux_Input}unload_sixty_days_clicks_count_000 ${Linux_Input}sixty_days_clicks_count.txt
mv ${Linux_Input}unload_sixty_days_approvals_count_000 ${Linux_Input}sixty_days_approvals_count.txt
#mv ${Linux_Input}unload_approval_transactions_000 ${Linux_Input}approval_transactions.txt
mv ${Linux_Input}unload_external_clicks_count_000 ${Linux_Input}external_clicks_count.txt
mv ${Linux_Input}unload_clicks_count_000 ${Linux_Input}clicks_count.txt
mv ${Linux_Input}unload_approvals_count_000 ${Linux_Input}approvals_count.txt
mv ${Linux_Input}unload_approval_transactions_from_beg_mon_000 ${Linux_Input}approval_transactions_from_beg_mon.txt
mv ${Linux_Input}unload_clicks_from_beg_of_mon_000 ${Linux_Input}clicks_from_beg_of_mon.txt
mv ${Linux_Input}unload_best_credit_cards_000 ${Linux_Input}best_credit_cards.txt
mv ${Linux_Input}unload_total_pvs_000 ${Linux_Input}total_pvs.txt
mv ${Linux_Input}unload_pos_counts_000 ${Linux_Input}pos_counts.txt
mv ${Linux_Input}unload_ext_clicks_000 ${Linux_Input}ext_clicks.txt
mv ${Linux_Input}unload_ext_pvs_000 ${Linux_Input}ext_pvs.txt
mv ${Linux_Input}unload_bcc_pvs_000 ${Linux_Input}bcc_pvs.txt
mv ${Linux_Input}unload_bcc_clicks_000 ${Linux_Input}bcc_clicks.txt
mv ${Linux_Input}unload_clicks_by_card_000 ${Linux_Input}clicks_by_card.txt
mv ${Linux_Input}unload_impressions_by_card_000 ${Linux_Input}impressions_by_card.txt
mv ${Linux_Input}unload_impressions_by_position_000 ${Linux_Input}impressions_by_position.txt
mv ${Linux_Input}unload_approvals_by_date_page_card_000 ${Linux_Input}approvals_by_date_page_card.txt

echo_processing_step ${job_name} "Renaming the files" "Completed"

echo_processing_step ${job_name} "Running python script to convert to json" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/bcc_brain_app.py ${Linux_Input}sixty_days_clicks_count.txt ${Linux_Input}sixty_days_approvals_count.txt  ${Linux_Input}external_clicks_count.txt ${Linux_Input}clicks_count.txt ${Linux_Input}approvals_count.txt  ${Linux_Input}best_credit_cards.txt  ${Linux_Input}approval_transactions_from_beg_mon.txt  ${Linux_Input}clicks_from_beg_of_mon.txt   ${Linux_Input}bcc_pvs.txt    ${Linux_Input}ext_pvs.txt    ${Linux_Input}bcc_clicks.txt  ${Linux_Input}ext_clicks.txt  ${Linux_Input}total_pvs.txt   ${Linux_Input}pos_counts.txt  ${Linux_Input}clicks_by_card.txt ${Linux_Input}impressions_by_card.txt  ${Linux_Input}impressions_by_position.txt ${Linux_Input}approvals_by_date_page_card.txt


echo_processing_step ${job_name} "Running python script to convert to json" "Completed"


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
