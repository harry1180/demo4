'''
Created on Dec 3, 2017
@author: ramkarunanidhi
'''
import os
import shutil
import sys

from datetime import datetime

from redshift_modules import exec_query
from s3_email_process import email_attachment_extract
from s3_modules import mv_to_s3


LENDER_SQL = """
Select lender,lender_dwnld_wildcard
from dw_report.ctl_dw_aflt_tran_growth_f
where vertical='pl' and lender_dwnld_wildcard is not null
"""

JOB_NAME = 'aflt_tran_preprocess_personal_loans'

LOCAL_BASE_DATA_DIR = sys.argv[2]
LOCAL_INPUT_DIR = os.path.join(LOCAL_BASE_DATA_DIR, JOB_NAME, 'input')
LOCAL_OUTPUT_DIR = os.path.join(LOCAL_BASE_DATA_DIR, JOB_NAME, 'output')
print LOCAL_BASE_DATA_DIR
print LOCAL_INPUT_DIR
print LOCAL_OUTPUT_DIR

S3_DESTINATION = sys.argv[1]
S3_AIRDROP_BUCKET = 'east1-prod-aflt-airdrop-0'
S3_AIRDROP_FOLDER = 'PersonalLoansRawEmail'
S3_AIRDROP_ARCHIVE = 'Archive'


def get_new_filename(filename, lender_map):
    new_filename = None
    for wildcard, lender in lender_map.iteritems():
        if filename.startswith(wildcard):
            if wildcard.lower() != lender.lower():
                new_filename = filename.replace(wildcard, lender + '_' + wildcard)
                # manually append date to lightstream file to avoid overwriting raw file
                if lender.lower() == 'lightstream':
                    new_filename = filename.replace(wildcard, '{}_{}_{}'.format(lender, wildcard, datetime.strftime(datetime.now(), '%Y-%m-%d')))
                break
            else:
                new_filename = filename
                break
    return new_filename


def main():
    """
    This is the main pre-processing script for PL Aft Tran that downloads email attachments from
    pl.raw.airdrop@nerdwallet.awsapps.com (S3: s3://east1-prod-aflt-airdrop-0/PersonalLoansRawEmail) and renames
    the files to include the proper lender name. These renamed files are then uploaded to S3 for subsequent lender
    transformer job to clean and load.
    """

    # Create subfolder for file renaming purposes
    local_rename_dir = '{}/rename'.format(LOCAL_OUTPUT_DIR)
    if not os.path.isdir(local_rename_dir):
        os.mkdir(local_rename_dir)

    # download email attachments from airdrop bucket
    email_attachment_extract(S3_AIRDROP_BUCKET, S3_AIRDROP_FOLDER, S3_AIRDROP_ARCHIVE, LOCAL_INPUT_DIR, LOCAL_OUTPUT_DIR)

    # Pull down lender wildcard info from control table
    lender_list = {lender['lender_dwnld_wildcard']: lender['lender'] for lender in exec_query(LENDER_SQL)}

    # rename downloaded email files based on above wildcard lookups
    for filename in os.listdir(LOCAL_OUTPUT_DIR):
        new_filename = get_new_filename(filename, lender_list)
        if not new_filename:
            continue
        # copy files to "rename" folder so that we can rename files and then move to final s3 destination
        filepath = os.path.join(LOCAL_OUTPUT_DIR, filename)
        new_filepath = os.path.join(local_rename_dir, new_filename)
        print('Copying and renaming {} --> {}'.format(filepath, new_filepath))
        shutil.copy(filepath, local_rename_dir)
        os.rename(os.path.join(local_rename_dir, filename), new_filepath)

        mv_to_s3(new_filepath, S3_DESTINATION)


if __name__ == '__main__':
    main()

