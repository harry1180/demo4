job_name='aflt_tran_preprocess_personal_loans'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
source /etc/passwords.ctrl
#source pas.ctrl
#source /home/akhajekar/passwords.ctrl
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}
echo '+----------+----------+---Custom Variables--+----------+----------+'
ftp_remote_dir="/"
ftp_local_dir=$Linux_Output
raw_file_s3_dest="aflt_tran_process_personal_loans/input"
echo '+----------+----------+----------+----------+----------+----------+'
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning S3 and data directories:" "Started"
find $Linux_Input $Linux_Output $Linux_Archive -type f -exec rm {} \; || true
echo_processing_step ${job_name} "Cleaning S3 and data directories:" "Completed"

echo_processing_step ${job_name} "Download files from FTP - Goldman Sachs" "Started"
python -c "from downloadsftp import connect,download_file; download_file(connect('$marcus_sftpURL', '$marcus_sftpUser', '$marcus_sftpPassword'), '$ftp_remote_dir', '$Linux_Output', '$Events_dwh_bucket', '$raw_file_s3_dest', decrypt='Yes', output_format='csv', output_nm=['marcus', 'goldmansachs'])" || true
echo_processing_step ${job_name} "Download files from FTP - Goldman Sachs" "Completed"

echo_processing_step ${job_name} "Download files from FTP - LendingClub" "Started"
lendingclub_sftp_url="files.lendingclub.com"
echo $lendingclub_sftp_url
python -c "from downloadsftp import connect,download_file; download_file(connect('$lendingclub_sftp_url', '$lendingclub_sftp_username', '$lendingclub_sftp_password'), '$ftp_remote_dir', '$Linux_Output', '$Events_dwh_bucket', '$raw_file_s3_dest', decrypt='Yes', output_format='csv')" || true
echo_processing_step ${job_name} "Download files from FTP - LendingClub" "Completed"

echo_processing_step ${job_name} "Download the email attachments" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/aflt_tran_preprocess_personal_loans.py $raw_file_s3_dest $dwh_data_base_dir
echo_processing_step ${job_name} "Download the email attachments" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
