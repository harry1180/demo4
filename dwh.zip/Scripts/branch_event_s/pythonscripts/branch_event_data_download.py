import sys
from branch_api_download  import get_branch_data

key=sys.argv[1]
skey=sys.argv[2]
report_to_download_date=sys.argv[3]
file_path=sys.argv[4]
dim=sys.argv[5]
job_name=sys.argv[6]
source_bucket=sys.argv[7]
json_file=sys.argv[8]
extra_json_file=sys.argv[9]


url='https://api.branch.io/v2/export/'

#column header in the downloaded csv file.
field_name_list='id,name,metadata,timestamp,branch_identity_id,developer_identity,identity_creation_timestamp,branch_session_id,app_version,ip_address,session_start_timestamp,branch_device_fingerprint_id,device_first_seen_timestamp,device_os,device_os_version,device_metadata,hardware_id,google_advertising_id,branch_browser_fingerprint_id,browser_first_seen_timestamp,browser_os,browser_os_version,user_agent,first_referring_click_timestamp,first_referring_click_query_params,first_referring_branch_identity_id,first_referring_developer_identity,first_referring_hardware_id,first_referring_branch_link_id,first_referring_link_creation_timestamp,first_referring_link_channel,first_referring_link_feature,first_referring_link_campaign,first_referring_link_stage,first_referring_link_tags,first_referring_link_data,first_referring_link_creation_source,first_referring_link_url,session_referring_click_timestamp,session_referring_click_query_params,session_referring_branch_identity_id,session_referring_developer_identity,session_referring_hardware_id,session_referring_branch_link_id,session_referring_link_creation_timestamp,session_referring_link_channel,session_referring_link_feature,session_referring_link_campaign,session_referring_link_stage,session_referring_link_tags,session_referring_link_data,session_referring_link_creation_source,session_referring_link_url,first_referring_click_id,session_referring_click_id'


# defining various dictionary for different json objects.
json_dict={      
             'device_metadata':{'ad_tracking_enabled':'device_ad_tracking_enabled', 'brand':'brand_name', 'google_advertising_id':'device_google_advertising_id', 'hardware_id_type':'device_hardware_id_type', 'ios_vendor_id':'device_ios_vendor_id', 'ip':'device_ip', 'lat_val':'device_lat_val', 'local_ip':'device_local_ip', 'model':'device_model', 'os_version':'device_os_version_nr', 'os':'device_os_nm', 'screen_dpi':'device_screen_dpi', 'screen_height':'device_screen_height', 'screen_width':'device_screen_width', 'user_agent':'device_user_agent', 'wifi':'device_wifi'}
           , 'session_referring_link_data':{'+click_timestamp': 'session_rfr_link_click_timestamp', '+phone_number': 'session_rfr_link_phone_number', '+referrer': 'session_rfr_link_referrer', '+url': 'session_rfr_link_url', '~campaign': 'session_rfr_link_campaign', '~channel': 'session_rfr_link_channel', '~creation_source': 'session_rfr_link_creation_source', '~feature': 'session_rfr_link_feature', '~id': 'session_rfr_link_id', '~marketing': 'session_rfr_link_marketing', '~tags': 'session_rfr_link_tags', '$marketing_title': 'session_rfr_link_marketing_title', '$og_description': 'session_rfr_link_og_description', '$og_title': 'session_rfr_link_og_title', '$one_time_use': 'session_rfr_link_one_time_use', 'test-key': 'session_rfr_link_test_key','gclid':'session_rfr_link_gclid','referrer':'session_rfr_link_referrer_tx','_t':'session_rfr_link_referrer_t','_branch_match_id':'session_rfr_link_referrer_branch_match_id','$og_video':'session_rfr_link_referrer_og_video','$og_image_url':'session_rfr_link_referrer_og_image_url','$canonical_url':'session_rfr_link_referrer_canonical_url'}
           , 'first_referring_link_data':{'_branch_match_id': 'first_rfr_link_branch_match_id','_t': 'first_rfr_link_t','+click_timestamp': 'first_rfr_link_click_timestamp','+phone_number': 'first_rfr_link_phone_number','+referrer': 'first_rfr_link_referrer','+url': 'first_rfr_link_url','~campaign': 'first_rfr_link_campaign','~channel': 'vchannel','~creation_source': 'first_rfr_link_creation_source','~feature': 'first_rfr_link_feature','~id': 'first_rfr_link_id','~marketing': 'first_rfr_link_marketing','~tags': 'first_rfr_link_tags','$canonical_url': 'first_rfr_link_canonical_url','$marketing_title': 'first_rfr_link_marketing_title','$og_description': 'first_rfr_link_og_description','$og_image_url': 'first_rfr_link_og_image_url','$og_title': 'first_rfr_link_og_title','$og_video': 'first_rfr_link_og_video','$one_time_use': 'first_rfr_link_one_time_use','gclid': 'first_rfr_link_gclid','referrer': 'first_rfr_link_referrer_tx','test-key' : 'first_rfr_link_test_key','test':'first_rfr_link_test','$identity_id':'first_rfr_link_identity_id'}
           , 'session_referring_click_query_param':{'referrer':'session_rfr_click_query_param_referrer','gclid':'session_rfr_click_query_param_gclid'}
           , 'metadata':{'ip': 'metadata_ip','language': 'metadata_language','referred': 'metadata_referred','reinstall': 'metadata_reinstall','url': 'metadata_url','user_agent' : 'metadata_user_agent'}
          }


final_url=url+key+'?branch_secret='+skey+'&export_date='+report_to_download_date

print "Call function to download the data"
if get_branch_data (final_url,file_path,dim, json_dict,field_name_list,job_name,source_bucket,json_file,extra_json_file)== -1 :
   print "Error in processing. Existing"
   sys.exit(1)
else :
   print 'processing completed successfully for %s '   %report_to_download_date 
