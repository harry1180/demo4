#!/bin/bash

job_name='all_events_s_nerdlake'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
if [ -d "$Linux_Temp" ] && [ "$Linux_Temp" != "/tmp" ]
then
    echo_processing_step ${job_name} "Removing Temporary Files" "Started"
    find $Linux_Temp -type f -exec rm {} \; || true
    echo_processing_step ${job_name} "Removing Temporary Files" "Completed"
fi

# Missing in NerdLake:
# "BrowserTimingEvent",
# "CCElementImpressionEvent",
# "DeactivateCreditProfileEvent",
# "InvestingClickEvent",
# "ShoppingClickEvent",

echo_processing_step ${job_name} "Calling Composite Script" "Started"
python $dwh_common_base_dir/nerdlake_composite_table.py \
    --composite-table dwnl_stage.all_events_s \
    --base-field event_name \
    --base-table dwnl_stage.ActivateCreditProfileEvent_s,ACTIVATE_CREDIT_PROFILE_EVENT \
    --base-table dwnl_stage.ActivationEvent_s,ACTIVATION_EVENT \
    --base-table dwnl_stage.AppsFlyerWebhookEvent_s,APPSFLYER_WEBHOOK_EVENT \
    --base-table dwnl_stage.BankingRateImpressionEvent_s,BANKING_RATE_IMPRESSION_EVENT \
    --base-table dwnl_stage.BrokersClickEvent_s,BROKERS_CLICK_EVENT \
    --base-table dwnl_stage.BrokersImpressionEvent_s,BROKERS_IMPRESSION_EVENT \
    --base-table dwnl_stage.CCClickEvent_s,CC_CLICK_EVENT \
    --base-table dwnl_stage.CCElementImpressionEvent_s,CC_ELEMENT_IMPRESSION_EVENT \
    --base-table dwnl_stage.CCElementInteractionEvent_s,CC_ELEMENT_INTERACTION_EVENT \
    --base-table dwnl_stage.CCImpressionEvent_s,CC_IMPRESSION_EVENT \
    --base-table dwnl_stage.CreditScoreClickEvent_s,CREDIT_SCORE_CLICK_EVENT \
    --base-table dwnl_stage.DeactivateIdentityEvent_s,DEACTIVATE_IDENTITY_EVENT \
    --base-table dwnl_stage.DeactivationEvent_s,DEACTIVATION_EVENT \
    --base-table dwnl_stage.EDULoansPrequalOfferEvent_s,EDU_LOANS_PREQUAL_OFFER_EVENT \
    --base-table dwnl_stage.ElementImpressionEvent_s,ELEMENT_IMPRESSION_EVENT \
    --base-table dwnl_stage.ElementInteractionEvent_s,ELEMENT_INTERACTION_EVENT \
    --base-table dwnl_stage.EmailBounceEvent_s,EMAIL_BOUNCE_EVENT \
    --base-table dwnl_stage.EmailClickEvent_s,EMAIL_CLICK_EVENT \
    --base-table dwnl_stage.EmailOpenEvent_s,EMAIL_OPEN_EVENT \
    --base-table dwnl_stage.EmailSendEvent_s,EMAIL_SEND_EVENT \
    --base-table dwnl_stage.ExperimentExposureEvent_s,EXPERIMENT_EXPOSURE_EVENT \
    --base-table dwnl_stage.FeedItemChangedEvent_s,FEED_ITEM_CHANGED_EVENT \
    --base-table dwnl_stage.FeedElementImpressionEvent_s,FEED_ELEMENT_IMPRESSION_EVENT \
    --base-table dwnl_stage.FeedElementInteractionEvent_s,FEED_ELEMENT_INTERACTION_EVENT \
    --base-table dwnl_stage.FormInputChangedEvent_s,FORM_INPUT_CHANGED_EVENT \
    --base-table dwnl_stage.GenericClickEvent_s,GENERIC_CLICK_EVENT \
    --base-table dwnl_stage.GenericImpressionEvent_s,GENERIC_IMPRESSION_EVENT \
    --base-table dwnl_stage.HeartbeatEvent_s,HEARTBEAT_EVENT \
    --base-table dwnl_stage.InsuranceClickEvent_s,INSURANCE_CLICK_EVENT \
    --base-table dwnl_stage.InsuranceImpressionEvent_s,INSURANCE_IMPRESSION_EVENT \
    --base-table dwnl_stage.InsuranceProductClickEvent_s,INSURANCE_PRODUCT_CLICK_EVENT \
    --base-table dwnl_stage.JoinEvent_s,JOIN_EVENT \
    --base-table dwnl_stage.LoginIdentityEvent_s,LOGIN_IDENTITY_EVENT \
    --base-table dwnl_stage.LogoutIdentityEvent_s,LOGOUT_IDENTITY_EVENT \
    --base-table dwnl_stage.MortgageLenderClickEvent_s,MORTGAGE_LENDER_CLICK_EVENT \
    --base-table dwnl_stage.MortgageLenderImpressionEvent_s,MORTGAGE_LENDER_IMPRESSION_EVENT \
    --base-table dwnl_stage.MortgageLenderQuoteEvent_s,MORTGAGE_LENDER_QUOTE_EVENT \
    --base-table dwnl_stage.OptimizelyExperimentsEvent_s,OPTIMIZELY_EXPERIMENTS_EVENT \
    --base-table dwnl_stage.PageViewEvent_s,PAGE_VIEW_EVENT \
    --base-table dwnl_stage.PasswordResetIdentityEvent_s,PASSWORD_RESET_IDENTITY_EVENT \
    --base-table dwnl_stage.PersonalLoansClickEvent_s,PERSONAL_LOANS_CLICK_EVENT \
    --base-table dwnl_stage.PersonalLoansImpressionEvent_s,PERSONAL_LOANS_IMPRESSION_EVENT \
    --base-table dwnl_stage.PersonalLoansPrequalOfferEvent_s,PERSONAL_LOANS_PREQUAL_OFFER_EVENT \
    --base-table dwnl_stage.PrepaidClickEvent_s,PREPAID_CLICK_EVENT \
    --base-table dwnl_stage.ProductInteractionEvent_s,PRODUCT_INTERACTION_EVENT \
    --base-table dwnl_stage.PushSendEvent_s,PUSH_SEND_EVENT \
    --base-table dwnl_stage.RateClickEvent_s,RATE_CLICK_EVENT \
    --base-table dwnl_stage.RegisterIdentityEvent_s,REGISTER_IDENTITY_EVENT \
    --base-table dwnl_stage.RoleChangeEvent_s,ROLE_CHANGE_EVENT \
    --base-table dwnl_stage.SMBClickEvent_s,SMB_CLICK_EVENT \
    --base-table dwnl_stage.SMBImpressionEvent_s,SMB_IMPRESSION_EVENT \
    --base-table dwnl_stage.SMBPrequalOfferEvent_s,SMB_PREQUAL_OFFER_EVENT \
    --base-table dwnl_stage.TaxesClickEvent_s,TAXES_CLICK_EVENT \
    --base-table dwnl_stage.BackendNWUserDataExportEvent_s,NW_USER_DATA_EXPORT_BACKEND \
    --base-table dwnl_stage.ProviderAccountStateChangeEvent_s,PROVIDER_ACCOUNT_STATE_CHANGE_EVENT

echo_processing_step ${job_name} "Calling Composite Script" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
