'''
Created on Oct 12, 2016

@author: [apillai]
The lender filename must be of the format lendername_vertical_date.ext
'''
import json
import os
import sys
import traceback

from email_module import send_email
from excelutils import excel2json
from s3_modules import s3_file_upload
from tran_log_modules import insert_log
from redshift_modules import exec_query
from lender_transformer.lender_transformation import transform_to_excel

def get_lenders(vertical):
    query = "Select lender from dw_report.ctl_dw_aflt_tran_growth_f where vertical='{0}' group by 1".format(vertical) 
    lenders = exec_query(query, user='superuser')
    return [lender['lender'] for lender in lenders]

def get_mapping_dict(lendername, s3_folder, s3_bucket):
    return {
	'bondstreet': os.path.join(s3_folder, 'transformation', 'bondstreet_map.xlsx'),
	'credibilitycapital': os.path.join(s3_folder, 'transformation', 'credibilitycapital_map.xlsx'),
	'fundbox': os.path.join(s3_folder, 'transformation', 'fundbox_map.xlsx'),
	'streetshares': os.path.join(s3_folder, 'transformation', 'streetshares_map.xlsx'),
	'smartbiz': os.path.join(s3_folder, 'transformation', 'smartbiz_map.xlsx'),
	'lendingclub': os.path.join(s3_folder, 'transformation', 'lendingclub_map.xlsx'),
	'kabbage': os.path.join(s3_folder, 'transformation', 'kabbage_map.xlsx'),
	'ondeck': os.path.join(s3_folder, 'transformation', 'ondeck_map.xlsx'),
        'bluevine': os.path.join(s3_folder, 'transformation', 'bluevine_map.xlsx'),
        'ablelending': os.path.join(s3_folder, 'transformation', 'ablelending_map.xlsx'),
        'fundingcircle': os.path.join(s3_folder, 'transformation', 'fundingcircle_map.xlsx')}.get(lendername)

def get_mapping_file(lendername, s3_folder, s3_bucket):
    try:
        mapping_file = get_mapping_dict(lendername, s3_folder, s3_bucket)
    except:
        raise MappingFileError("Error while #trying to find mapping doc for lender: " + lendername)
    return mapping_file

def init_email(email_template):
    with open(email_template) as email_file:
        email_info = json.loads(email_file.read().replace('\n', ' ').replace('\r', ' '), strict=False)
    return email_info



def main(input_src, s3_bucket, s3_folder, email_template):
    """
    Main python script to convert Personal Loan raw Excel files to JSON files. Given a raw file path or
    path to directory containing raw files, each file will be logged to the transaction log table,
    converted from xlsx to json, and moved to S3.

    :param input_src: str, Input file path or directory path. All files will be processed if directory.
    :param s3_bucket: str, S3 bucket to store files
    :param s3_folder: str, S3 folder to store files
    :param email_template: str, file path to JSON email template
    """

    aflt_tran_id = 36 
    file_list = []
    # Generate list of files to process from input source
    if os.path.isfile(input_src):
        file_list = [input_src]
    elif os.path.isdir(input_src):
        file_list = [os.path.join(input_src, f) for f in os.listdir(input_src) if os.path.isfile(os.path.join(input_src, f))]
    else:
        print("No input files to process!")
	
     
    for input_file in file_list:
    	try:
            print('Generating output and input file names Started')
            print('Input File: {}'.format(input_file))

  	    outfile_dir = os.path.dirname(input_file)
	    print("outfile_dir:  {} ".format(outfile_dir))
            input_filepath = os.path.splitext(os.path.basename(input_file))[0]
	    print("input_filepath: {}".format(input_filepath))
	    input_filename = input_filepath.split('/')[-1]
	    print("input_filenamei: {}".format(input_filename))

            output_json_file = os.path.join(outfile_dir, '{name}.{ext}'.format(name=input_filepath, ext='json'))
            output_transformed_file = os.path.join(outfile_dir, '{name}_{transformed}.{ext}'.format(name=input_filename, transformed='Transformed',ext='xlsx')) 
            print('Output Json File: {}'.format(output_json_file))
            print('Output Transformed File {}'.format(output_transformed_file))
	    
	    lender, vertical, file_received_dt = input_filename.split('_')
	    lender, vertical = lender.lower(), vertical.lower()
            
	    if (vertical != 'smb') or (lender not in get_lenders(vertical)): 	
		raise Exception("The vertical is not smb / Lender is not part of the cntrol table/ Improper file name lender_vertical_date.ext") 
	   
	    print("file_received_dt {}".format(file_received_dt))
            print('Generating output and input file names Completed')

	    lender_map_path = get_mapping_file(lender, s3_folder, s3_bucket)
	   

            print("Running python script to transform excel Started")
            err_transformation = transform_to_excel(input_file, output_transformed_file, lender_map_path, s3_bucket, lender, file_received_dt, vertical)
	    print("Running python script to transform excel Completed")

            print('Running python script to convert csv to json Started')
            #excel2json(input_file, output_json_file, ignoreheadercase=True)
            excel2json(output_transformed_file, output_json_file, ignoreheadercase=True, new_map=True)
            print('Running python script to convert csv to json Completed')
            
	    print('Moving the JSON File to S3 Started')
            dest_s3_folder = os.path.join(s3_folder, 'output', lender)
            s3_file_upload(output_json_file, s3_bucket, dest_s3_folder)
            print('Moving the JSON File to S3 Completed')

	    # Move both raw as well as transformed files -- to be done 
            print('Moving the Raw file to S3 Started')
            raw_s3_folder = s3_folder + "/input/raw"
            s3_file_upload(input_file, s3_bucket, raw_s3_folder)
            print('Moving the Raw file to S3 Completed')
	    
            # Moving transformed file to s3 
            print('Moving the Transformed file to S3 Started')
            transformed_s3_folder = s3_folder + "/input/transformed"
            s3_file_upload(output_transformed_file, s3_bucket, transformed_s3_folder)
            print('Moving the Raw file to S3 Completed')
		
	    insert_log(aflt_tran_id, output_transformed_file, lender)	    
	    if err_transformation:
	        raise Exception("\n".join(err_transformation))	
	    

        except Exception, e:
	    email_info = init_email(email_template) 
            print('Exception: {}'.format(e))
            print('Failure processing file {}! An email will be sent out to the concerned party.'.format(input_file))
            email_info['subject'] = email_info['subject'] + ' for file ' + input_file
            email_info['body'] = email_info['body'] + str(e) + ' ' + str(traceback.format_exc())
            email_info['attachment'] = email_info['attachment'] + input_file
            send_email(email_info)
	    continue


if __name__ == '__main__':

    # Get the command line variables
    input_src = sys.argv[1]
    s3_bucket_name = sys.argv[2]
    s3_folder_name = sys.argv[3]
    email_json_template = sys.argv[4]

    # Execute main function
    main(input_src, s3_bucket_name, s3_folder_name, email_json_template)
