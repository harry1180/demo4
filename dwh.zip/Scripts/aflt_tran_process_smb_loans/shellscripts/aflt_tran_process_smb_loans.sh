job_name='aflt_tran_process_smb_loans'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
to_date=`(date +'%Y%m%d')`
s3bucketFolder="aflt_tran_process_smb_loans"
EmailBucket="east1-prod-aflt-airdrop-0"
EmailPath="SmbLoansEmail"
ArchivePath="Archive"
output_path=$Linux_Input
ProcessedEmailPath=$Linux_Output

echo 'EmailBucket                    :-   '${EmailBucket}
echo 'Events_dwh_bucket              :-   '${Events_dwh_bucket}
echo 's3bucketFolder                 :-   '${s3bucketFolder}
echo 'EmailPath                      :-   '${EmailPath}
echo 'ArchivePath                    :-   '${ArchivePath}
echo 'File_Search                    :-   '${File_Search}
echo 'output_path                    :-   '${output_path}
echo 'ProcessedEmailPath             :-   '${ProcessedEmailPath}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning S3 and data direcotried:" "Started"
rm -f ${Linux_Output}* || true
rm -f ${Linux_Input}*  || true
echo_processing_step ${job_name} "Cleaning S3 and data direcotries:" "Completed"

echo_processing_step ${job_name} "Setting up variables for downloading the files locally" "Started"
echo "S3bucket:"$s3_bucketname" S3folder:"$s3bucketFolder" s3ArchivePath:"$s3ArchivePath" Linux_Input:"$Linux_Input
echo_processing_step ${job_name} "Setting up variables for downloading the files locally" "Completed"

echo_processing_step ${job_name} "Running python to Download the email attachments" "Started"
python -c "from s3_email_process import email_attachment_extract; email_attachment_extract('$EmailBucket','$EmailPath','$ArchivePath','$output_path','$ProcessedEmailPath', strict=False)" || true
echo_processing_step ${job_name} "Running python to Download the email attachments" "Completed"

echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Started"
python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/process_raw_to_confirmed_files.py $ProcessedEmailPath $Events_dwh_bucket $s3bucketFolder ${dwh_scripts_base_dir}/${job_name}/pythonscripts/email_info.json "smb" 36 true
echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

