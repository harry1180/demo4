SELECT 
    id
  , description
  , tag_id
  , panic
  , created_at
FROM
  bcc_app.offers
where created_at > DATE_SUB(current_date, INTERVAL 15 DAY)
;

