drop   table  dw_stage.bcc_brain_offers_s ;

CREATE TABLE dw_stage.bcc_brain_offers_s 
(  
id          BIGINT , 
description  varchar(255) , 
tag_id      BIGINT , 
panic       smallint , 
created_at  TIMESTAMP 
--,FOREIGN KEY (id) REFERENCES dw_stage.tags_s(id),

) 
distkey (id) ; 

GRANT ALL  ON dw_stage.bcc_brain_offers_s TO GROUP grp_etl;

