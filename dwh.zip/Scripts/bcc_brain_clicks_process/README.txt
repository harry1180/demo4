The program depends on AWS_ID and AWS_SEC being set before being run. There is
an example script that helps setup the environmental variables too (setCreds.sh)
which is used by source ./setCreds.sh 
