from __future__ import division

import json
import datetime
import optparse
import os
import pdb
import requests
import sys
import time

dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(dir_path)
from data_parser import DataParser
from s3_downloader import S3Downloader


def send_data(json_table, is_test):
    url = 'http://bccservices.nerdwallet.biz/api/v1/items'
    if is_test:
        url = 'http://bccservices.nerdwallet.biz/api/v1/items'
    else:
        url = 'http://bccservices.nerdwallet.com/api/v1/items'
    params = {}
    headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Token token=7af44fdcc9c68c80e949dcf6a3e6f95f'
            }
    response = requests.post(url, json=json_table, headers=headers)
    #if response.status_code != 200:
    #    sys.stderr.write('Error in posting to key value store\n{}'.format(response.reason))
    #    response.raise_for_status()
    if response.ok:
        print json.loads(response.content)
        print 'headers:', headers
        print 'url:', url
    else:
        print response.reason
        print response.status_code
        print json.loads(response.content)
        print json_table
        print 'headers:', headers
        print 'url:', url
    return response     


def main():
    usage = 'usage: %prog [options]'
    parser = optparse.OptionParser(usage=usage)
    parser.add_option('-s', '--start-time', action='store',
            dest='start_time', help='Time after which click counts are to be measured',
            default=0)
    parser.add_option('-o', '--hours', action='store',
            dest='hours', help='Number of hours to look back to',
            default=6)
    parser.add_option('-p', '--path', action='store',
            dest='path', help='path to store intermediatry files in',
            default='/data/etl/Data/bcc_brain_clicks_process/input/')
    parser.add_option('-t', '--test', action='store_true',
            dest='is_test', help='Is this run a test and data should hit stage',
            default=False)
    utc_time = datetime.datetime.utcnow()
    (options, args) = parser.parse_args()
    sd = S3Downloader(path=options.path, utc_time=utc_time)
    sd.download_all()
    dp = DataParser(path=options.path, utc_time=utc_time)
    data = dp.get_data(int(options.start_time))
    sd.cleanup()
    print json.dumps(data, indent=2)
    send_data(data, options.is_test)


if __name__ == '__main__':
    start_time = time.time()
    main()
    end_time = time.time()
    #print('--- {} seconds ---'.format(end_time - start_time))

