from __future__ import division

import collections


class BotDetector:

    def __init__(self, ip_max=20, session_max=20):
        self.pv_by_ip_count = collections.defaultdict(lambda: 0) # store pv seen by an ip
        self.pv_by_session_count = collections.defaultdict(lambda: 0)
        self.pv_cookie_set = set([]) # all cookieIds that have had page views
        self.ip_max = ip_max
        self.session_max = session_max
        return

    def add_pageview(self, pv_entry):
        self.pv_by_session_count[pv_entry['header']['browserSessionId']] += 1 
        self.pv_by_ip_count[pv_entry['header']['ip']] += 1 
        self.pv_cookie_set.add(pv_entry['header']['cookieId'])
        return

    def add_cc_click(self, cc_entry):
        return
    
    def is_bot(self, cc_entry):
        session_id = None
        if 'browserSessionId' in cc_entry['header'].keys():
            session_id = cc_entry['header']['browserSessionId']
        ip = cc_entry['header']['ip']
        cookie = cc_entry['header']['cookieId']
        
        if self.pv_by_ip_count[ip] >= self.ip_max:
            return True
        if session_id is not None and self.pv_by_session_count[session_id] >= self.session_max:
            return True
        if cookie not in self.pv_cookie_set:
            return True
       
        if 'kafka' in cc_entry['header']['url']:
            return True

        user_agent = cc_entry['header']['userAgent']
        bot_strs = ['bot', 'spider', 'crawl']
        if any(bot_str in user_agent for bot_str in bot_strs):
            return True
        return False
