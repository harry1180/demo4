import os
import sys
dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(dir_path + '/protoschemas/')
import inspect
import struct
from google.protobuf.descriptor import FieldDescriptor

# A key value store of schema_class -> module. The purpose of this is so that
# we don't have to recurse down the directory structure under nwpyschemas
# each time. Also, we only cache modules in the "standard" path under nwpyshcemas
module_cache = dict()


def load_class(schema_class):
    """
    Returns the class nwpyschemas.<nw-package>.<schema_class>_pb2.<schema_class>
    @param schema_class should be the name of the protobuf schema class
    Example:
        load_class('PageViewEvent')
    """
    global module_cache
    if schema_class in module_cache:
        return module_cache[schema_class]

    mod_path = "{0}_pb2".format(schema_class)
    module_cache[schema_class] = _load_class(mod_path, schema_class)
    return module_cache[schema_class]


def _load_class(module, klass):
    """
    Given a dotted path to a module and a class in that module, this function is the equivalent of:
        from <module> import <klass>; return <klass>
    """
    schema_mod = __import__(
        module, fromlist=[klass], level=-1
    )
    for n, cls in inspect.getmembers(schema_mod, inspect.isclass):
        if n == klass:
            return cls


def deserialize(pb_class, serialized_pb):
    """
    Deserializes the given protobuf encoded string and returns the corresponding protobuf
    object.

    @param pb_class should be a protobuf class object (NOT instance)
    @param serialized_pb is the protobuf encoded string corresponding to the given schema

    Example:
        pb_class = load_class('PageViewEvent')
        deserialize(pb_class, serialized_pb)
    """
    pb = pb_class()
    pb.ParseFromString(serialized_pb)
    return pb


def is_enum(pb, k):
    """
    Returns True if k is a key in the protobuf object corresponding to an enum type.

    @param pb is a protobuf object
    @param k is a field in the protobuf object schema
    """
    return pb.DESCRIPTOR.fields_by_name[k].enum_type is not None


def enum_string_to_number(pb, k, attr):
    """
    Returns the enum number corresponding to the string attr for the given protobuf object.

    @param pb is a protobuf object
    @param k is a field in the protobuf object schema corresponding to an enum type
    @param attr is the string representation of the enum

    Example:
        enum_string_to_number(pb, 'eventName', 'PAGE_VIEW_EVENT')
    """
    return pb.DESCRIPTOR.fields_by_name[k].enum_type.values_by_name[attr].number


def enum_number_to_string(pb, k, attr):
    """
    Returns the enum string corresponding to the int attr for the given protobuf object.

    @param pb is a protobuf object
    @param k is a field in the protobuf object schema corresponding to an enum type
    @param attr is the number representation of the enum

    Example:
        enum_number_to_string(pb, 'eventName', 1)
    """
    return pb.DESCRIPTOR.fields_by_name[k].enum_type.values_by_number[attr].name


def set_attr(pb, k, attr):
    """
    Sets the attribute in the specified protobuf object

    @param pb is the protobuf object
    @param k is the field
    @param attr is the value to be assigned to the given field
    """
    if is_enum(pb, k):
        setattr(pb, k, enum_string_to_number(pb, k, attr))
    elif isinstance(attr, list):
        getattr(pb, k).extend(attr)
    else:
        setattr(pb, k, attr)


def protobuf_to_dict(pb):
    """
    Takes a protobuf object and transforms it to a Python dictionary. If any fields are protobuf
    objects themselves, they are added as sub-dictionaries. Lists of protobuf objects are returned
    as lists of python dictionaries.

    @param pb is the protobuf object to convert to a Python dictionary
    """
    proto_dict = {}

    for field, value in pb.ListFields():
        if field.label == FieldDescriptor.LABEL_REPEATED:
            pb_list = []
            if field.type == FieldDescriptor.TYPE_MESSAGE:
                # If it's a list of messages, recurse and dictionary each, appending to the list
                for val in value:
                    pb_list.append(protobuf_to_dict(val))
            else:
                # Just save the raw values of primitive-ish types
                for val in value:
                    pb_list.append(val)

            proto_dict[field.name] = pb_list
        elif field.type == FieldDescriptor.TYPE_ENUM:
            proto_dict[field.name] = enum_number_to_string(pb, field.name, value)
        elif field.type == FieldDescriptor.TYPE_MESSAGE:
            proto_dict[field.name] = protobuf_to_dict(value)
        else:
            proto_dict[field.name] = value

    return proto_dict


class BlobParser(object):
    """
    Given a string with the following format:
        s := '' | '<len><serialized_record><s>'
        len := long
        serialized_record := protobuf serialized string
    this class provides a method to parse out all records contained in the string.
    """
    def __init__(self, schema_class, s):
        """
        @param schema_class is a string containing the name of the protobuf schema class
        @param s is the string described above

        Example:
            BlobParser('PageViewEvent', s)
        """
        self.blob = s
        self.pb_class = load_class(schema_class)
        self.offset = 0
        self.blob_len = len(self.blob)

    def __iter__(self):
        return self

    def next(self):
        if self.offset >= self.blob_len:
            raise StopIteration()

        # get record length
        length = struct.unpack(">Q", self.blob[self.offset:8 + self.offset])[0]
        self.offset += 8

        # get record
        record = self.blob[self.offset:length + self.offset]
        if len(record) != length:
            raise IOError('Malformed Protobuf blob')
        self.offset += length

        return deserialize(self.pb_class, record)


class FileParser(object):
    """
    If the string described in BlobParser is too large to fit in memory,
    this class provides the same functionality but reads the string off disk
    given a file name.
    """
    def __init__(self, schema_class, fname):
        """
        @param schema_class is a string containing the full package path to the protobuf
        python class
        @param fname is the name of the file
        """
        self.f = open(fname, 'r')
        self.done = False
        self.pb_class = load_class(schema_class)

    def __iter__(self):
        return self

    def next(self):
        if self.done:
            raise StopIteration()

        # get record length
        length_str = self.f.read(8)
        if length_str == '':
            self.f.close()
            self.done = True
            raise StopIteration()

        # get record
        length = struct.unpack(">Q", length_str)[0]
        record = self.f.read(length)
        if len(record) != length:
            self.f.close()
            raise IOError('Malformed Protobuf file format')

        return deserialize(self.pb_class, record)

def fetch_creds(input_var_name):
    
    import os

    try:
        creds_file_dir=os.environ['dwh_credentials_file_dir']
        creds_file_nm=creds_file_dir+'/credentials.ctrl'

    except:
        print "unable to locate user credentials file. trying to use etl user creds file"
        creds_file_nm='/data/etl/Common/credentials.ctrl' 

    creds = open(creds_file_nm)

    for line in creds:
        if input_var_name in line:
            #print line
            return str(line.split('=')[1].replace('"',""))
