from __future__ import division

import os
import csv
import collections
import datetime
import glob
import sys
import time
import urlparse
import urllib

dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(dir_path)
sys.path.append(dir_path + '/protoschemas')

import bot_detector
import util


PAGE_VIEW_EVENT = 'PageViewEvent'
CC_CLICK_EVENT = 'CCClickEvent'


class DataParser:
    def __init__(self, path='/data/etl/Data/bcc_brain_clicks_process/input/',
            extension='protobuf', utc_time=datetime.datetime.utcnow()):
        self.extension = extension
        self.path = path
        self.bot_detector = bot_detector.BotDetector()
        self.utc_time = utc_time

    def __exit__(self, type, value, traceback):
        return
    def __enter__(self):
        return self

    def train_bot(self, start_time):
        self.train_bot_on_pageviews(start_time)
        self.train_bot_on_ccclicks(start_time)

    def train_bot_on_pageviews(self, start_time):
        directory = self.path + PAGE_VIEW_EVENT.lower() + '/'
        for infile in glob.glob(os.path.join(directory, '*' +
            self.extension)):
            input_file = open(infile, 'rb')
            input_data = input_file.read()
            b_parser = util.BlobParser(PAGE_VIEW_EVENT, input_data)
            for entry in b_parser:
                entry_dict = util.protobuf_to_dict(entry)
                if int(entry_dict['header']['timestamp']) < start_time:
                    continue
                self.bot_detector.add_pageview(entry_dict)

    def train_bot_on_ccclicks(self, start_time):
        directory = self.path + CC_CLICK_EVENT.lower() + '/'
        for infile in glob.glob(os.path.join(directory, '*' +
            self.extension)):
            input_file = open(infile, 'rb')
            input_data = input_file.read()
            b_parser = util.BlobParser(CC_CLICK_EVENT, input_data)
            for entry in b_parser:
                entry_dict = util.protobuf_to_dict(entry)
                if int(entry_dict['header']['timestamp']) < start_time:
                    continue
                self.bot_detector.add_cc_click(entry_dict)

    def get_data(self, start_time):
        results = collections.defaultdict(lambda: collections.defaultdict(lambda: 0))
        #results['clicks_count'] = 0
        #results['external_clicks_count'] = 0
        results['page_views_count'] = 0
        results['external_page_views_count'] = 0
        # results['delta'] = True delta does not make sense anymore
        self.train_bot(start_time)
        self.count_pageviews(results, start_time)
        self.count_ccclicks(results, start_time)
        ret_dict = {}
        ret_dict['item'] = {}
        time_str = self.utc_time.strftime('%Y_%m_%d')
        key = 'click_aggregate_s3_' + time_str
        ret_dict['item']['key'] = key
        ret_dict['item']['value'] = results
        return ret_dict

    def count_ccclicks(self, results, start_time):
        #result_dict = defaultdict(lambda: defaultdict(int))
        directory = self.path + CC_CLICK_EVENT.lower() + '/'
        for infile in glob.glob(os.path.join(directory, '*' +
            self.extension)):
            input_file = open(infile, 'rb')
            input_data = input_file.read()
            b_parser = util.BlobParser(CC_CLICK_EVENT, input_data)
            for entry in b_parser:
                entry_dict = util.protobuf_to_dict(entry)
                if int(entry_dict['header']['timestamp']) < start_time:
                    continue
                if not self.bot_detector.is_bot(entry_dict):
                    self.add_cc_click_event_data(entry_dict, results)

    def count_pageviews(self, results, start_time):
        directory = self.path + PAGE_VIEW_EVENT.lower() + '/'
        for infile in glob.glob(os.path.join(directory, '*' +
            self.extension)):
            input_file = open(infile, 'rb')
            input_data = input_file.read()
            b_parser = util.BlobParser(PAGE_VIEW_EVENT, input_data)
            for entry in b_parser:
                entry_dict = util.protobuf_to_dict(entry)
                if int(entry_dict['header']['timestamp']) < start_time:
                    continue
                if not self.bot_detector.is_bot(entry_dict):
                    self.add_pageview_event_data(entry_dict, results)

    def add_cc_click_event_data(self, entry, result_dict):
        product_id = entry['clickHeader']['productId']
        if 'the-best-credit-cards' in entry['header']['url']:
            if 'brainHeader' in entry['clickHeader'].keys() and \
            entry['clickHeader']['brainHeader']['brainSuccess'] == True:
                result_dict['clicks_count'][product_id] += 1
            else:
                result_dict['clicks_count'][product_id] += 1
        else:
            result_dict['external_clicks_count'][product_id] += 1

    def add_pageview_event_data(self, entry, result_dict):
        if 'the-best-credit-cards' in entry['header']['url']:
            if 'brainSuccess' in entry.keys() and entry['brainSuccess'] == True:
                result_dict['page_views_count'] += 1
            else:
                result_dict['page_views_count'] += 1
        else:
            result_dict['external_page_views_count'] += 1
        #return ret_dict
        return result_dict
