from __future__ import division

import boto
import boto.s3.key
from datetime import datetime, timedelta
import os
import shutil
from util import fetch_creds


class S3Downloader:

    def __init__(
            self, schemas =['PageViewEvent', 'CCClickEvent'],
            path='/data/etl/Data/bcc_brain_clicks_process/input/',
            utc_time=datetime.utcnow()):
        self.schemas = schemas
        self.path = path
        self.utc_time = utc_time

    def download_all(self, schemas=None):
        if schemas is not None:
            self.schemas = schemas
        self.cleanup()
        for schema in self.schemas:
            self.download_schema(schema)

    def cleanup(self):
        for schema in self.schemas:
            if os.path.isdir(self.path + schema.lower()):
                shutil.rmtree(self.path + schema.lower())

    def download_schema(self, schema):
        bucket_name = 'nw-event-data-prod'
        identifier = fetch_creds('AWS_ACCESS_KEY_ID')
        security = fetch_creds('AWS_SECRET_ACCESS_KEY')
        conn = boto.connect_s3(identifier.strip(), security.strip())
        bucket = conn.get_bucket(bucket_name)
        key = boto.s3.key.Key(bucket)
        os.makedirs(self.path + schema.lower())
        hours = self.utc_time.hour
        utc_time = self.utc_time - timedelta(hours=hours)
        if self.utc_time.minute < 10:
            print 'Less than 10 minutes since hour stroke, hence skipping the last hour'
            hours -= 1
        for i in range(hours):
            proto_time = utc_time + timedelta(hours=i)
            res_str = schema + proto_time.strftime('/%Y/%m/%d/%H.protobuf')
            key.key = res_str
            key.get_contents_to_filename(
                '{}/{}'.format(self.path + schema.lower(), proto_time.strftime('%H.protobuf')))
