'''
@author: [apillai, jportwood]
The lender filename must be of the format lendername_vertical_date.ext
'''
import argparse
import json
import logging
import os
import sys
import traceback
from datetime import datetime
from email_module import send_email
from s3_modules import s3_file_upload
from google_spreadsheet import gs_to_csv


# set up logging
logging.basicConfig(level=logging.INFO,
                    stream=sys.stdout,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('aflt_tran')


def init_email(email_template):
    """
    Parse email json template
    :param email_template: str, path to template
    :return: dict, email template data
    """
    with open(email_template) as email_file:
        email_info = json.loads(email_file.read().replace('\n', ' ').replace('\r', ' '), strict=False)
    return email_info


def email_file(email_info, email_to, file_path):
    email_info['subject'] = email_info['subject'] + ' for file ' + file_path
    email_info['body'] = email_info['body']
    email_info['attachment'] = file_path
    email_info['to'] = email_to
    logger.debug('Email Template: %s', email_info)
    send_email(email_info)


def email_error(email_info, error_msg, lender_url):
    logger.warning('Could not processing spreadsheet. Sending error email!')
    email_info['subject'] = "Error processing: google spreadsheet: " + lender_url
    email_info['to'] = "jportwood@nerdwallet.com, akhajekar@nerdwallet.com"
    email_info['body'] = email_info['body'] + str(error_msg) + ' ' + str(traceback.format_exc())
    logger.debug('Email Template: %s', email_info)
    send_email(email_info)


def main(lender_url, lender, vertical, file_out_dir, s3_bucket, s3_folder, email_template, worksheet, email_to, skiprows):
    """
    Main python script to get data from a google spreadsheet  and convert it to JSON file. Given a
    url to a file, file will be logged to the transaction log table,
    converted from csv to json, and moved to S3.

    :param lender_url: str, lender_url  
    :param vertical: str, vertical  
    :param lender: str, lender
    :param file_out_dir: str, directory to store local output csv
    :param s3_bucket: str, S3 bucket name
    :param s3_srcBucketFolder: str, S3 src folder name.
    :param s3_destBucketFolder: str, S3 bucket to store files
    :param email_template: str, file path to JSON email template
    :param worksheet: str, name of the worksheet to read 
    :param email_to: str, email alias
    :param skiprows: number of rows to skip before the header
    """
    email_info = init_email(email_template)
    try:

        # define local csv file to store spreadsheet contents
        file_name = '{}_{}_{}.csv'.format(lender, vertical, datetime.today().strftime("%Y-%m-%d"))
        file_out = os.path.join(file_out_dir, file_name)

        # clean up old local file if already exists
        if os.path.isfile(file_out):
            logger.debug('{} already exists!'.format(file_out))
            os.remove(file_out)
            logger.debug('Deleted existing file {}'.format(file_out))

        # Convert gs to csv
        gs_to_csv(lender_url, worksheet=worksheet, file_out=file_out, format_fields=False, skiprows=skiprows)

        logger.info('{} GS --> {}'.format(lender, file_out))

        # upload to s3
        logger.info('Uploading to {}'.format('s3://{}'.format(os.path.join(s3_bucket, s3_folder))))
        s3_file_upload(file_out, s3_bucket, s3_folder)

        # email csv
        email_file(email_info, email_to, file_out)

    except Exception, e:
        # send out error email
        email_error(email_info, e, lender_url)


if __name__ == '__main__':


    # Get the command line variables
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('lender_url')
        parser.add_argument('lender')
        parser.add_argument('vertical')
        parser.add_argument('file_out_dir')
        parser.add_argument('s3_bucket')
        parser.add_argument('s3_folder')
        parser.add_argument('email_json_template')
        parser.add_argument('worksheet', nargs='+')
        parser.add_argument('email_to')
	parser.add_argument('skiprows')
        args = parser.parse_args()

    except ValueError, e:
        logging.error('Invalid input parameters')
        logging.error(e)
        sys.exit(1)

    # Execute main function
    main(args.lender_url, args.lender, args.vertical, args.file_out_dir, args.s3_bucket, args.s3_folder, args.email_json_template, ' '.join(args.worksheet), args.email_to, int(args.skiprows))
