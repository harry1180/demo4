import json
import os
import pwd
import sys

import redshift_modules


def grant_permissions(conn, schema_name, table_name, permissions, grantee_keyword=None, simulate=False):
    """
    Grant a set of permissions on a table or view.

    :param conn: Database connection
    :param schema_name: Schema name for the table to grant permissions on.
    :param table_name: Name of the table to grant permissions on.
    :param permissions: The set of permissions to grant on the table or view.
    :param grantee_keyword: Keyword (if any) that is prefixed in front of the grantee. Should be set to 'GROUP' if the
    grantee is a user group.
    :param simulate: Indicates if the grants should be displayed in the log but not actually executed.
    """
    if not permissions:
        return

    for grantee, right_list in permissions.iteritems():
        sql = 'GRANT {right_list} ON {schema}.{table} TO {grantee_keyword} {grantee}'.format(
            right_list=', '.join(right_list),
            schema=schema_name,
            table=table_name,
            grantee_keyword='' if not grantee_keyword else grantee_keyword,
            grantee=grantee
        )
        print('    {};'.format(sql))
        if not simulate:
            with conn.cursor() as right_curs:
                right_curs.execute(sql)


def main(schema_metadata_filename):
    with open(schema_metadata_filename, 'r') as fh:
        schemas_metadata = json.load(fh)

    if pwd.getpwuid(os.getuid()).pw_name == 'airflow':
        conn = redshift_modules.redshift_connect(input_db='superuser')
        simulate = False
    else:
        conn = redshift_modules.redshift_connect()
        simulate = True

    for schema_name, schema_metadata in schemas_metadata.iteritems():
        owner = schema_metadata['owner']
        group_permissions = schema_metadata.get('group_permissions')
        user_permissions = schema_metadata.get('user_permissions')

        print '----------------------------------------'
        print 'CHANGING OWNERSHIP AND PERMISSIONS FOR SCHEMA ' + schema_name
        print '----------------------------------------'
        
        tables_list_query = """
            SELECT tablename, tableowner
            FROM pg_tables
            WHERE schemaname = %s
              and tableowner <> %s
            UNION ALL
            SELECT viewname, viewowner
            FROM pg_views
            WHERE schemaname = %s
              and viewowner <> %s
            ORDER BY 1"""
        with conn.cursor() as curs:
            curs.execute(tables_list_query, [schema_name, owner, schema_name, owner])
            for row in curs:
                table_name = row[0]
                current_owner = row[1]
                print('{} ({})'.format(table_name, current_owner))

                # Change the owner
                sql = 'ALTER TABLE {schema}.{table} OWNER TO {owner}'.format(
                    schema=schema_name,
                    table=table_name,
                    owner=owner
                )
                print('    {};'.format(sql))
                if not simulate:
                    with conn.cursor() as owner_curs:
                        owner_curs.execute(sql)

                # Set permissions for users and groups
                grant_permissions(
                    conn=conn,
                    schema_name=schema_name,
                    table_name=table_name,
                    permissions=user_permissions,
                    simulate=simulate)
                grant_permissions(
                    conn=conn,
                    schema_name=schema_name,
                    table_name=table_name,
                    permissions=group_permissions,
                    grantee_keyword='GROUP',
                    simulate=simulate)


if __name__ == '__main__':
    main(sys.argv[1])

