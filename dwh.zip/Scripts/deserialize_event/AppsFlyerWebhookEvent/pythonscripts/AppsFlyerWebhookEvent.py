# This is an array of the "++" columns that customize_local_json_dict adds.  Parquet is explicitly typed
# so these are needed.  Format is described in:
# https://www.safaribooksonline.com/library/view/hadoop-the-definitive/9781491901687/ch13.html

custom_fields = ['optional binary identity_id (UTF8)', 'optional binary device_id (UTF8)']

overrides = {
    'AppsFlyerWebhookEvent.event_name': {
        'name': 'appsflyer_event_name'
    }
}

def customize_dict(in_dict):
    """
    Customize dict fields from an input dict, otherwise known as ++ logic.  The parquet datatypes
    need to be declared separately in a list.
    @param in_dict is an input json dict from the protobuf stream
    Return:
        dictionary with additional and customized fields
    """

    # default values
    out_dict = {
        'identity_id': '',
        'device_id': ''
    }

    # Check if customer_user_id presents
    customer_user_id = in_dict.get('customer_user_id')
    if customer_user_id: # if key presents
        if ':' in customer_user_id: # new format
            out_dict['identity_id'], out_dict['device_id'] = customer_user_id.split(':', 1)

    return out_dict
