from datetime import datetime, date, timedelta
from six import string_types

custom_fields = ["optional INT96 zzz_timestamp"]

def customize_dict(in_dict):
    """
    Customize json dict fields from an input json dict.
    @param in_dict is an input json dict
    Return:
        dictionary containing additional and customized fields
    """
    out_dict = dict()

    # UUID values of CHCKPIPE are internal records that verify that AB is able
    # to talk with Logger. We started seeing these on 2016-11-01. These are
    # internal status fields, ignore them.
    if in_dict.get("uuid") == "CHCKPIPE":
        out_dict["_skipthisrecord"] = True
        return out_dict

    # If we don't have a timestamp, skip the record
    epoch_time = in_dict.get("time")
    if epoch_time is None:
        out_dict["_skipthisrecord"] = True
        return out_dict

    # Make sure our timestamp is numeric
    if isinstance(epoch_time, (int, long)):
        pass
    elif isinstance(epoch_time, string_types) and epoch_time.isdigit():
        epoch_time = long(epoch_time)
    else:
        out_dict["_skipthisrecord"] = True
        return out_dict

    # Convert the "time" field into milliseconds. Historically the "time" field
    # has changed formats:
    #
    # 1. Originally it was provided in nanoseconds, 9 decimals of precision
    # 2. Sometime in the first half of 2016 it was switched to microseconds,
    #    6 decimals of precision.
    # 3. On 2016-10-21 we started getting bad time values that were 17 digits
    #    long.
    #
    if epoch_time >= 1000000000000000000L:
        # 19 digits = Nanoseconds
        epoch_time = epoch_time / 1000000L
    elif 1000000000000000L <= epoch_time <= 9999999999999999L:
        # 16 digits = Microseconds
        epoch_time = epoch_time / 1000L
    elif 1000000000000L <= epoch_time <= 9999999999999L:
        # 13 digits = Milliseconds, the desired format although we don't
        # actually get any records like this today
        pass
    else:
        # Unexpected number of digits, skip the record
        out_dict["_skipthisrecord"] = True
        return out_dict

    out_dict["zzz_timestamp"] = epoch_time

    # Check our timestamp. If it's before 2015-01-01 or if it's more than two
    # days in the future, then it's not valid and we should skip this record.
    # Otherwise we'll create thousands of past and future partitions in Hive/S3
    # that only have a couple records in them.
    if epoch_time < 1420070400000:  # 2015-01-01 00:00:00.000 UTC
        out_dict["_skipthisrecord"] = True
        return out_dict

    two_days_from_now = (datetime.now() + timedelta(days=2))
    two_days_from_now_posix_ms = (two_days_from_now - datetime.utcfromtimestamp(0)).total_seconds() * 1000L
    if epoch_time > two_days_from_now_posix_ms:
        out_dict["_skipthisrecord"] = True
        return out_dict

    return out_dict
