import sys,os
import time
import json
import os.path
import shutil
import urllib
from s3_modules import get_s3_files_in_range, s3_file_download, mv_to_s3, check_if_key_exist
from file_and_path_utils import FileUtils
sys.path.append('/data/etl/Common/nw_python_modules/json_modules')
import json_utils as json_util
from s3_modules import *
from datetime import date
from datetime import datetime
from datetime import timedelta
import fileinput
import glob
import pandas
from pprint import *
from pandas.io.json import json_normalize
import pprint
from nw_url_check import *
from prettytable import PrettyTable

def parse_ccclick_view(input_file):
#    print "input_file", input_file
    redshift_dict=[]
    key_file_stats={}
    with open(input_file) as json_file:
        jsondict = json.load(json_file)
#        print "jsondict count - ",len(jsondict)
        for item in jsondict:
            dw_item=item.copy()
            src_url=fetch_dict_key(dw_item,'url')
            src_url=urllib.unquote(src_url)
            Final_clean_url = url_strip(src_url)
            parse_url = urlparse(Final_clean_url)
            parse_scheme = parse_url.scheme
            parse_netloc = parse_url.netloc
            parse_path = parse_url.path
            new_url=nw_url_join(parse_scheme,parse_netloc,url_strip(parse_path))
            validated_url = url_strip(fix_nw_url(new_url))
            validated_parsed = urlparse(validated_url)
            validated_scheme = validated_parsed.scheme
            validated_netloc = validated_parsed.netloc
            validated_path = validated_parsed.path
            is_valid = validate_url_struct(validated_url)
            validated_query = validated_parsed.query
            dw_item.update({'zzz_parse_scheme':parse_scheme})
            dw_item.update({'zzz_parse_netloc':parse_netloc})
            dw_item.update({'zzz_parse_path':parse_path})
            dw_item.update({'zzz_new_url':new_url})
            dw_item.update({'zzz_validated_url':validated_url})
            dw_item.update({'zzz_validated_scheme':validated_scheme})
            dw_item.update({'zzz_validated_netloc':validated_netloc})
            dw_item.update({'zzz_validated_path':validated_path})
            dw_item.update({'zzz_is_valid':is_valid})
            dw_item.update({'zzz_validated_query':validated_query})
            src_user_agent = fetch_dict_key(dw_item,'userAgent')
            dw_userAgent = parse_useragent(src_user_agent)
            dw_item.update(dw_userAgent)
            redshift_dict.append(dw_item)

    try:
        key_file_stats={'key_file_name':input_file,'raw_json_record_count':len(jsondict),'parsed_json_redshift_record_count':len(redshift_dict)}
    except:
        key_file_stats={'key_file_name':input_file,'raw_json_record_count':-1,'parsed_json_redshift_record_count':-1}
    return redshift_dict, key_file_stats


####################################       main          ####################################

def main():
    """
    Pulls python files from S3 using details specified in a .ctrl file. It then converts all python/json files (format: [{},\n{},...,\n{}]\n) to json (format: {}\n...\n{}\n) that is loadable by Redshift
    and re-uploads to S3.
    Usage: python ccimpression_event.py <source_bucket> <source_path> <task_name> <local_input_path> <local_output_path> <local_archive_path> <destination_bucket> <destination_output_path> <destination_archive_path> <start_date_yyyy-mm-dd> <end_date_yyyy-mm-dd>
    """
    if len(sys.argv) != 13:
        print 'Input %d arguments:\n%s' % (len(sys.argv), str(sys.argv))
        print main.__doc__
        print "Exit."
        return
    print 'Start ...'
    #print 'Input %d arguments:\n%s' % (len(sys.argv), str(sys.argv))
    source_bucket              = sys.argv[1]
    source_path                = sys.argv[2]

    task_name                  = sys.argv[3]

    local_input_path           = sys.argv[4]
    local_output_path          = sys.argv[5]
    local_archive_path         = sys.argv[6]

    destination_bucket         = sys.argv[7]
    destination_path           = sys.argv[8]
    destination_output_path    = sys.argv[9]
    destination_archive_path   = sys.argv[10]

    start_date_time            = sys.argv[11]
    end_date_time              = sys.argv[12]
    print 'Processing json files from s3: %s / %s to s3: %s / %s' % (source_bucket, source_path, destination_bucket, destination_path)
    print 'Running for date range of [%s, %s]' % (start_date_time, end_date_time)

    # Local fs stuff
    FileUtils.create_path(local_input_path)
    FileUtils.create_path(local_output_path)
    FileUtils.create_path(local_archive_path)

    # Counters for hourly json files
    JSON_record_counter=[]


    local_batch_filename = os.path.join(local_output_path, task_name) + "_" + time.strftime('%Y_%m_%d_%H_%M') + '.json'
    # local_batch_filename = /data/etl/Data/ccimpression_event/output/ccimpression_event_2015_09_17_09_11.json

    # Main action
    # Download the python files and merged into one json file for loading into Redshift
    with open(local_batch_filename, 'w') as batch_outfile:
        for key in get_s3_files_in_range('Prod', source_bucket, start_date_time, end_date_time, source_path,'created'):
            print 'Found key at s3: %s / %s' % (source_bucket, key)

            s3_dest_file = key.replace(source_path + '/', destination_archive_path)
            #Uncomment the below step if we need to skip the existing keys
            #if check_if_key_exist(destination_bucket, s3_dest_file):
            #    print 'DWH Key already exist at s3: %s / %s' % (destination_bucket, s3_dest_file)
            #    continue
            #print 'DWH Key is: %s' % s3_dest_file

            s3_subdir = os.path.dirname(s3_dest_file).replace(destination_archive_path, '')
            # s3_subdir=2015/09/17

            file_input_path = os.path.join(local_input_path, s3_subdir)
            FileUtils.create_path(file_input_path)

            file_archive_path = os.path.join(local_archive_path, s3_subdir)
            FileUtils.create_path(file_archive_path)

            # only when key doesn't exist then download from s3 to local

            tries = 1
            tot_size=0
            while tries < 5:
                try:
                    local_input_filename = s3_file_download(source_bucket, source_path, key, local_input_path, to_file=True)
                    break
                except ssl.SSLError:
                    tries +=1
            else:
                raise TimeoutError

            # local_input_filename=/data/etl/Data/ccimpression_event/input/2015/09/17/10.json
            print 'Downloaded   to %s' % local_input_filename

            # File and path manipulation
            local_archive_filename = local_input_filename.replace(local_input_path, local_archive_path)
            # local_archive_filename=/data/etl/Data/ccimpression_event/archive/2015/09/17/10.json

            #parse JSON file for ETL cleansing
            print 'parsing JSON file for ETL cleansing %s' % local_input_filename

            #Main Code to page click event
            ccc_output_dict, parsed_key_file_stats=parse_ccclick_view(local_input_filename)
            JSON_record_counter.append(parsed_key_file_stats)


            #dump the dict in Redshift readable format
            with open(local_archive_filename, 'w') as outfile:
                for item in ccc_output_dict:

                    # write to hourly key file
                    json.dump(item,outfile,indent=4, sort_keys=True)
                    batch_outfile.write('\n')

                    # write to batch file
                    json.dump(item,batch_outfile,indent=4, sort_keys=True)
                    batch_outfile.write('\n')
            # Upload the json from local path to destination s3 bucket
            s3_archive_path = os.path.join(destination_archive_path,s3_subdir)
            mv_to_s3(local_archive_filename, s3_archive_path, destination_bucket)
            print 'Uploaded     to s3: %s / %s' % (destination_bucket, os.path.join(s3_archive_path,os.path.basename(local_archive_filename)))

    mv_to_s3(local_batch_filename, destination_output_path, destination_bucket)
    print 'Uploaded     from %s to s3: %s / %s' % ( local_batch_filename, destination_bucket, os.path.join(destination_output_path,os.path.basename(local_batch_filename)) )


    print 'Batch Completed. Printing key file stats ...'
    #x = PrettyTable(counter[0].viewkeys())
    x = PrettyTable(["key_file_name", "raw_json_record_count","parsed_json_redshift_record_count","diff"])
    x.align = "l" # Left align
    x.padding_width = 1 # One space between column edges and contents (default)
    for c in JSON_record_counter:
        x.add_row([c['key_file_name'],c['raw_json_record_count'],c['parsed_json_redshift_record_count'],(c['raw_json_record_count']-c['parsed_json_redshift_record_count'])])
    print x

if __name__ == '__main__':
    main()
