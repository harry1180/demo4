--DROP TABLE "dw_report"."dw_aflt_tran_comm_junc_f";
CREATE TABLE "dw_report"."dw_aflt_tran_comm_junc_f"
(
	"aflt_network_tran_id" VARCHAR(256)
	,"aflt_network_id" INTEGER
	,"aflt_fin_tran_type_cd" VARCHAR(256)
	,"dw_eff_dt" DATE
	,"tran_post_dt" DATE
	,"tran_click_dt" DATE
	,"tran_post_ts" TIMESTAMP WITHOUT TIME ZONE
	,"tran_click_ts" TIMESTAMP WITHOUT TIME ZONE
	,"src_prod_nm" VARCHAR(256)
	,"dw_site_visitor_id" VARCHAR(256)
	,"prod_src_sys_id" VARCHAR(256)
	,"dw_site_prod_sk" VARCHAR(256)
	,"dw_site_prod_nm" VARCHAR(256)
	,"prog_nm" VARCHAR(256)
	,"src_unique_click_id" VARCHAR(256)
	,"commission_am" NUMERIC(10,2)
	,"merchant_am" NUMERIC(10,2)
	,"catg_nm" VARCHAR(256)
	,"action_status" VARCHAR(256)
	,"sku" VARCHAR(256)
	,"aid" BIGINT
	,"country" VARCHAR(256)
	,"locking_dt" DATE
	,"order_id" VARCHAR(256)
	,"original" BOOLEAN
	,"original_action_id" BIGINT
	,"website_id" BIGINT
	,"action_tracker_id" BIGINT
	,"category_id" BIGINT
	,"order_discount" NUMERIC(10,2)
	,"dw_load_ts" TIMESTAMP WITHOUT TIME ZONE
)
DISTSTYLE KEY
DISTKEY ("aflt_network_tran_id")
SORTKEY (
	"dw_eff_dt"
	)
;
