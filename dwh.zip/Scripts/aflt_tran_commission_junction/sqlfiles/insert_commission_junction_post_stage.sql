CREATE TEMP TABLE dwh_clicks DISTSTYLE KEY DISTKEY (src_unique_click_id) AS
SELECT
    src_unique_click_id,
    dw_site_visitor_id,
    src_prod_nm,
    dw_src_sys_id,
    dw_site_prod_sk
FROM (
    SELECT
        src_unique_click_id,
        dw_site_visitor_id,
        src_prod_nm,
        dw_src_sys_id,
        dw_site_prod_sk,
        row_number() OVER (PARTITION BY src_unique_click_id ORDER BY click_utc_ts DESC) as dedup
    FROM dw_report.dw_clicks_event_f
    WHERE dw_eff_dt >= (
        SELECT COALESCE(MIN(event_date) - 30, current_date - 30) as min_date
        FROM :stagedb.aflt_tran_comm_junc
      )
  ) clicks_event
WHERE clicks_event.dedup = 1
;

INSERT INTO :stagedb.aflt_tran_comm_junc_post_stg
(
    aflt_network_tran_id,
    aflt_network_id,
    aflt_fin_tran_type_cd,
    dw_eff_dt,
    tran_post_dt,
    tran_click_dt,
    tran_post_ts,
    tran_click_ts,
    src_prod_nm,
    prog_nm,
    src_unique_click_id,
    dw_site_visitor_id,
    prod_src_sys_id,
    dw_site_prod_sk,
    dw_site_prod_nm,
    commission_am,
    merchant_am,
    catg_nm,
    action_status,
    sku,
    aid,
    country,
    locking_dt,
    order_id,
    original,
    original_action_id,
    website_id,
    action_tracker_id,
    category_id,
    order_discount,
    dw_load_ts
)
WITH stg AS
(
    SELECT
        a.commission_id AS aflt_network_tran_id,
        1 AS aflt_network_id,
        a.action_type AS aflt_fin_tran_type_cd,
        cast(event_date AS date) AS dw_eff_dt,
        cast(a.posting_date AS date) AS tran_post_dt,
        cast(a.event_date AS date) AS tran_click_dt,
        cast(a.posting_date AS timestamp) AS tran_post_ts,
        cast(a.event_date AS timestamp) AS tran_click_ts,
        a.action_tracker_name AS src_prod_nm,
        a.advertiser_name AS prog_nm,
        a.sid AS src_unique_click_id,
        coalesce (d.dw_site_visitor_id, -999999999) AS dw_site_visitor_id,
        coalesce (d.dw_src_sys_id, -999999999) AS prod_src_sys_id,
        coalesce (d.dw_site_prod_sk, '-999999999') AS dw_site_prod_sk,
        coalesce (d.src_prod_nm, 'Not Found In Clicks') AS dw_site_prod_nm,
        a.commission_amount  AS commission_am,
        a.sale_amount  AS merchant_am,
        a.cid AS catg_nm,
        a.action_status,
        a.sku,
        a.aid,
        a.country,
        cast (a.locking_date AS DATE) AS locking_dt,
        a.order_id,
        a.original,
        a.original_action_id,
        a.website_id,
        a.action_tracker_id,
        a.cid AS category_id,
        a.order_discount,
        sysdate as dw_load_ts,
        row_number() OVER (PARTITION BY a.commission_id ORDER BY event_date DESC) as dedup
    FROM :stagedb.aflt_tran_comm_junc a
    LEFT OUTER JOIN dwh_clicks d
        ON COALESCE(a.sid, 'NA') = COALESCE(d.src_unique_click_id, 'UNKNOWN')
)
SELECT
    aflt_network_tran_id,
    aflt_network_id,
    aflt_fin_tran_type_cd,
    dw_eff_dt,
    tran_post_dt,
    tran_click_dt,
    tran_post_ts,
    tran_click_ts,
    src_prod_nm,
    prog_nm,
    src_unique_click_id,
    dw_site_visitor_id,
    prod_src_sys_id,
    dw_site_prod_sk,
    dw_site_prod_nm,
    commission_am,
    merchant_am,
    catg_nm,
    action_status,
    sku,
    aid,
    country,
    locking_dt,
    order_id,
    original,
    original_action_id,
    website_id,
    action_tracker_id,
    category_id,
    order_discount,
    dw_load_ts
FROM stg
WHERE stg.dedup = 1
;
