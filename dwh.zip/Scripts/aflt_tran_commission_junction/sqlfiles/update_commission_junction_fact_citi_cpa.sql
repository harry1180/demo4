
update :reportdb.dw_aflt_tran_comm_junc_f
set
 dw_site_prod_sk = c.dw_site_prod_sk ,
 dw_site_prod_nm = c.dw_site_prod_sk ,
 commission_am = cpa_d.cpa  
from dw_report.dw_clicks_event_f c
inner join
(select distinct dw_site_prod_sk , cpa from dw_report.dw_citi_cpa_d) cpa_d
on cpa_d.dw_site_prod_sk = c.dw_site_prod_sk
where c.src_unique_click_id = :reportdb.dw_aflt_tran_comm_junc_f.src_unique_click_id
and c.dw_src_sys_id=1
and lower(:reportdb.dw_aflt_tran_comm_junc_f.src_prod_nm) = 'citi approved application'
and :reportdb.dw_aflt_tran_comm_junc_f.dw_eff_dt > '2018-05-31'
and :reportdb.dw_aflt_tran_comm_junc_f.dw_eff_dt > trunc(sysdate) - 60  and c.dw_eff_dt > trunc(sysdate) - 60 and coalesce(commission_am,0) = 0;



update :reportdb.dw_aflt_tran_comm_junc_f
set
dw_site_prod_sk = cpa_d.prod_sk ,
dw_site_prod_nm = cpa_d.slug_tx ,
commission_am =  cpa_d.cpa 
from   
(
select src_comm_id,src_item_nm,src_actn_trckr_nm,dw_site_prod_sk as prod_sk,cpa,src_event_dt,slug_tx   from dw_report.dw_aflt_tran_citi_f
inner join
dw_report.dw_citi_cpa_d
on src_item_nm = CJ_prod_1
) cpa_d

where aflt_network_tran_id = split_part(cpa_d.src_comm_id,'.',1)
and tran_post_dt >  trunc(sysdate) - 60 and tran_post_dt > '2018-05-31'
and lower(src_prod_nm) like '%citi%'
and dw_site_prod_sk = '-999999999'
and src_prod_nm = 'Citi Approved Application'
;

