SELECT admin_best_credit_cards_sections.id,
    admin_best_credit_cards_sections.title,
    admin_best_credit_cards_sections.short_title,
    admin_best_credit_cards_sections.title_notes,
    admin_best_credit_cards_sections.identifier,
    admin_best_credit_cards_sections.order,
    admin_best_credit_cards_sections.active
FROM nwallet_creditcards_mvc.admin_best_credit_cards_sections;
