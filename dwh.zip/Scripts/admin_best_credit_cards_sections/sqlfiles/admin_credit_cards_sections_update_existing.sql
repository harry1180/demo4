UPDATE dw_report.dw_admin_best_credit_cards_sections_d
   SET dw_expr_dt = sysdate, curr_in = 0
  FROM dw_stage.admin_best_credit_cards_sections_s b
      WHERE    dw_report.dw_admin_best_credit_cards_sections_d.section_id = b.id
           AND dw_report.dw_admin_best_credit_cards_sections_d.title <> b.title
           AND dw_report.dw_admin_best_credit_cards_sections_d.short_title <> b.short_title
           AND dw_report.dw_admin_best_credit_cards_sections_d.title_notes <> b.title_notes
                   AND dw_report.dw_admin_best_credit_cards_sections_d.identifier <> b.identifier
           AND dw_report.dw_admin_best_credit_cards_sections_d.order_id <> b.order_id
           AND dw_report.dw_admin_best_credit_cards_sections_d.active_in <> b.active_in
           AND dw_report.dw_admin_best_credit_cards_sections_d.curr_in = 1;
