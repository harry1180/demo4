INSERT INTO dw_report.dw_admin_best_credit_cards_sections_d
   (SELECT id as section_id,
          cast (sysdate AS date) AS dw_eff_dt,
          to_date ('9999-01-01', 'YYYY-MM-DD') AS dw_expr_dt,
          1 AS curr_in,
          title,
          short_title,
          title_notes,
		  identifier,
		  order_id,
		  active_in,
		  sysdate as dw_load_ts from (
     select a.*, b.section_id as record_exists FROM dw_stage.admin_best_credit_cards_sections_s a
          LEFT OUTER JOIN dw_report.dw_admin_best_credit_cards_sections_d b
             ON     a.id = b.section_id 
                ) where record_exists IS NULL);
