INSERT INTO dw_report.dw_admin_best_credit_cards_sections_d
   (SELECT a.id as section_id,
          cast (sysdate AS date) AS dw_eff_dt,
          to_date ('9999-01-01', 'YYYY-MM-DD') AS dw_expr_dt,
          1 AS curr_in,
          a.title,
          a.short_title,
          a.title_notes,
		  a.identifier,
		  a.order_id,
		  a.active_in,
		  sysdate as dw_load_ts
      FROM dw_stage.admin_best_credit_cards_sections_s a,
           dw_report.dw_admin_best_credit_cards_sections_d b
     WHERE     a.id = b.section_id 
           AND a.title <> b.title
           AND a.short_title <> b.short_title
           AND a.title_notes <> b.title_notes
		   AND a.identifier <> b.identifier
           AND a.order_id <> b.order_id
           AND a.active_in <> b.active_in);
