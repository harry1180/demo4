DROP TABLE IF EXISTS dw_stage.deactivate_credit_profile_event_s;

CREATE TABLE dw_stage.deactivate_credit_profile_event_s
(
  userId                 VARCHAR(256)   ENCODE LZO ,
  targetUserId           VARCHAR(256)   ENCODE LZO ,
  deactivate_reason       VARCHAR(1000)   ENCODE LZO ,
  userType               VARCHAR(50)   ENCODE LZO ,
  guid                   VARCHAR(6000)   ENCODE LZO ,
  "timestamp"            TIMESTAMP   ENCODE LZO ,
  environment            VARCHAR(10)   ENCODE LZO ,
  cookieId               VARCHAR(100)   ENCODE LZO ,
  url                    VARCHAR(6000)   ENCODE LZO ,
  ip                     VARCHAR(100)   ENCODE LZO ,
  userAgent              VARCHAR(6000)   ENCODE LZO ,
  pageviewId             VARCHAR(1000)   ENCODE LZO ,
  eventName              VARCHAR(100)   ENCODE LZO ,
  errorMessages          VARCHAR(6000)   ENCODE LZO ,
  referrer               VARCHAR(6000)   ENCODE LZO ,
  userRoles              VARCHAR(100)   ENCODE LZO ,
  browserSessionId       VARCHAR(256)   ENCODE LZO ,
  requestId              VARCHAR(6000)   ENCODE LZO ,
  applicationId          VARCHAR(3000)   ENCODE LZO ,
  geoResolved            BOOLEAN    ENCODE RUNLENGTH ,
  latitude               VARCHAR(100)   ENCODE LZO ,
  longitude              VARCHAR(100)   ENCODE LZO ,
  city                   VARCHAR(100)   ENCODE LZO ,
  postalCode             VARCHAR(100)   ENCODE LZO ,
  country                VARCHAR(100)   ENCODE LZO ,
  region                 VARCHAR(100)   ENCODE LZO ,
  metroCode              BIGINT   ENCODE LZO ,
  timezone               VARCHAR(100)   ENCODE LZO ,
  geoId                  BIGINT   ENCODE LZO ,
  browserType            VARCHAR(100)   ENCODE LZO ,
  browserTypeReason      VARCHAR(1000)   ENCODE LZO ,
  nwSessionId             VARCHAR(1000)   ENCODE LZO ,
  callerClientId          varchar(2000)   ENCODE LZO ,
  referringCallerClientId   varchar(2000) ENCODE LZO 
)
distkey (userId);

GRANT ALL  ON dw_stage.deactivate_credit_profile_event_s TO GROUP grp_etl;

GRANT SELECT  ON dw_stage.deactivate_credit_profile_event_s TO GROUP grp_data_users;



