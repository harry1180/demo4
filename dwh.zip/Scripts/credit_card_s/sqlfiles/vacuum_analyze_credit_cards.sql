vacuum dw_report.dw_credit_cards;

analyze dw_report.dw_credit_cards;
