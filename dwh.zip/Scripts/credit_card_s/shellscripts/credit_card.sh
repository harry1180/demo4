

job_name='credit_card_s'



job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


Linux_Input=${dwh_data_base_dir}/${job_name}/input/
Linux_Output=${dwh_data_base_dir}/${job_name}/output/
Linux_Archive=${dwh_data_base_dir}/${job_name}/archive/
S3_Input=/s3mnt-dwh-staging/${job_name}/input/
S3_Output=/s3mnt-dwh-staging/${job_name}/output/
S3_Archive=/s3mnt-dwh-staging/${job_name}/archive/
echo '+----------+----------+----------+----------+----------+----------+'
echo 'dwh_credentials_file_dir   :-   '${dwh_credentials_file_dir}
echo 'dwh_scripts_base_dir       :-   '${dwh_scripts_base_dir}
echo 'dwh_common_base_dir        :-   '${dwh_common_base_dir}
echo 'dwh_data_base_dir          :-   '${dwh_data_base_dir}
echo 'Linux_Input                :-   '${Linux_Input}
echo 'Linux_Output               :-   '${Linux_Output}
echo 'Linux_Archive              :-   '${Linux_Archive}
echo 'S3_Input                   :-   '${S3_Input}
echo 'S3_Output                  :-   '${S3_Output}
echo 'S3_Archive                 :-   '${S3_Archive}
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'

echo '+----------+----------+----------+----------+----------+----------+'



bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'


echo_processing_step ${job_name} "Cleaning S3 and data direcotries" "Started"
rm $Linux_Input*credit* || true
rm $S3_Input*credit* || true
echo_processing_step ${job_name} "Cleaning S3 and data direcotries" "Completed" 

echo_processing_step ${job_name} "Pulling MySql Data" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/mysql_pull_credit_card.sql ${dwh_data_base_dir}/${job_name}/credit_cards.csv
echo_processing_step ${job_name} "Pulling MySql Data" "Completed"

echo_processing_step ${job_name} "Compressing the file and moving to S3" "Started"
gzip ${dwh_data_base_dir}/${job_name}/credit_cards.csv
chmod 775 ${dwh_data_base_dir}/${job_name}/credit_cards.csv.gz
mv ${dwh_data_base_dir}/${job_name}/credit_cards.csv.gz /s3mnt-dwh-staging/credit_card_s/credit_cards.csv.gz
chmod 775 /s3mnt-dwh-staging/credit_card_s/credit_cards.csv.gz
echo_processing_step ${job_name} "Compressing the file and moving to S3" "Completed"

echo_processing_step ${job_name} "Deleting the data from the Staging Table" "Started"
query_stage_delete="delete from dw_stage.credit_cards_l;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Deleting the data from the Staging Table" "Completed"

echo_processing_step ${job_name} "Copying the data to Staging Table" "Started"
query="copy dw_stage.credit_cards_l from '$s3_bucket_name/${job_name}/credit_cards' credentials '$s3_prod_load_creds' gzip delimiter '\t' dateformat 'auto' NULL AS 'NULL' ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF TRUNCATECOLUMNS TRIMBLANKS;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
echo_processing_step ${job_name} "Copying the data to Staging Table" "Completed"

echo_processing_step ${job_name} "Loading the data to Target Table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/load_credit_cards_d.sql
echo_processing_step ${job_name} "Loading the data to Target Table" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

