set -e
job_name='ba_mktg_sst_additive_nerdlake'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/set_dwh_schema_variables.sh
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
source ${dwh_common_base_dir}/nw_shell_modules/date_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0

bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
stagetable='ba_mktg_sst_additive_w'
datatable='ba_mktg_sst_additive'

echo "Stage Table                      :- $stagetable"
echo "Data Table                       :- $datatable"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
if [ -d "$Linux_Temp" ] && [ "$Linux_Temp" != "/tmp" ]
then
    echo_processing_step ${job_name} "Removing Temporary Files" "Started"
    find $Linux_Temp -type f -exec rm {} \; || true
    echo_processing_step ${job_name} "Removing Temporary Files" "Completed"
fi

JSON_PARAMS=$(mktemp --tmpdir=$Linux_Temp --suffix=.json params_XXXXXXXXXX)
echo "{" > $JSON_PARAMS
echo "    \"\${hivevar:stagedb}\": \"$hive_stagedb\"," >> $JSON_PARAMS
echo "    \"\${hivevar:start_date}\": \"$start_date\"" >> $JSON_PARAMS
echo "}" >> $JSON_PARAMS

Processing_Step="Load data into fact table"
echo_processing_step ${job_name} "$Processing_Step" "Started"

sql_script="step01_ba_mktg_sst_additive_w.sql"
bash $dwh_common_base_dir/hive_sql_function.sh "$dwh_scripts_base_dir/$job_name/sqlfiles/$sql_script" \
    --hivevar stagedb=$hive_stagedb \
    --hivevar datadb=$hive_datadb
echo_processing_step ${job_name} "$sql_script" "Completed"

# Run DML using Presto
sql_script="step02_ins_ba_mktg_sst_additive_w.sql"
echo_processing_step ${job_name} "$sql_script" "Started"
bash $dwh_common_base_dir/presto_sql_function.sh $dwh_scripts_base_dir/$job_name/sqlfiles/$sql_script $JSON_PARAMS
echo_processing_step ${job_name} "$sql_script" "Completed"

# Move the partitions we built into the production table
echo_processing_step ${job_name} "Move partitions into production table" "Started"
python ${dwh_common_base_dir}/exchange_partitions.py ${hive_stagedb} ${stagetable} ${hive_datadb} ${datatable}
echo_processing_step ${job_name} "Move partitions into production table" "Started"

# End of job
echo_processing_step ${job_name} "$Processing_Step" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'