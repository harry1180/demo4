insert into dw_report.ctl_jobs_status
(job_id,
job_tracking_id,
job_date,
job_name,
job_start_time,
job_end_time,
job_status,
dw_load_ts
) values
(113,
cast(to_char(sysdate,'YYYYMMDD') as bigint),
sysdate,
'dag_daily_marketing_offline',
null,
sysdate,
'SUCCESS',
sysdate
);
