import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_activity_merge"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2016, 07, 30),
    'email': ['airflowalerts@nerdwallet.com','dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(1,5),
    task_id='Initiating_start_time',
    dag=dag)
    

Task_page_view_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_page_view_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='page_view_event_f',
    dag=dag)

Task_click_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_clicks_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

Task_impression_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_prod_imprsn_consolidated_f',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='CCImpressionEvent_Consolidated_F',
    dag=dag)

Task_identity_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_identity_event_f',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_identity_event_Fact_Load',
    dag=dag)

Task_form_input_change_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_pv_form_input_chg_event_f',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='FormInputChangedEvent_Fact_Load',
    dag=dag)

Task_affiliate_transaction_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_aflt_tran_consolidated_f',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_consolidated_fact',
    dag=dag)

Task_product_interaction_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_prod_intactn_event_f',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='dw_prod_intactn_event_f_Fact_Load',
    dag=dag)


task_dw_actvy_f_Core_Fact_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_actvy_f/shellscripts/dw_actvy_f_core.sh",
    script_args=[],
    task_id='dw_actvy_f_core_Fact_Load',
    dag=dag)  
    
task_dw_actvy_f_Non_Core_Fact_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_actvy_f/shellscripts/dw_actvy_f_non_core.sh",
    script_args=[],
    task_id='dw_actvy_f_non_core_Fact_Load',
    dag=dag)                     
                       

task_dw_actvy_f_Core_Fact_Load.set_upstream(task_start_job)
task_dw_actvy_f_Core_Fact_Load.set_upstream(Task_page_view_dependency)
task_dw_actvy_f_Core_Fact_Load.set_upstream(Task_click_dependency)
task_dw_actvy_f_Core_Fact_Load.set_upstream(Task_identity_dependency)
task_dw_actvy_f_Core_Fact_Load.set_upstream(Task_affiliate_transaction_dependency)

task_dw_actvy_f_Non_Core_Fact_Load.set_upstream(task_start_job)
task_dw_actvy_f_Non_Core_Fact_Load.set_upstream(Task_impression_dependency)
task_dw_actvy_f_Non_Core_Fact_Load.set_upstream(Task_form_input_change_dependency)
task_dw_actvy_f_Non_Core_Fact_Load.set_upstream(Task_product_interaction_dependency)
task_dw_actvy_f_Non_Core_Fact_Load.set_upstream(task_dw_actvy_f_Core_Fact_Load)

