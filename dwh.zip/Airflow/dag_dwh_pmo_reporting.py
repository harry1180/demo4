# import sys
from airflow import DAG
# import airflow.operators
from datetime import datetime, timedelta, time
# from airflow.operators import BashOperator
# import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_dwh_pmo_reporting"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 7, 27),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(4, 25),
    task_id='Initiating_start_time',
    dag=dag)


task_jira_issue_stage_load_script = "/data/etl/Scripts/jira_issue_s/shellscripts/jira_issue_s.sh"
task_jira_issue_stage_load = NWBashScriptOperator(
    bash_script=task_jira_issue_stage_load_script,
    script_args=[],
    task_id='jira_issue_stage_load',
    dag=dag)
    
task_jira_issue_fact_load_script = "/data/etl/Scripts/jira_issu_f/shellscripts/jira_issu_f.sh"
task_jira_issue_fact_load = NWBashScriptOperator(
    bash_script=task_jira_issue_fact_load_script,
    script_args=[],
    task_id='jira_issue_fact_load',
    dag=dag)
    
task_jira_design_cstm_fact_load_script = "/data/etl/Scripts/jira_design_cstm_f/shellscripts/jira_design_cstm_f.sh"
task_jira_design_cstm_fact_load = NWBashScriptOperator(
    bash_script=task_jira_design_cstm_fact_load_script,
    script_args=[],
    task_id='jira_design_cstm_fact_load',
    dag=dag)
    

task_jira_user_stage_load_script = "/data/etl/Scripts/jira_user_s/shellscripts/jira_user_s.sh"
task_jira_user_stage_load = NWBashScriptOperator(
    bash_script=task_jira_user_stage_load_script,
    script_args=[],
    task_id='jira_user_stage_load',
    dag=dag)
    
task_jira_user_fact_load_script = "/data/etl/Scripts/jira_user_d/shellscripts/jira_user_d.sh"
task_jira_user_fact_load = NWBashScriptOperator(
    bash_script=task_jira_user_fact_load_script,
    script_args=[],
    task_id='jira_user_fact_load',
    dag=dag)
    

task_jira_comment_stage_load_script = "/data/etl/Scripts/jira_comment_s/shellscripts/jira_comment_s.sh"
task_jira_comment_stage_load = NWBashScriptOperator(
    bash_script=task_jira_comment_stage_load_script,
    script_args=[],
    task_id='jira_comment_stage_load',
    dag=dag)
    
task_jira_cmnt_fact_load_script = "/data/etl/Scripts/jira_cmnt_d/shellscripts/jira_cmnt_d.sh"
task_jira_cmnt_fact_load = NWBashScriptOperator(
    bash_script=task_jira_cmnt_fact_load_script,
    script_args=[],
    task_id='jira_cmnt_fact_load',
    dag=dag)
    
    
task_jira_issue_stage_load.set_upstream(task_start_job)
task_jira_issue_fact_load.set_upstream(task_jira_issue_stage_load)
task_jira_design_cstm_fact_load.set_upstream(task_jira_issue_stage_load)


task_jira_user_stage_load.set_upstream(task_start_job)
task_jira_user_fact_load.set_upstream(task_jira_user_stage_load)


task_jira_comment_stage_load.set_upstream(task_start_job)
task_jira_cmnt_fact_load.set_upstream(task_jira_comment_stage_load)

