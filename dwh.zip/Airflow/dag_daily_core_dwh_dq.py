import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator, PythonOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

sys.path.append('/data/etl/Common')
from run_dq_check import dq_check as dq_check_call

job_name = "dag_daily_core_dwh_dq"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime.now(),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    'depends_on_past': False,
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(3,15),
    task_id='Initiating_start_time',
    dag=dag)

Task_daily_core_dwh_clicks_event_fact_dependency = ExternalTaskSensor(
    task_id='waiting_for_daily_core_dwh_clicks_event_fact',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

task_dq_click_event_max_work = PythonOperator(
	task_id         = 'dq_click_event_max_work',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_max_work.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_work = PythonOperator(
	task_id         = 'dq_click_event_work',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_work.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_day_mismatch = PythonOperator(
	task_id         = 'dq_click_event_day_mismatch',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_day_mismatch.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_hr_mismatch = PythonOperator(
	task_id         = 'dq_click_event_hr_mismatch',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_hr_mismatch.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_compare_match_by_day_pct = PythonOperator(
	task_id         = 'dq_click_event_compare_match_by_day_pct',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_compare_match_by_day_pct.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_clicks_missing_page_or_url_sk = PythonOperator(
	task_id         = 'dq_click_event_clicks_missing_page_or_url_sk',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_clicks_missing_page_or_url_sk.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_clicks_missing_products = PythonOperator(
	task_id         = 'dq_click_event_clicks_missing_products',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_clicks_missing_products.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_pl_count_change_wow = PythonOperator(
	task_id         = 'dq_click_event_pl_count_change_wow',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_pl_count_change_wow.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_smb_count_change_wow = PythonOperator(
	task_id         = 'dq_click_event_smb_count_change_wow',
	python_callable = dq_check_call,
	op_args         = ['/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_smb_count_change_wow.json'],
	provide_context = True,
	dag             = dag
)

task_dq_click_event_max_work.set_upstream(task_start_job)
task_dq_click_event_max_work.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_work.set_upstream(task_start_job)
task_dq_click_event_work.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_day_mismatch.set_upstream(task_start_job)
task_dq_click_event_day_mismatch.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_hr_mismatch.set_upstream(task_start_job)
task_dq_click_event_hr_mismatch.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_compare_match_by_day_pct.set_upstream(task_start_job)
task_dq_click_event_compare_match_by_day_pct.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_clicks_missing_page_or_url_sk.set_upstream(task_start_job)
task_dq_click_event_clicks_missing_page_or_url_sk.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_clicks_missing_products.set_upstream(task_start_job)
task_dq_click_event_clicks_missing_products.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_pl_count_change_wow.set_upstream(task_start_job)
task_dq_click_event_pl_count_change_wow.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_dq_click_event_smb_count_change_wow.set_upstream(task_start_job)
task_dq_click_event_smb_count_change_wow.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)
