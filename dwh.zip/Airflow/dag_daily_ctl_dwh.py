import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_ctl_dwh"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 12, 4),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval='0 7,15,23 * * *')

task_ctl_counts_json_Stage_Load01 = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/ctl_counts_json_s/shellscripts/ctl_counts_json_s.sh",
    script_args=[],
    task_id='CTL_Counts_Json_Stage_Load01',
    dag=dag)

task_ctl_event_file_tracking_Load01 = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/ctl_event_file_tracking/shellscripts/ctl_event_file_tracking.sh",
    script_args=[],
    task_id='CTL_Event_File_Tracking_Load01',
    dag=dag)

task_ctl_event_file_tracking_Load01.set_upstream(task_ctl_counts_json_Stage_Load01)
