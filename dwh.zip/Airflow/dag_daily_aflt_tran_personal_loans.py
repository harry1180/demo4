import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_aflt_tran_personal_loans"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2016,07,31),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(5,15),
    task_id='Initiating_start_time',
    dag=dag)

Task_ClickEvent_dependency = ExternalTaskSensor(
    task_id='waiting_for_ClickEvent_fact_load',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

task_dag_daily_identity_dependency = ExternalTaskSensor(
    task_id='dag_daily_identity.dw_user_actvy_smry_f',
    external_dag_id='dag_daily_identity',
    external_task_id='dw_user_actvy_smry_f',
    allowed_states=['success', 'failed'],
    dag=dag)

task01_script="/data/etl/Scripts/dw_aflt_tran_growth_sofi_f/shellscripts/dw_aflt_tran_growth_sofi_f.sh"
task01_aflt_tran_sofi_pl = NWBashScriptOperator(
    bash_script=task01_script,
    script_args=[],
    task_id='aflt_tran_sofi_pl',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task1_script="/data/etl/Scripts/aflt_tran_preprocess_personal_loans/shellscripts/aflt_tran_preprocess_personal_loans.sh"
task1_aflt_tran_preprocess_personal_loans = NWBashScriptOperator(
    bash_script=task1_script,
    script_args=[],
    task_id='aflt_tran_preprocess_personal_loans',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task2_script="/data/etl/Scripts/aflt_tran_process_personal_loans/shellscripts/aflt_tran_process_personal_loans.sh"
task2_aflt_tran_process_personal_loans = NWBashScriptOperator(
    bash_script=task2_script,
    script_args=["yes", "redshift"],
    task_id='aflt_tran_process_personal_loans',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task3_script="/data/etl/Scripts/aflt_tran_personal_loan_s_redshift/shellscripts/aflt_tran_personal_loan_s_redshift.sh"
task3_aflt_tran_personal_loan_s_redshift = NWBashScriptOperator(
    bash_script=task3_script,
    script_args=[],
    task_id='aflt_tran_personal_loan_s_redshift',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task4_script="/data/etl/Scripts/dw_aflt_tran_personal_loans_f/shellscripts/dw_aflt_tran_personal_loans_f.sh"
task4_dw_aflt_tran_personal_loans_f = NWBashScriptOperator(
    bash_script=task4_script,
    script_args=[],
    task_id='dw_aflt_tran_personal_loans_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)


task01_aflt_tran_sofi_pl.set_upstream(task_start_job)
task01_aflt_tran_sofi_pl.set_upstream(Task_ClickEvent_dependency)
task1_aflt_tran_preprocess_personal_loans.set_upstream(task01_aflt_tran_sofi_pl)
task2_aflt_tran_process_personal_loans.set_upstream(task1_aflt_tran_preprocess_personal_loans)
task3_aflt_tran_personal_loan_s_redshift.set_upstream(task2_aflt_tran_process_personal_loans)
task4_dw_aflt_tran_personal_loans_f.set_upstream(task3_aflt_tran_personal_loan_s_redshift)
task4_dw_aflt_tran_personal_loans_f.set_upstream(task_dag_daily_identity_dependency)
