import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_pud_identity_non_core"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 1, 23),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(1,30),
    task_id='Initiating_start_time',
    dag=dag)
    
Task_TU_Credit_Report_load_dependency = ExternalTaskSensor(
    task_id='waiting_for_TU_Credit_Report_Load',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_identity_tu_credit_rprt_profile_d',
    dag=dag)
    

task_idb_tu_tradeline_s_script="/data/etl/Scripts/idb_tu_tradeline_s/shellscripts/idb_tu_tradeline_s.sh"
task_idb_tu_tradeline_s = NWBashScriptOperator(
    bash_script=task_idb_tu_tradeline_s_script,
    script_args=[],
    task_id='idb_tu_tradeline_s',
    dag=dag)

task_dw_identity_tu_trdln_snap_f_script="/data/etl/Scripts/dw_identity_tu_trdln_snap_f/shellscripts/dw_identity_tu_trdln_snap_f.sh"
task_dw_identity_tu_trdln_snap_f = NWBashScriptOperator(
    bash_script=task_dw_identity_tu_trdln_snap_f_script,
    script_args=[],
    task_id='dw_identity_tu_trdln_snap_f',
    dag=dag)   
    
task_idb_tu_tradeline_s.set_upstream(task_start_job)
task_idb_tu_tradeline_s.set_upstream(Task_TU_Credit_Report_load_dependency)
task_dw_identity_tu_trdln_snap_f.set_upstream(task_idb_tu_tradeline_s)
#task_dw_identity_tu_trdln_snap_f.set_upstream(Task_TU_Credit_Report_load_dependency)

