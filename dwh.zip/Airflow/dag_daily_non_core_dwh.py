from datetime import datetime, timedelta,time

from airflow import DAG
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_non_core_dwh"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2015, 11, 12),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@daily')

task_start_job = TimeSensor(
    target_time=time(1, 0),
    task_id='Initiating_start_time',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_pbclass_PageViewEvent_s = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.pbclass_PageViewEvent_s',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='pbclass_PageViewEvent_s',
    dag=dag)

task_status_update_aflt_tran = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.status_update',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='status_update',
    dag=dag)

task_baidag_dashboard_milestones_handshake = ExternalTaskSensor(
    task_id='baidag__dashboard_milestones.bai_dwh_vacuum_ready_handshake',
    external_dag_id='baidag__dashboard_milestones',
    external_task_id='bai_dwh_vacuum_ready_handshake',
    dag=dag)
task_baidag_dashboard_milestones_handshake.set_upstream(task_start_job)

###########################################################################
# Command tasks
###########################################################################
task_dw_marketplace_traffic_gs = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_marketplace_traffic_gs/shellscripts/dw_marketplace_traffic_gs.sh',
    script_args=[],
    task_id='dw_marketplace_traffic_gs',
    dag=dag)
task_dw_marketplace_traffic_gs.set_upstream(task_baidag_dashboard_milestones_handshake)

task4_script="/data/etl/Scripts/dw_twilio_call_logs_f/shellscripts/dw_twilio_call_logs_f.sh"
task4_twilio_call_logs = NWBashScriptOperator(
    bash_script=task4_script,
    script_args=[],
    task_id='twilio_call_logs',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)


# task5_script="/data/etl/Scripts/dw_zendesk_tickets_f/shellscripts/dw_zendesk_tickets_f.sh"
# task5_zendesk_load = NWBashScriptOperator(
#     bash_script=task5_script,
#     script_args=[],
#     task_id='zendesk_load',
#     dag=dag)

task10_script="/data/etl/Scripts/zopim/shellscripts/zopim_load.sh"
task10_zopim_load = NWBashScriptOperator(
    bash_script=task10_script,
    script_args=[],
    task_id='zopim_load',
    dag=dag)

task11_script="/data/etl/Scripts/dw_zopim_chat_f/shellscripts/dw_zopim_chat_f_load.sh"
task11_zopim_chat_f = NWBashScriptOperator(
    bash_script=task11_script,
    script_args=[],
    task_id='zopim_chat_f',
    pool='redshift_etl',
    dag=dag)

task12_script="/data/etl/Scripts/dw_zopim_chat_sessions_f/shellscripts/dw_zopim_chat_sessions_f_load.sh"
task12_zopim_chat_sessions_f = NWBashScriptOperator(
    bash_script=task12_script,
    script_args=[],
    task_id='zopim_chat_sessions_f',
    pool='redshift_etl',
    dag=dag)

task14_script="/data/etl/Common/redshift_sql_function.sh"
task14_status_update = NWBashScriptOperator(
    bash_script=task14_script,
    script_args=["/data/etl/Airflow/post_updates/dag_daily_non_core_dwh_status_update.sql"],
    task_id='status_update',
    dag=dag)

# task16_script="/data/etl/Scripts/zendesk/shellscripts/zendesk_ticket_custom_fields_load.sh"
# task16_zendesk_custom_fields = NWBashScriptOperator(
#     bash_script=task16_script,
#     script_args=[],
#     task_id='zendesk_custom_fields',
#     dag=dag)

task_amp_load_transaction_event = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/amp_load_transaction_event/shellscripts/amp_load_transaction_event.sh",
    script_args=[],
    task_id='amp_load_transaction_event',
    pool='redshift_etl',
    dag=dag)
    
task_amp_load_user_property = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/amp_load_user_property/shellscripts/amp_load_user_property.sh",
    script_args=[],
    task_id='amp_load_user_property',
    pool='redshift_etl',
    dag=dag)

task_mrtg_gs_load_dwh= NWBashScriptOperator(
    bash_script="/data/etl/Scripts/mrtg_gs_load_dwh/shellscripts/mrtg_gs_load_dwh.sh",
    script_args=[],
    task_id='mrtg_gs_load_dwh',
    pool='redshift_etl',
    dag=dag)

task_dw_mbl_dvc_d = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_mbl_dvc_d/shellscripts/dw_mbl_dvc_d.sh",
    script_args=[],
    task_id='dw_mbl_dvc_d',
    pool='redshift_etl',
    dag=dag)

task17_script="/data/etl/Scripts/livechat/shellscripts/livechat_load.sh"
task17_livechat_load = NWBashScriptOperator(
    bash_script=task17_script,
    script_args=[],
    task_id='livechat_load',
    pool='redshift_etl',
    dag=dag)

task18_script="/data/etl/Scripts/dw_livechat_f/shellscripts/dw_livechat_load.sh"
task18_livechat_f = NWBashScriptOperator(
    bash_script=task18_script,
    script_args=[],
    task_id='dw_livechat_f',
    pool='redshift_etl',
    dag=dag)

task19_script="/data/etl/Scripts/dw_wt_csat_svy_rsp_f/shellscripts/dw_wt_csat_svy_rsp_f.sh"
task19_dw_wt_csat_svy_rsp_f = NWBashScriptOperator(
    bash_script=task19_script,
    script_args=[],
    task_id='dw_wt_csat_svy_rsp_f',
    pool='redshift_etl',
    dag=dag)

task20_script="/data/etl/Scripts/dw_wt_csat_svy_expsr_f/shellscripts/dw_wt_csat_svy_expsr_f.sh"
task20_dw_wt_csat_svy_expsr_f = NWBashScriptOperator(
    bash_script=task20_script,
    script_args=[],
    task_id='dw_wt_csat_svy_expsr_f',
    pool='redshift_etl',
    dag=dag)

task_cc_propensity_model = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/cc_propensity_model/shellscripts/cc_propensity_model.sh',
    script_args=[],
    task_id='cc_propensity_model',
    pool='redshift_etl',
    dag=dag)
task_cc_propensity_model.set_upstream(task_status_update_aflt_tran)

task4_twilio_call_logs.set_upstream(task_start_job)
task4_twilio_call_logs.set_upstream(task_status_update_aflt_tran)

# task5_zendesk_load.set_upstream(task_start_job)
# task5_zendesk_load.set_upstream(task_status_update_aflt_tran)

task10_zopim_load.set_upstream(task_start_job)
task10_zopim_load.set_upstream(task_status_update_aflt_tran)

task11_zopim_chat_f.set_upstream(task10_zopim_load)

task12_zopim_chat_sessions_f.set_upstream(task11_zopim_chat_f)

# task16_zendesk_custom_fields.set_upstream(task5_zendesk_load)

task17_livechat_load.set_upstream(task_start_job)
task17_livechat_load.set_upstream(task_status_update_aflt_tran)
task18_livechat_f.set_upstream(task17_livechat_load)

task_amp_load_transaction_event.set_upstream(task_start_job)
task_amp_load_transaction_event.set_upstream(task_status_update_aflt_tran)

task_amp_load_user_property.set_upstream(task_start_job)
task_amp_load_user_property.set_upstream(task_status_update_aflt_tran)

task_mrtg_gs_load_dwh.set_upstream(task_start_job)
task_mrtg_gs_load_dwh.set_upstream(task_status_update_aflt_tran)

task_dw_mbl_dvc_d.set_upstream(task_pbclass_PageViewEvent_s)
task_dw_mbl_dvc_d.set_upstream(task_status_update_aflt_tran)

task14_status_update.set_upstream(task4_twilio_call_logs)
#task14_status_update.set_upstream(task12_zopim_chat_sessions_f)

task19_dw_wt_csat_svy_rsp_f.set_upstream(task_start_job)
task19_dw_wt_csat_svy_rsp_f.set_upstream(task_status_update_aflt_tran)

task20_dw_wt_csat_svy_expsr_f.set_upstream(task_start_job)
task20_dw_wt_csat_svy_expsr_f.set_upstream(task19_dw_wt_csat_svy_rsp_f)
