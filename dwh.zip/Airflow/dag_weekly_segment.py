import sys
from datetime import *
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_weekly_segment"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime.now(),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 0,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@weekly')

task_start_job = TimeSensor(
    target_time=time(14,15),
    task_id='Initiating_start_time',
    dag=dag)


task_member_segment_script="/data/etl/Scripts/dw_user_sgmt_f/shellscripts/dw_user_sgmt_f.sh"
task_member_segment_weekly = NWBashScriptOperator(
    bash_script=task_member_segment_script,
    script_args=['weekly'],
    task_id='member_segment_weekly',
    dag=dag)


task_member_segment_weekly.set_upstream(task_start_job)
