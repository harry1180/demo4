from datetime import datetime, timedelta, time

from airflow import DAG
from airflow.operators import NWBashScriptOperator, DummyOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_wordpress'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 5, 13),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

task_start_wordpress_db_extract = TimeSensor(
    target_time=time(8, 15),
    task_id='WordPress_DB_Extract_Start',
    dag=dag)
task_start_wordpress_db_extract.set_upstream(task_start_dag)

################################################################################
# REST API extracts
################################################################################
task_wp_categories_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_categories_s/shellscripts/wp_categories_s.sh',
    script_args=[],
    task_id='wp_categories_s',
    dag=dag)
task_wp_categories_s.set_upstream(task_start_dag)

task_wordpress_api_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_wp_posts_api_s/shellscripts/dw_wp_posts_api_s_nerdlake.sh',
    script_args=[],
    task_id='wordpress_api_s',
    pool='redshift_etl',
    dag=dag)
task_wordpress_api_s.set_upstream(task_start_dag)

################################################################################
# Derived tables
################################################################################
task_wp_category_d_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_category_d_nerdlake/shellscripts/wp_category_d_nerdlake.sh',
    script_args=[],
    task_id='wp_category_d_nerdlake',
    trigger_rule='all_done',  # This job pulls the most recent set of data that's in the staging table
    pool='presto_etl',
    dag=dag)
task_wp_category_d_nerdlake.set_upstream(task_wp_categories_s)

task_wp_content_d_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_content_d_nerdlake/shellscripts/wp_content_d_nerdlake.sh',
    script_args=[],
    task_id='wp_content_d_nerdlake',
    trigger_rule='all_done',  # This job pulls the most recent set of data that's in the staging table
    pool='presto_etl',
    dag=dag)
task_wp_content_d_nerdlake.set_upstream(task_wordpress_api_s)
task_wp_content_d_nerdlake.set_upstream(task_wp_category_d_nerdlake)

################################################################################
# Copy objects between Redshift and NerdLake
################################################################################
task_wp_category_w = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_category_w/shellscripts/wp_category_w.sh',
    script_args=[],
    task_id='wp_category_w',
    pool='presto_etl',
    dag=dag)
task_wp_category_w.set_upstream(task_wp_category_d_nerdlake)

task_dw_wp_category_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_wp_category_d/shellscripts/dw_wp_category_d.sh',
    script_args=[],
    task_id='dw_wp_category_d',
    pool='redshift_etl',
    priority_weight=100,  # Needed for core Redshift processing
    dag=dag)
task_dw_wp_category_d.set_upstream(task_wp_category_w)

task_wp_latest_taxonomy_w = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_latest_taxonomy_w/shellscripts/wp_latest_taxonomy_w.sh',
    script_args=[],
    task_id='wp_latest_taxonomy_w',
    pool='presto_etl',
    dag=dag)
task_wp_latest_taxonomy_w.set_upstream(task_wp_content_d_nerdlake)
task_wp_latest_taxonomy_w.set_upstream(task_wp_category_d_nerdlake)

task_wp_latest_taxonomy_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_latest_taxonomy_s/shellscripts/wp_latest_taxonomy_s.sh',
    script_args=[],
    task_id='wp_latest_taxonomy_s',
    pool='redshift_etl',
    dag=dag)
task_wp_latest_taxonomy_s.set_upstream(task_wp_latest_taxonomy_w)

################################################################################
# Derive WordPress tables on Redshift
################################################################################
task_dw_wp_content_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_wp_content_d/shellscripts/dw_wp_content_d.sh',
    script_args=[],
    task_id='dw_wp_content_d',
    pool='redshift_etl',
    priority_weight=100,  # Needed for core Redshift processing
    dag=dag)
task_dw_wp_content_d.set_upstream(task_wp_latest_taxonomy_s)

################################################################################
# MySQL extracts and processing (deprecated)
################################################################################
task_dw_wp_instance_d_script="/data/etl/Scripts/dw_wp_instance_d/shellscripts/dw_wp_instance_d.sh"
task_dw_wp_instance_d = NWBashScriptOperator(
    bash_script=task_dw_wp_instance_d_script,
    script_args=[],
    task_id='dw_wp_instance_d',
    dag=dag)

task_dw_wp_options_d_script="/data/etl/Scripts/dw_wp_options_d/shellscripts/dw_wp_options_d.sh"
task_dw_wp_options_d = NWBashScriptOperator(
    bash_script=task_dw_wp_options_d_script,
    script_args=[],
    task_id='dw_wp_options_d',
    dag=dag)

task_dw_wp_post_meta_d_script="/data/etl/Scripts/dw_wp_post_meta_d/shellscripts/dw_wp_post_meta_d.sh"
task_dw_wp_post_meta_d = NWBashScriptOperator(
    bash_script=task_dw_wp_post_meta_d_script,
    script_args=[],
    task_id='dw_wp_post_meta_d',
    dag=dag)

task_dw_wp_post_term_taxonomy_xref_script="/data/etl/Scripts/dw_wp_post_term_taxonomy_xref/shellscripts/dw_wp_post_term_taxonomy_xref.sh"
task_dw_wp_post_term_taxonomy_xref = NWBashScriptOperator(
    bash_script=task_dw_wp_post_term_taxonomy_xref_script,
    script_args=[],
    task_id='dw_wp_post_term_taxonomy_xref',
    dag=dag)

task_dw_wp_terms_d_script="/data/etl/Scripts/dw_wp_terms_d/shellscripts/dw_wp_terms_d.sh"
task_dw_wp_terms_d = NWBashScriptOperator(
    bash_script=task_dw_wp_terms_d_script,
    script_args=[],
    task_id='dw_wp_terms_d',
    dag=dag)

task_dw_wp_thesis_terms_d_script="/data/etl/Scripts/dw_wp_thesis_terms_d/shellscripts/dw_wp_thesis_terms_d.sh"
task_dw_wp_thesis_terms_d = NWBashScriptOperator(
    bash_script=task_dw_wp_thesis_terms_d_script,
    script_args=[],
    task_id='dw_wp_thesis_terms_d',
    dag=dag)

task_dw_wp_users_d_script="/data/etl/Scripts/dw_wp_users_d/shellscripts/dw_wp_users_d.sh"
task_dw_wp_users_d = NWBashScriptOperator(
    bash_script=task_dw_wp_users_d_script,
    script_args=[],
    task_id='dw_wp_users_d',
    dag=dag)

task_dw_wp_term_taxonomy_d_script="/data/etl/Scripts/dw_wp_term_taxonomy_d/shellscripts/dw_wp_term_taxonomy_d.sh"
task_dw_wp_term_taxonomy_d = NWBashScriptOperator(
    bash_script=task_dw_wp_term_taxonomy_d_script,
    script_args=[],
    task_id='dw_wp_term_taxonomy_d',
    dag=dag)

task_dw_wp_posts_d_script="/data/etl/Scripts/dw_wp_posts_d/shellscripts/dw_wp_posts_d.sh"
task_dw_wp_posts_d = NWBashScriptOperator(
    bash_script=task_dw_wp_posts_d_script,
    script_args=[],
    task_id='dw_wp_posts_d',
    dag=dag)

task_dw_wp_edit_flow_meta_xref_script="/data/etl/Scripts/dw_wp_edit_flow_meta_xref/shellscripts/dw_wp_edit_flow_meta_xref.sh"
task_dw_wp_edit_flow_meta_xref = NWBashScriptOperator(
    bash_script=task_dw_wp_edit_flow_meta_xref_script,
    script_args=[],
    task_id='dw_wp_edit_flow_meta_xref',
    dag=dag)

task_dw_wp_post_url_page_xref_script="/data/etl/Scripts/dw_wp_post_url_page_xref/shellscripts/dw_wp_post_url_page_xref.sh"
task_dw_wp_post_url_page_xref = NWBashScriptOperator(
    bash_script=task_dw_wp_post_url_page_xref_script,
    script_args=[],
    task_id='dw_wp_post_url_page_xref',
    dag=dag)

task_dw_wp_cntnt_post_d_script="/data/etl/Scripts/dw_wp_cntnt_post_d/shellscripts/dw_wp_cntnt_post_d.sh"
task_dw_wp_cntnt_post_d = NWBashScriptOperator(
    bash_script=task_dw_wp_cntnt_post_d_script,
    script_args=[],
    task_id='dw_wp_cntnt_post_d',
    dag=dag)

task_dw_wp_posts_api_s_script="/data/etl/Scripts/dw_wp_posts_api_s/shellscripts/dw_wp_posts_api_s.sh"
task_dw_wp_posts_api_s = NWBashScriptOperator(
    bash_script=task_dw_wp_posts_api_s_script,
    script_args=[],
    task_id='dw_wp_posts_api_s',
    dag=dag)

task_dw_wp_posts_api_d_script="/data/etl/Scripts/dw_wp_posts_api_d/shellscripts/dw_wp_posts_api_d.sh"
task_dw_wp_posts_api_d = NWBashScriptOperator(
    bash_script=task_dw_wp_posts_api_d_script,
    script_args=[],
    task_id='dw_wp_posts_api_d',
    dag=dag)

task_wordpress_load = DummyOperator(
    task_id='task_wordpress_load',
    dag=dag)

Task_core_complete_dependency = ExternalTaskSensor(
    task_id='waiting_for_core_complete_load',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    dag=dag)

task_dw_wp_instance_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_instance_d.set_upstream(task_dw_wp_options_d)
task_dw_wp_options_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_post_meta_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_post_term_taxonomy_xref.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_terms_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_thesis_terms_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_users_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_term_taxonomy_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_posts_api_s.set_upstream(task_start_dag)
task_dw_wp_posts_api_d.set_upstream(task_dw_wp_posts_api_s)
task_dw_wp_posts_d.set_upstream(task_start_wordpress_db_extract)
task_dw_wp_posts_d.set_upstream(task_dw_wp_instance_d)
task_dw_wp_posts_d.set_upstream(task_dw_wp_term_taxonomy_d)
task_dw_wp_posts_d.set_upstream(task_dw_wp_terms_d)
task_dw_wp_posts_d.set_upstream(task_dw_wp_post_term_taxonomy_xref)

task_dw_wp_edit_flow_meta_xref.set_upstream(task_dw_wp_posts_d)
task_dw_wp_edit_flow_meta_xref.set_upstream(task_dw_wp_users_d)
task_dw_wp_edit_flow_meta_xref.set_upstream(task_dw_wp_post_meta_d)

task_dw_wp_post_url_page_xref.set_upstream(task_dw_wp_posts_d)
task_dw_wp_post_url_page_xref.set_upstream(task_dw_wp_post_term_taxonomy_xref)
task_dw_wp_post_url_page_xref.set_upstream(task_dw_wp_terms_d)
task_dw_wp_post_url_page_xref.set_upstream(task_dw_wp_instance_d)
task_dw_wp_post_url_page_xref.set_upstream(Task_core_complete_dependency)

task_wordpress_load.set_upstream(task_dw_wp_instance_d)
task_wordpress_load.set_upstream(task_dw_wp_options_d)
task_wordpress_load.set_upstream(task_dw_wp_post_meta_d)
task_wordpress_load.set_upstream(task_dw_wp_post_term_taxonomy_xref)
task_wordpress_load.set_upstream(task_dw_wp_terms_d)
task_wordpress_load.set_upstream(task_dw_wp_thesis_terms_d)
task_wordpress_load.set_upstream(task_dw_wp_users_d)
task_wordpress_load.set_upstream(task_dw_wp_term_taxonomy_d)
task_wordpress_load.set_upstream(task_dw_wp_posts_d)
task_wordpress_load.set_upstream(task_dw_wp_edit_flow_meta_xref)
task_wordpress_load.set_upstream(task_dw_wp_post_url_page_xref)
task_wordpress_load.set_upstream(task_dw_wp_posts_api_d)

task_dw_wp_cntnt_post_d.set_upstream(task_wordpress_load)
