from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators import NWBashScriptOperator

dag_name = 'dag_hourly_nerdlake_aflt_tran'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 7, 15),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=5),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')

task_aflt_tran_process_cc_file = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_process_cc/shellscripts/aflt_tran_process_cc_file.sh',
    script_args=[],
    task_id='aflt_tran_process_cc_file',
    execution_timeout=timedelta(minutes=25),  # May not be needed anymore since this job is no longer PySpark
    dag=dag)

task_aflt_tran_load_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_nerdlake/shellscripts/aflt_tran_nerdlake.sh',
    script_args=[],
    task_id='aflt_tran_load_nerdlake',
    trigger_rule='all_done',
    pool='presto_etl',
    dag=dag)
task_aflt_tran_load_nerdlake.set_upstream(task_aflt_tran_process_cc_file)
