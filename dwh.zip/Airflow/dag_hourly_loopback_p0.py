from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators import BashOperator, DummyOperator, NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor, TimeSensor

dag_name = 'dag_hourly_loopbacks_p0'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 6, 26),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=10),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')

task_dynamodb_cdc_materialize_visitor_tokens = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_dynamodb_cdc_p0.materialize_udp-visitor_tokens',
    external_dag_id='dag_hourly_nerdlake_dynamodb_cdc_p0',
    external_task_id='materialize_udp-visitor_tokens',
    dag=dag)

task_dw_actvy_f_nerdlake_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_core_p0.dw_actvy_f_nerdlake_load',
    external_dag_id='dag_hourly_nerdlake_core_p0',
    external_task_id='dw_actvy_f_nerdlake_load',
    dag=dag)

task_dynamodb_udp_visitor_tokens_dedup_w = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dynamodb_udp_visitor_tokens_dedup_w/shellscripts/dynamodb_udp_visitor_tokens_dedup_w.sh',
    script_args=[],
    task_id='dynamodb_udp_visitor_tokens_dedup_w',
    pool='presto_etl',
    dag=dag)
task_dynamodb_udp_visitor_tokens_dedup_w.set_upstream(task_dynamodb_cdc_materialize_visitor_tokens)

task_loopback_dwh_udp_vstr_prod_shp_actn = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_vstr_prod_shp_actn/shellscripts/loopback_dwh_udp_vstr_prod_shp_actn.sh',
    script_args=[],
    task_id='loopback_dwh_udp_vstr_prod_shp_actn',
    pool='presto_etl',
    dag=dag)
task_loopback_dwh_udp_vstr_prod_shp_actn.set_upstream(task_dynamodb_udp_visitor_tokens_dedup_w)
task_loopback_dwh_udp_vstr_prod_shp_actn.set_upstream(task_dw_actvy_f_nerdlake_load)
