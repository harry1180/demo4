from datetime import datetime, timedelta, time
import os
import sys

from airflow import DAG
import airflow.operators
from airflow.operators import DummyOperator
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_complete_dwh_vacuum'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=2),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

task_baidag_dashboards_complete_dependency = ExternalTaskSensor(
    task_id='baidag__dashboard_milestones.bai_dwh_vacuum_ready_handshake',
    external_dag_id='baidag__dashboard_milestones',
    external_task_id='bai_dwh_vacuum_ready_handshake',
    poke_interval=300,  # Check every 5 minutes
    dag=dag)
task_baidag_dashboards_complete_dependency.set_upstream(task_start_dag)

task_dwh_complete_vacuum = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dwh_complete_vacuum/shellscripts/dwh_complete_vacuum.sh',
    script_args=[],
    task_id='dwh_complete_vacuum',
    pool='redshift_vacuum',
    priority_weight=4,
    dag=dag)
task_dwh_complete_vacuum.set_upstream(task_baidag_dashboards_complete_dependency)

task_dwh_workarea_vacuum = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dwh_complete_vacuum/shellscripts/dwh_workarea_vacuum.sh',
    script_args=[],
    task_id='dwh_workarea_vacuum',
    pool='redshift_vacuum',
    priority_weight=2,
    dag=dag)
task_dwh_workarea_vacuum.set_upstream(task_baidag_dashboards_complete_dependency)

task_dwh_bai_vacuum = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dwh_complete_vacuum/shellscripts/dwh_bai_vacuum.sh',
    script_args=[],
    task_id='dwh_bai_vacuum',
    pool='redshift_vacuum',
    priority_weight=3,
    dag=dag)
task_dwh_bai_vacuum.set_upstream(task_baidag_dashboards_complete_dependency)

task_dwh_stage_vacuum = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dwh_complete_vacuum/shellscripts/dwh_stage_vacuum.sh',
    script_args=[],
    task_id='dwh_stage_vacuum',
    pool='redshift_vacuum',
    dag=dag)
task_dwh_stage_vacuum.set_upstream(task_baidag_dashboards_complete_dependency)

task_dwh_delete_vacuum = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dwh_complete_vacuum/shellscripts/dwh_delete_only_vacuum.sh',
    script_args=[],
    task_id='dwh_delete_vacuum',
    pool='redshift_vacuum',
    dag=dag)
task_dwh_delete_vacuum.set_upstream(task_baidag_dashboards_complete_dependency)

task_dwh_complete_analyze = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dwh_complete_analyze/shellscripts/dwh_complete_analyze.sh',
    script_args=[],
    task_id='dwh_complete_analyze',
    dag=dag)
task_dwh_complete_analyze.set_upstream(task_dwh_complete_vacuum)
task_dwh_complete_analyze.set_upstream(task_dwh_bai_vacuum)
task_dwh_complete_analyze.set_upstream(task_dwh_workarea_vacuum)
task_dwh_complete_analyze.set_upstream(task_dwh_stage_vacuum)
task_dwh_complete_analyze.set_upstream(task_dwh_delete_vacuum)

task_dag_status_update = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_sql_function.sh',
    script_args=['/data/etl/Airflow/post_updates/dag_complete_dwh_vacuum.sql'],
    task_id='status_update',
    dag=dag)
task_dag_status_update.set_upstream(task_dwh_complete_analyze)
