from datetime import datetime, timedelta,time

from airflow import DAG
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_marketing_non_core"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2016, 2, 23),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@daily')

task_mktg_core_dependency =  ExternalTaskSensor(
    task_id = 'waiting_for_mktg_core',
    external_dag_id = 'dag_daily_marketing',
    external_task_id = 'status_update',
    dag = dag)

task_mktg_mta_dependency =  ExternalTaskSensor(
    task_id = 'waiting_for_mta_dag',
    external_dag_id = 'dag_daily_marketing_mta',
    external_task_id = 'mktg_mta_status_update',
    dag = dag)

task_mktg_sst_dependency =  ExternalTaskSensor(
    task_id = 'baidag_mktg_sst.aggs_done',
    external_dag_id = 'baidag_mktg_sst',
    external_task_id = 'aggs_done',
    dag = dag)

task_start_job_bluekai = TimeSensor(
    target_time=time(11, 5),
    task_id='Initiating_start_time_UTC_11_PDT_04',
    dag=dag)

task_start_job_mktg_utc02 = TimeSensor(
    target_time=time(2, 5),
    task_id='mktg_digital_start_time_UTC_02_PST_18',
    dag=dag)

# task_start_job_mktg_utc18 = TimeSensor(
#     target_time=time(18, 5),
#     task_id='mktg_digital_start_time_UTC_18_PST_11',
#     dag=dag)

task_start_job_mktg_utc01 = TimeSensor(
    target_time=time(1, 5),
    task_id='mktg_digital_start_time_UTC_01_PDT_18',
    dag=dag)

task_start_job_mktg_mailchimp_utc01 = TimeSensor(
    target_time=time(1, 5),
    task_id='mktg_digital_mailchimp_start_time_UTC_01_PDT_18',
    dag=dag)

task_start_job_mktg_utc02.set_upstream(task_mktg_core_dependency)
task_start_job_bluekai.set_upstream(task_mktg_core_dependency)

########################################################  dianomi #########################################################
#task_dianomi_upload_script="/data/etl/Scripts/mktg_dianomi_upload/shellscripts/mktg_dianomi_upload.sh"
#task_dianomi_upload = NWBashScriptOperator(
#    bash_script=task_dianomi_upload_script,
#    script_args=[],
#    task_id='mktg_dianomi_upload',
#    dag=dag)

#task_dianomi_upload.set_upstream(task_start_job_dianomi_dwh)


######################################################## Yahoo #########################################################

task_mktg_yahoo_search_perf_f_script = "/data/etl/Scripts/mktg_yahoo_search_perf_f/shellscripts/mktg_yahoo_search_perf_f.sh"
task_mktg_yahoo_search_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_yahoo_search_perf_f_script,
    script_args=[],
    task_id='mktg_yahoo_search_perf_f',
    dag=dag)

task_mktg_yahoo_user_perf_f_script = "/data/etl/Scripts/mktg_yahoo_user_perf_f/shellscripts/mktg_yahoo_user_perf_f.sh"
task_mktg_yahoo_user_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_yahoo_user_perf_f_script,
    script_args=[],
    task_id='mktg_yahoo_user_perf_f',
    dag=dag)


task_mktg_yahoo_search_perf_f.set_upstream(task_start_job_mktg_utc02)
task_mktg_yahoo_user_perf_f.set_upstream(task_mktg_yahoo_search_perf_f)

######################################################## Google non-core #########################################################


task_marketing_google_script="/data/etl/Scripts/marketing_google/shellscripts/marketing_google_to_json.sh"
task_marketing_google = NWBashScriptOperator(
    bash_script=task_marketing_google_script,
    script_args=[],
    task_id='marketing_google',
    dag=dag)

task_mktg_goog_campaign_conv_f_script="/data/etl/Scripts/mktg_goog_campaign_conv_f/shellscripts/mktg_goog_campaign_conv_f.sh"
task_mktg_goog_campaign_conv_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_campaign_conv_f_script,
    script_args=[],
    task_id='mktg_goog_campaign_conv_f',
    dag=dag)

task_mktg_goog_paid_vs_org_f_script="/data/etl/Scripts/mktg_goog_paid_vs_org_f/shellscripts/mktg_goog_paid_vs_org_f.sh"
task_mktg_goog_paid_vs_org_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_paid_vs_org_f_script,
    script_args=[],
    task_id='mktg_goog_paid_vs_org_f',
    dag=dag)

task_mktg_goog_sq_perf_f_script="/data/etl/Scripts/mktg_goog_sq_perf_f/shellscripts/mktg_goog_sq_perf_f.sh"
task_mktg_goog_sq_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_sq_perf_f_script,
    script_args=[],
    task_id='mktg_goog_sq_perf_f',
    dag=dag)

task_mktg_goog_sq_conv_f_script="/data/etl/Scripts/mktg_goog_sq_conv_f/shellscripts/mktg_goog_sq_conv_f.sh"
task_mktg_goog_sq_conv_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_sq_conv_f_script,
    script_args=[],
    task_id='mktg_goog_sq_conv_f',
    dag=dag)

task_mktg_goog_gender_perf_f_script="/data/etl/Scripts/mktg_goog_gender_perf_f/shellscripts/mktg_goog_gender_perf_f.sh"
task_mktg_goog_gender_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_gender_perf_f_script,
    script_args=[],
    task_id='mktg_goog_gender_perf_f',
    dag=dag)

task_mktg_goog_gender_conv_f_script="/data/etl/Scripts/mktg_goog_gender_conv_f/shellscripts/mktg_goog_gender_conv_f.sh"
task_mktg_goog_gender_conv_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_gender_conv_f_script,
    script_args=[],
    task_id='mktg_goog_gender_conv_f',
    dag=dag)

task_marketing_google.set_upstream(task_start_job_mktg_utc02)
task_mktg_goog_campaign_conv_f.set_upstream(task_marketing_google)
task_mktg_goog_paid_vs_org_f.set_upstream(task_marketing_google)
task_mktg_goog_sq_perf_f.set_upstream(task_mktg_goog_paid_vs_org_f)
task_mktg_goog_sq_conv_f.set_upstream(task_mktg_goog_paid_vs_org_f)
task_mktg_goog_gender_perf_f.set_upstream(task_mktg_goog_paid_vs_org_f)
task_mktg_goog_gender_conv_f.set_upstream(task_mktg_goog_paid_vs_org_f)


######################################################## Remarketing ###############################################

task_mktg_email_remktg_upload_f_script = "/data/etl/Scripts/mktg_email_remktg_upload_f/shellscripts/mktg_email_remktg_upload_f.sh"
task_mktg_email_remktg_upload_f = NWBashScriptOperator(
    bash_script=task_mktg_email_remktg_upload_f_script,
    script_args=[],
    task_id='mktg_email_remktg_upload_f',
    dag=dag)

task_mktg_goog_adwords_remktg_upload_f_script = "/data/etl/Scripts/mktg_goog_adwords_remktg_upload_f/shellscripts/mktg_goog_adwords_remktg_upload_f.sh"
task_mktg_goog_adwords_remktg_upload = NWBashScriptOperator(
    bash_script=task_mktg_goog_adwords_remktg_upload_f_script,
    script_args=[],
    task_id='mktg_goog_adwords_remktg_upload_f',
    dag=dag)

task_mktg_liveramp_upload_f_script = "/data/etl/Scripts/mktg_liveramp_upload_f/shellscripts/mktg_liveramp_upload_f.sh"
tast_mktg_liveramp_upload = NWBashScriptOperator(
    bash_script=task_mktg_liveramp_upload_f_script,
    script_args=[],
    task_id='mktg_liveramp_upload_f',
    dag=dag)

task_mktg_fb_offline_event_upload_f_script = "/data/etl/Scripts/mktg_fb_offline_event_upload_f/shellscripts/mktg_fb_offline_event_upload_f.sh"
task_mktg_fb_offline_event_upload_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_offline_event_upload_f_script,
    script_args=[],
    task_id='mktg_fb_offline_event_upload_f',
    execution_timeout=timedelta(hours=20),
    dag=dag)


task_mktg_email_remktg_upload_f.set_upstream(task_start_job_mktg_utc02)
task_mktg_goog_adwords_remktg_upload.set_upstream(task_mktg_email_remktg_upload_f)
tast_mktg_liveramp_upload.set_upstream(task_mktg_goog_adwords_remktg_upload)
task_mktg_fb_offline_event_upload_f.set_upstream(task_start_job_mktg_utc01)

######################################################## Mailchimp ###################################################################

task_mktg_mailchimp_email_event_f_script = "/data/etl/Scripts/mktg_mailchimp_email_event_f/shellscripts/mktg_mailchimp_email_event_f.sh"
task_mktg_mailchimp_email_event_f = NWBashScriptOperator(
    bash_script=task_mktg_mailchimp_email_event_f_script,
    script_args=[],
    task_id='mktg_mailchimp_email_event_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_mailchimp_campaign_d_script = "/data/etl/Scripts/mktg_mailchimp_campaign_d/shellscripts/mktg_mailchimp_campaign_d.sh"
task_mktg_mailchimp_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_mailchimp_campaign_d_script,
    script_args=[],
    task_id='mktg_mailchimp_campaign_d',
    pool='redshift_etl',
    dag=dag)

task_mktg_mailchimp_ab_campaign_d_script = "/data/etl/Scripts/mktg_mailchimp_ab_campaign_d/shellscripts/mktg_mailchimp_ab_campaign_d.sh"
task_mktg_mailchimp_ab_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_mailchimp_ab_campaign_d_script,
    script_args=[],
    task_id='mktg_mailchimp_ab_campaign_d',
    pool='redshift_etl',
    dag=dag)

task_mktg_mailchimp_url_perf_f_script = "/data/etl/Scripts/mktg_mailchimp_url_perf_f/shellscripts/mktg_mailchimp_url_perf_f.sh"
task_mktg_mailchimp_url_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_mailchimp_url_perf_f_script,
    script_args=[],
    task_id='mktg_mailchimp_url_perf_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_mailchimp_nps_f_script = "/data/etl/Scripts/mktg_mailchimp_nps_f/shellscripts/mktg_mailchimp_nps_f.sh"
task_mktg_mailchimp_nps_f = NWBashScriptOperator(
    bash_script=task_mktg_mailchimp_nps_f_script,
    script_args=[],
    task_id='mktg_mailchimp_nps_f',
    pool='redshift_etl',
    dag=dag)


task_mktg_mailchimp_email_event_f.set_upstream(task_start_job_mktg_mailchimp_utc01)

task_mktg_mailchimp_campaign_d.set_upstream(task_start_job_mktg_utc01)
task_mktg_mailchimp_ab_campaign_d.set_upstream(task_mktg_mailchimp_campaign_d)
task_mktg_mailchimp_url_perf_f.set_upstream(task_mktg_mailchimp_ab_campaign_d)
task_mktg_mailchimp_nps_f.set_upstream(task_mktg_mailchimp_url_perf_f)
task_mktg_mailchimp_nps_f.set_upstream(task_mktg_mta_dependency)

######################################################## Pinterest #########################################################
# pausing pinterest as of 10/03/2017 - campaign pasued on 10/01/2017
# task_mktg_pinterest_download_script = "/data/etl/Scripts/mktg_pinterest/shellscripts/mktg_pinterest.sh"
# task_mktg_pinterest_download = NWBashScriptOperator(
#       bash_script=task_mktg_pinterest_download_script,
#       script_args=[],
#       task_id='mktg_pinterest',
#       dag=dag)
#
# task_mktg_pinterest_promo_pin_id_perf_f_script = "/data/etl/Scripts/mktg_pinterest_promo_pin_id_perf_f/shellscripts/mktg_pinterest_promo_pin_id_perf_f.sh"
# task_mktg_pinterest_promo_pin_id_perf_f = NWBashScriptOperator(
#       bash_script=task_mktg_pinterest_promo_pin_id_perf_f_script,
#       script_args=[],
#       task_id='mktg_pinterest_promo_pin_id_perf_f',
#       dag=dag)
#
# task_mktg_pinterest_download.set_upstream(task_start_job_mktg_utc18)
# task_mktg_pinterest_promo_pin_id_perf_f.set_upstream(task_mktg_pinterest_download)
#
# task_mktg_pinterest_campaign_perf_f_script = "/data/etl/Scripts/mktg_pinterest_campaign_perf_f/shellscripts/mktg_pinterest_campaign_perf_f.sh"
# task_mktg_pinterest_campaign_perf_f = NWBashScriptOperator(
#       bash_script=task_mktg_pinterest_campaign_perf_f_script,
#       script_args=[],
#       task_id='mktg_pinterest_campaign_perf_f',
#       dag=dag)
#
# task_mktg_pinterest_campaign_perf_f.set_upstream(task_mktg_pinterest_download)

######################################################## Mktg bugdet doc ingestion #########################################################

task_mktg_chnl_spend_gs_f_script = "/data/etl/Scripts/mktg_chnl_spend_gs_f/shellscripts/mktg_chnl_spend_gs_f.sh"
task_mktg_chnl_spend_gs_f = NWBashScriptOperator(
    bash_script=task_mktg_chnl_spend_gs_f_script,
    script_args=[],
    task_id='mktg_chnl_spend_gs_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_chnl_spend_gs_f.set_upstream(task_mktg_mta_dependency)

######################################################## Brax data upload #########################################################

task_mktg_brax_offline_upload_f_script = "/data/etl/Scripts/mktg_brax_offline_upload_f/shellscripts/mktg_brax_offline_upload_f.sh"
task_mktg_brax_offline_upload_f = NWBashScriptOperator(
    bash_script=task_mktg_brax_offline_upload_f_script,
    script_args=[],
    task_id='mktg_brax_offline_upload_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_brax_offline_upload_f.set_upstream(task_mktg_sst_dependency)

######################################################## DQ Check Job Tracker #########################################################

task_dq_jobs_tracking_script = "/data/etl/Scripts/dq_jobs_tracking/shellscripts/dq_jobs_tracking.sh"
task_dq_jobs_tracking = NWBashScriptOperator(
    bash_script=task_dq_jobs_tracking_script,
    script_args=[],
    task_id='dq_jobs_tracking',
    dag=dag
        )

task_dq_jobs_tracking.set_upstream(task_start_job_bluekai)

#######################google_audience level data ingestion#######################################################
task_mktg_goog_adnc_perf_f_script = "/data/etl/Scripts/mktg_goog_adnc_perf_f/shellscripts/mktg_goog_adnc_perf_f.sh"
task_mktg_goog_adnc_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_adnc_perf_f_script,
    script_args=[],
    task_id='mktg_goog_adnc_perf_f',
    dag=dag,
    pool='redshift_etl',
    email=['a4j8h6y1s0z9v1e3@nerdwallet.slack.com'])
task_mktg_goog_adnc_perf_f.set_upstream(task_start_job_mktg_utc01)
