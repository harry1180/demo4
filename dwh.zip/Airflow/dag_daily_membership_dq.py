from airflow import DAG
from datetime import datetime, timedelta, time

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor, ExternalTaskSensor

job_name = "dag_daily_membership_dq"

default_args = {
    'owner': 'dwh',
    'depends_on_past': False,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 6, 1),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh'
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(10, 00),
    task_id='Initiating_start_time',
    dag=dag)

task_prequal_dependency = ExternalTaskSensor(
    task_id='waiting_for_prequal_status_update',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='status_update',
    dag=dag)
    
task_credit_profile_dependency = ExternalTaskSensor(
    task_id='waiting_for_pud_status_update',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='status_update',
    dag=dag)

task_consolidated_multiple_fico = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_prequal_offer_event_pl_f/pythonscripts/multiple_fico.json"],
    task_id='multiple_fico',
    dag=dag)

task_consolidated_null_fico = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_prequal_offer_event_pl_f/pythonscripts/null_fico.json"],
    task_id='null_fico',
    dag=dag)

task_consolidated_null_fico.set_upstream(task_start_job)
task_consolidated_null_fico.set_upstream(task_prequal_dependency)
task_consolidated_null_fico.set_upstream(task_credit_profile_dependency)
task_consolidated_multiple_fico.set_upstream(task_start_job)
task_consolidated_multiple_fico.set_upstream(task_prequal_dependency)
task_consolidated_multiple_fico.set_upstream(task_credit_profile_dependency)
