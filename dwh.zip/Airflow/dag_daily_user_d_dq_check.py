import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_user_d_dq_check"

default_args = {
    'owner': 'dwh',
    'depends_on_past': False,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 10, 8),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(4,15),
    task_id='Initiating_start_time',
    dag=dag)


Task_dw_user_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_user_d',
    external_dag_id='dag_daily_identity',
    external_task_id='dw_user_d',
    dag=dag)

task_dw_eff_dt= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_dw_eff_dt_check.json"],
    task_id='dw_eff_dt_check',
    dag=dag)


task_dw_eff_dt.set_upstream(task_start_job)
task_dw_eff_dt.set_upstream(Task_dw_user_d_dependency)


task_curr_in= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_curr_in_check.json"],
    task_id='curr_in_check',
    dag=dag)


task_curr_in.set_upstream(task_start_job)
task_curr_in.set_upstream(Task_dw_user_d_dependency)


task_del_in= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_del_in_check.json"],
    task_id='del_in_check',
    dag=dag)


task_del_in.set_upstream(task_start_job)
task_del_in.set_upstream(Task_dw_user_d_dependency)


task_reg_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_reg_ts_check.json"],
    task_id='reg_ts_check',
    dag=dag)


task_reg_ts.set_upstream(task_start_job)
task_reg_ts.set_upstream(Task_dw_user_d_dependency)


task_reg_pfm_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_reg_pfm_nm_check.json"],
    task_id='reg_pfm_nm_check',
    dag=dag)


task_reg_pfm_nm.set_upstream(task_start_job)
task_reg_pfm_nm.set_upstream(Task_dw_user_d_dependency)


task_reg_form_fctr_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_reg_form_fctr_nm_check.json"],
    task_id='reg_form_fctr_nm_check',
    dag=dag)


task_reg_form_fctr_nm.set_upstream(task_start_job)
task_reg_form_fctr_nm.set_upstream(Task_dw_user_d_dependency)


task_reg_auth_pvdr_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_reg_auth_pvdr_nm_check.json"],
    task_id='reg_auth_pvdr_nm_check',
    dag=dag)


task_reg_auth_pvdr_nm.set_upstream(task_start_job)
task_reg_auth_pvdr_nm.set_upstream(Task_dw_user_d_dependency)


task_dw_load_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_dw_load_ts_check.json"],
    task_id='dw_load_ts_check',
    dag=dag)


task_dw_load_ts.set_upstream(task_start_job)
task_dw_load_ts.set_upstream(Task_dw_user_d_dependency)


task_dw_suspected_bot_in= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_dw_suspected_bot_in_check.json"],
    task_id='dw_suspected_bot_in_check',
    dag=dag)


task_dw_suspected_bot_in.set_upstream(task_start_job)
task_dw_suspected_bot_in.set_upstream(Task_dw_user_d_dependency)


task_user_id_unique_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_user_id_unique_check_check.json"],
    task_id='user_id_unique_check_check',
    dag=dag)


task_user_id_unique_check.set_upstream(task_start_job)
task_user_id_unique_check.set_upstream(Task_dw_user_d_dependency)


task_record_change_count_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_record_change_count_check_check.json"],
    task_id='record_change_count_check_check',
    dag=dag)


task_record_change_count_check.set_upstream(task_start_job)
task_record_change_count_check.set_upstream(Task_dw_user_d_dependency)


task_source_target_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_source_target_check_check.json"],
    task_id='source_target_check_check',
    dag=dag)


task_source_target_check.set_upstream(task_start_job)
task_source_target_check.set_upstream(Task_dw_user_d_dependency)


task_scd_date_gap_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_scd_date_gap_check_check.json"],
    task_id='scd_date_gap_check_check',
    dag=dag)


task_scd_date_gap_check.set_upstream(task_start_job)
task_scd_date_gap_check.set_upstream(Task_dw_user_d_dependency)


task_scd_date_overlap_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_scd_date_overlap_check_check.json"],
    task_id='scd_date_overlap_check_check',
    dag=dag)


task_scd_date_overlap_check.set_upstream(task_start_job)
task_scd_date_overlap_check.set_upstream(Task_dw_user_d_dependency)


task_incorrect_date_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_incorrect_date_check_check.json"],
    task_id='incorrect_date_check_check',
    dag=dag)


task_incorrect_date_check.set_upstream(task_start_job)
task_incorrect_date_check.set_upstream(Task_dw_user_d_dependency)


task_multiple_user_dw_eff_dt_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_multiple_user_dw_eff_dt_check_check.json"],
    task_id='multiple_user_dw_eff_dt_check_check',
    dag=dag)


task_multiple_user_dw_eff_dt_check.set_upstream(task_start_job)
task_multiple_user_dw_eff_dt_check.set_upstream(Task_dw_user_d_dependency)


task_reg_page_sk_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_d/pythonscripts/dw_user_d_reg_page_sk_check_check.json"],
    task_id='reg_page_sk_check',
    dag=dag)


task_reg_page_sk_check.set_upstream(task_start_job)
task_reg_page_sk_check.set_upstream(Task_dw_user_d_dependency)



