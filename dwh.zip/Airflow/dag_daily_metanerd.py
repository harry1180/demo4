import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor

job_name = "dag_daily_metanerd"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'start_date': datetime(2015, 10, 14),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(10,01),
    task_id='Initiating_start_time',
    dag=dag)


task1_script="/data/etl/Scripts/MetaNerd/shellscripts/dw_metanerd.sh"
task1_metanerd = NWBashScriptOperator(
    bash_script=task1_script,
    script_args=[],
    task_id='Load_metanerd_tables',
    dag=dag)



task1_metanerd.set_upstream(task_start_job)

