import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_dwh_hourly_downstream_apps"


default_args = {
    'owner': 'dwh',
   # 'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime.now(),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_interval': timedelta(minutes=5),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='25 * * * *')

task_hourly_start_job = TimeSensor(
target_time=time(0,25),
task_id='Initiating_start_time_hourly_job',
dag=dag)    

## leave here as a placeholder
