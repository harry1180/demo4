import sys
from datetime import datetime, timedelta, time
from airflow import DAG
from email.mime.text import MIMEText
import airflow.operators
from airflow.operators import PythonOperator
from airflow.operators import DummyOperator
from airflow.models import  BaseOperator

import os
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor
#import airflow.models.BaseOperator
import smtplib
sys.path.append(os.path.dirname(__file__))
import json
import requests
def send_message(channel,text):    
# Set the webhook_url to the one provided by Slack when you create the webhook at https://my.slack.com/services/new/incoming-webhook/    
    webhook_url = 'https://hooks.slack.com/services/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'    
    data = dict()    
    data['channel']=channel    
    #data['text']=text+ '{{ ds }}'    
    data['text']=text
    slack_data =json.dumps(data)    
    response = requests.post(    
        webhook_url,slack_data,    
        headers={'Content-Type': 'application/json'}    
    )    
    response.raise_for_status()    
# Calling the above function example nw_slack.send_message("dwh-marketing-team","Testing out slack module"). First arg is a slack channel_name & second arg is the text to be sent    
# **By default the channel is #dwh-team & the user name is Airflow**
# k6v7j9w6n5r3w2v4@nerdwallet.slack.com dwh-oncall slack#
# o2h5c1k1l5p7e3z9@nerdwallet.slack.com mktg-dq slack#

dag_name = "dag_send_slack_daily_alerts"

default_args = {
    'owner': 'dwh',
    'start_date': datetime(2018,8,13),
    'retries': 0,
    'queue': 'dwh'
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)


task_start_job = TimeSensor(
    target_time=time(06,30), #HH,MM
    task_id='job_start_time_UTC_00_PDT_18_PST_17',
    dag=dag)


### check marketing mta completed at UTC 06 ###

task_dag_daily_marketing_start = ExternalTaskSensor(
    task_id='dag_daily_marketing_start',
    external_dag_id='dag_daily_marketing',
    external_task_id='mktg_digital_start_time_UTC_01_PDT_18_PST_17',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['nmylarappa@nerdwallet.com'],
    dag=dag)

task_dag_daily_marketing_complete = ExternalTaskSensor(
    task_id='dag_daily_marketing_complete',
    external_dag_id='dag_daily_marketing',
    external_task_id='status_update',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['nmylarappa@nerdwallet.com'],
    dag=dag)

task_dag_daily_core_dwh_complete = ExternalTaskSensor(
    task_id='dag_daily_core_dwh_complete',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['nmylarappa@nerdwallet.com'],
    dag=dag)

task_dag_daily_marketing_offline_mktg_conv_upload_session_f_complete = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_mktg_upload_session_f_complete',
    external_dag_id='dag_daily_marketing_offline',
    external_task_id='mktg_conv_upload_session_f',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['nmylarappa@nerdwallet.com'],
    dag=dag)

task_dag_daily_marketing_offline_mktg_conv_upload_ds_post_f_complete = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_mktg_conv_upload_ds_post_f_complete',
    external_dag_id='dag_daily_marketing_offline',
    external_task_id='mktg_conv_upload_ds_post_f',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['nmylarappa@nerdwallet.com'],
    dag=dag)

task_dag_daily_marketing_offline_mktg_conv_upload_goog_f_complete = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_mktg_conv_upload_goog_f_complete',
    external_dag_id='dag_daily_marketing_offline',
    external_task_id='mktg_conv_upload_goog_f',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['nmylarappa@nerdwallet.com'],
    dag=dag)

### check marketing core completed at UTC 12 ###

task_dag_daily_mktg_core_dwh_sla = ExternalTaskSensor(
    task_id='check_marketing_sla_done',
    external_dag_id='dag_daily_dwh_sla_checkpoint',
    external_task_id='check_marketing_core_done',
    allowed_states=['failed'],
    email_on_failure=True,
    email=['ssekhar@nerdwallet.com','hkoppuravuri@nerdwallet.com'],
    dag=dag)


# *****************Sending Slack Message*************************

class MyPythonOperator(PythonOperator):
    template_fields = ('templates_dict','op_args')
ds = '{{ ds }}'
exec_date = '{{ execution_date }}'
ts = '{{ ts }}'


#def slack_failed_task(contextDictionary, **kwargs):
#     failed_alert = SlackAPIPostOperator(
#     task_id='check_marketing_core_done',
#     channel="dwh-marketing-team",
#     text = ':red_circle: DAG Failed',
#     owner = 'dwh')
#     return failed_alert.execute

task_send_slack_marketing_start=MyPythonOperator(
               task_id='send_slack_msg_dag_daily_mktg_start',
               python_callable=send_message,
               op_args=["dwh-marketing-team","Daily Airflow Alerts - dag daily marketing started at "+exec_date],
               dag=dag)

task_send_slack_marketing_complete=MyPythonOperator(
               task_id='send_slack_msg_dag_daily_mktg_completed',
               python_callable=send_message,
               op_args=["dwh-marketing-team","Daily Airflow Alerts - dag daily marketing completed at "+exec_date],
               dag=dag)

task_send_slack_core_dwh_complete=MyPythonOperator(
               task_id='send_slack_msg_dag_daily_core_dwh_completed',
               python_callable=send_message,
               op_args=["dwh-marketing-team","Daily Airflow Alerts - dag daily core dwh completed at "+exec_date],
               dag=dag)

task_send_slack_offline_conv_upload_session_f_complete=MyPythonOperator(
               task_id='send_slack_msg_dag_daily_offline_conv_upload_session_f_completed',
               python_callable=send_message,
               op_args=["dwh-marketing-team","Daily Airflow Alerts - dag daily offline conv upload session f  completed at "+exec_date],
               dag=dag)

task_send_slack_offline_conv_upload_ds_post_f_complete=MyPythonOperator(
               task_id='send_slack_msg_dag_daily_offline_conv_upload_ds_post_f_completed',
               python_callable=send_message,
               op_args=["dwh-marketing-team","Daily Airflow Alerts - dag daily offline conv upload ds post f completed at "+exec_date],
               dag=dag)

task_send_slack_offline_conv_upload_goog_f_complete=MyPythonOperator(
               task_id='send_slack_msg_dag_daily_offline_conv_upload_goog_f_completed',
               python_callable=send_message,
               op_args=["dwh-marketing-team","Daily Airflow Alerts - dag daily offline mktg conv upload goog f completed at "+exec_date],
               dag=dag)
task_send_slack_mktg_core_sla=MyPythonOperator(
               task_id='send_slack_mktg_core_sla',
               python_callable=send_message,
               op_args=["dwh-marketing-team","Daily Airflow Alerts -  mktg_core_done_missed_sla"+exec_date],
               dag=dag)




#task_send_slack_mktg_core_sla=MyPythonOperator(
#               task_id='send_slack_mktg_core_done',
#               python_callable=send_message,
#               op_args=["dwh-marketing-team","Daily Airflow Alerts -  mktg_core_done_missed_sla"+exec_date],
#               dag=dag)

#task_with_failed_slack_alerts = MyPythonOperator(
#task_id='send_slack_mktg_core_done',
#python_callable=send_message,
#on_failure_callback=slack_failed_task,
#provide_context=True,
#dag=dag)

#task_with_failed_slack_alerts=myBaseOperator(
#		task_id='send_slack_mktg_core_done',
#		on_failure_callback=send_message,
#		python_callable=send_message,
#		on_retry_callback=None,
#                op_args=["dwh-marketing-team","Daily Airflow Alerts -  mktg_core_done_missed_sla_using mybaseoperator"+exec_date],
#		on_success_callback=None,
#		dag=dag)

task_dag_daily_marketing_start.set_upstream(task_start_dag)
task_send_slack_marketing_start.set_upstream(task_dag_daily_marketing_start)
task_dag_daily_marketing_offline_mktg_conv_upload_session_f_complete.set_upstream(task_start_dag)
task_send_slack_offline_conv_upload_session_f_complete.set_upstream(task_dag_daily_marketing_offline_mktg_conv_upload_session_f_complete)
task_dag_daily_marketing_offline_mktg_conv_upload_ds_post_f_complete.set_upstream(task_start_dag)
task_send_slack_offline_conv_upload_ds_post_f_complete.set_upstream(task_dag_daily_marketing_offline_mktg_conv_upload_ds_post_f_complete)
task_dag_daily_marketing_offline_mktg_conv_upload_goog_f_complete.set_upstream(task_start_dag)
task_send_slack_offline_conv_upload_goog_f_complete.set_upstream(task_dag_daily_marketing_offline_mktg_conv_upload_goog_f_complete)
task_dag_daily_marketing_complete.set_upstream(task_start_dag)
task_send_slack_marketing_complete.set_upstream(task_dag_daily_marketing_complete)
task_dag_daily_core_dwh_complete.set_upstream(task_start_dag)
task_send_slack_core_dwh_complete.set_upstream(task_dag_daily_core_dwh_complete)
task_dag_daily_mktg_core_dwh_sla.set_upstream(task_start_job)
task_send_slack_mktg_core_sla.set_upstream(task_dag_daily_mktg_core_dwh_sla)

