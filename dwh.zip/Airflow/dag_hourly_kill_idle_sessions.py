import sys
from datetime import *
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_hourly_kill_idle_sessions"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2016, 12, 6),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='30 * * * *')


task_semrush_monthly_load_script="/data/etl/Scripts/dw_kill_idle_sessions/shellscripts/kill_dwh_idle_sessions.sh"
task_semrush_monthly_load = NWBashScriptOperator(
    bash_script=task_semrush_monthly_load_script,
    script_args=[],
    task_id='dwh_kill_idle_sessions',
    dag=dag)
