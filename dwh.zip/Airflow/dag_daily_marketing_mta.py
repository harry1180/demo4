import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_marketing_mta'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2016, 12, 15),
    'email': ['airflowalerts@nerdwallet.com','dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh'
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_mktg_mta_external_dependency_1 = ExternalTaskSensor(
    task_id='waiting_for_dw_session_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_session_event_f',
    trigger_rule='all_done',
    dag=dag)

task_mktg_mta_external_dependency_2 = ExternalTaskSensor(
    task_id='waiting_for_mktg_trkng_param_fact_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='mktg_trkng_param_fact_load',
    trigger_rule='all_done',
    dag=dag)

task_mktg_mta_external_dependency_3 = ExternalTaskSensor(
    task_id='waiting_for_sizmek',
    external_dag_id='dag_daily_marketing_offline',
    external_task_id='mktg_offline_status_update_sizmek',
    trigger_rule='all_done',
    dag=dag)


task_mktg_mta_external_dependency_4 = ExternalTaskSensor(
    task_id='waiting_for_email_event_load',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='dw_email_event_Fact_Load',
    trigger_rule='all_done',
    dag=dag)

task_start_appsflyer_webhook_job = TimeSensor(
    target_time=time(0,15),
    task_id='appsflyer_webhook_start_time',
    dag=dag)

Task_SITE_VISITOR_D_dependency = ExternalTaskSensor(
    task_id='waiting_for_Site_Visitor_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='site_visitor_d',
    dag=dag)

Task_PUD_IDENTITY_dependency = ExternalTaskSensor(
    task_id='waiting_for_daily_pud_identity_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_identity_d',
    dag=dag)

###################### Dependent tables ######################

# Google Spreadsheet
task_mktg_gs_load_dwh_script = "/data/etl/Scripts/mktg_gs_load_dwh/shellscripts/mktg_gs_load_dwh.sh"
task_mktg_gs_load_dwh = NWBashScriptOperator(
        bash_script=task_mktg_gs_load_dwh_script,
        script_args=[],
        task_id='mktg_gs_load_dwh',
        trigger_rule='all_done',
        pool='redshift_etl',
        dag=dag
        )


task_mktg_gs_load_dwh.set_upstream(task_mktg_mta_external_dependency_3)

###################### MTA dimenssion tables ######################

task_mktg_consolidated_paid_campaign_d_script = "/data/etl/Scripts/mktg_consolidated_paid_campaign_d/shellscripts/mktg_consolidated_paid_campaign_d.sh"
task_mktg_consolidated_paid_campaign_d = NWBashScriptOperator(
      bash_script=task_mktg_consolidated_paid_campaign_d_script,
      script_args=[],
      task_id='mktg_consolidated_paid_campaign_d',
      trigger_rule='all_done',
      pool='redshift_etl',
      dag=dag)



task_mktg_tch_campaign_d_script = "/data/etl/Scripts/mktg_tch_campaign_d/shellscripts/mktg_tch_campaign_d.sh"
task_mktg_tch_campaign_d  = NWBashScriptOperator(
        bash_script=task_mktg_tch_campaign_d_script,
        script_args=[],
        task_id='mktg_tch_campaign_d',
        #trigger_rule='all_done',
        pool='redshift_etl',
        dag=dag
        )


task_mktg_tch_ad_d_script = "/data/etl/Scripts/mktg_tch_ad_d/shellscripts/mktg_tch_ad_d.sh"
task_mktg_tch_ad_d = NWBashScriptOperator(
        bash_script=task_mktg_tch_ad_d_script,
        script_args=[],
        task_id='mktg_tch_ad_d',
        #trigger_rule='all_done',
        pool='redshift_etl',
        dag=dag
        )

task_mktg_consolidated_paid_campaign_d.set_upstream([task_mktg_mta_external_dependency_1,task_mktg_mta_external_dependency_2,task_mktg_mta_external_dependency_3,task_mktg_mta_external_dependency_4])
task_mktg_tch_campaign_d.set_upstream(task_mktg_consolidated_paid_campaign_d)
task_mktg_tch_campaign_d.set_upstream(task_mktg_mta_external_dependency_4)
task_mktg_tch_ad_d.set_upstream([task_mktg_gs_load_dwh, task_mktg_tch_campaign_d])


###################### MTA facts tables ######################

task_mktg_tch_event_f_script = "/data/etl/Scripts/mktg_tch_event_f/shellscripts/mktg_tch_event_f.sh"
task_mktg_tch_event_f = NWBashScriptOperator(
        bash_script=task_mktg_tch_event_f_script,
        script_args=[],
        task_id='mktg_tch_event_f',
        #trigger_rule='all_done',
        pool='redshift_etl',
        dag=dag
        )


task_mktg_session_mta_f_script = "/data/etl/Scripts/mktg_session_mta_f/shellscripts/mktg_session_mta_f.sh"
task_mktg_session_mta_f = NWBashScriptOperator(
        bash_script=task_mktg_session_mta_f_script,
        script_args=[],
        task_id='mktg_session_mta_f',
        #trigger_rule='all_done',
        pool='redshift_etl',
        dag=dag
        )


task_mktg_page_view_attr_sum_f_script = "/data/etl/Scripts/mktg_page_view_attr_sum_f/shellscripts/mktg_page_view_attr_sum_f.sh"
task_mktg_page_view_attr_sum_f = NWBashScriptOperator(
        bash_script=task_mktg_page_view_attr_sum_f_script,
        script_args=[],
        task_id='mktg_page_view_attr_sum_f',
        #trigger_rule='all_done',
        pool='redshift_etl',
        dag=dag
        )


task_mktg_tch_event_f.set_upstream(task_mktg_tch_ad_d)
task_mktg_session_mta_f.set_upstream(task_mktg_tch_event_f)
task_mktg_page_view_attr_sum_f.set_upstream(task_mktg_session_mta_f)

#### Appsflyer Events Begin #####

task_mktg_appsflyer_non_organic_in_app_events_raw_f_script = "/data/etl/Scripts/mktg_appsflyer_non_organic_in_app_events_raw_f/shellscripts/mktg_appsflyer_non_organic_in_app_events_raw_f.sh"
task_mktg_appsflyer_non_organic_in_app_events_raw_f = NWBashScriptOperator(
       bash_script=task_mktg_appsflyer_non_organic_in_app_events_raw_f_script,
       script_args=[],
       task_id='mktg_appsflyer_non_organic_in_app_events_raw_f',
       trigger_rule='all_done',
       pool='redshift_etl',
       dag=dag)

task_mktg_appsflyer_non_organic_installs_raw_f_script = "/data/etl/Scripts/mktg_appsflyer_non_organic_installs_raw_f/shellscripts/mktg_appsflyer_non_organic_installs_raw_f.sh"
task_mktg_appsflyer_non_organic_installs_raw_f = NWBashScriptOperator(
       bash_script=task_mktg_appsflyer_non_organic_installs_raw_f_script,
       script_args=[],
       task_id='mktg_appsflyer_non_organic_installs_raw_f',
       trigger_rule='all_done',
       pool='redshift_etl',
       dag=dag)

task_AppsFlyerWebhookEvent = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['AppsFlyerWebhookEvent'],
    task_id='AppsFlyerWebhookEvent',
    dag=dag)

task_dw_appsflyer_event_f_script="/data/etl/Scripts/dw_appsflyer_event_f/shellscripts/dw_appsflyer_event_f.sh"
task_dw_appsflyer_event_f = NWBashScriptOperator(
    bash_script=task_dw_appsflyer_event_f_script,
    script_args=[],
    task_id='dw_appsflyer_event_f',
    pool='redshift_etl',
    dag=dag)

### Appsflyer Tasks Flow begin ###
task_mktg_appsflyer_non_organic_installs_raw_f.set_upstream(task_start_appsflyer_webhook_job)
task_mktg_appsflyer_non_organic_in_app_events_raw_f.set_upstream(task_mktg_appsflyer_non_organic_installs_raw_f)
task_AppsFlyerWebhookEvent.set_upstream(task_start_appsflyer_webhook_job)
task_dw_appsflyer_event_f.set_upstream(Task_SITE_VISITOR_D_dependency)
task_dw_appsflyer_event_f.set_upstream(Task_PUD_IDENTITY_dependency)
task_dw_appsflyer_event_f.set_upstream(task_AppsFlyerWebhookEvent)
task_mktg_tch_event_f.set_upstream(task_dw_appsflyer_event_f)
task_dw_appsflyer_event_f.set_upstream(task_mktg_appsflyer_non_organic_in_app_events_raw_f)
task_mktg_tch_campaign_d.set_upstream(task_dw_appsflyer_event_f)

### Appsflyer Tasks Flow end ###

#### Appsflyer Events End #####

################ Status Update  #################

task_status_update_script = "/data/etl/Common/redshift_sql_function.sh"
task_status_update = NWBashScriptOperator(
    bash_script=task_status_update_script,
    script_args=[
        "/data/etl/Airflow/post_updates/dag_daily_marketing_mta_status_update.sql"
    ],
    task_id='mktg_mta_status_update',
    dag=dag)

task_status_update.set_upstream(task_mktg_page_view_attr_sum_f)
