import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator, DummyOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor


dag_name = 'dag_hourly_nerdlake_pud_identity_p0'

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018, 7, 6, 16),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=10),
    'queue': 'dwh',
    'depends_on_past': True
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

###########################################################################
# Command tasks
###########################################################################

profile_names = {
    # 'addresses',
    # 'goals',
    # 'goals_debt',
    # 'goals_credit',
    # 'goals_profiles',
    # 'goals_retirement',
    # 'goals_savings',
    # 'identities',
    # 'registration_tracking_profiles',
    # 'subscription_profiles',
    'tradelines',
    # 'terms_of_service_acknowledgements',
    # 'terms_of_service_profiles',
    # 'tu_authentication_status_profiles',
    'tu_credit_report_profiles',
    # 'yodlee_accounts',
    # 'yodlee_bank_accounts',
    # 'yodlee_bill_accounts',
    # 'yodlee_credit_accounts',
    # 'yodlee_investment_accounts',
    # 'yodlee_loan_accounts',
}

force_full_profiles = {
    # 'addresses',
    # 'goals_credit',
    # 'goals_debt',
    # 'goals_profiles',
    # 'goals_retirement',
    # 'goals_savings',
    # 'yodlee_bank_accounts',
    # 'yodlee_bill_accounts',
    # 'yodlee_credit_accounts',
    # 'yodlee_investment_accounts',
    # 'yodlee_loan_accounts',
}

profile_target_load_tasks = dict()
for profile in sorted(profile_names, key=lambda s:s.lower()):
    script_args = [profile]
    if profile in force_full_profiles:
        script_args = [profile, '--force_full_extract']

    weight = 1
    if profile == 'identities':
        weight = 10

    profile_stage_load_task = NWBashScriptOperator(
        bash_script='/data/etl/Common/idb_nerdlake_stg_table_load.sh',
        script_args=script_args,
        task_id='idb_{}_s_load'.format(profile),
        pool='identity_replica_extract',
        priority_weight=100 + weight,
        dag=dag)
    profile_stage_load_task.set_upstream(task_start_dag)

    profile_target_load_task = NWBashScriptOperator(
        bash_script='/data/etl/Common/idb_nerdlake_tgt_table_load.sh',
        script_args=[profile],
        task_id='idb_{}_d_load'.format(profile),
        pool='presto_etl',
        priority_weight=weight,
        dag=dag)
    profile_target_load_task.set_upstream(profile_stage_load_task)
    profile_target_load_tasks[profile] = profile_target_load_task

###########################################################################
# Dummy Completion tasks
###########################################################################
task_pud_identity_done = DummyOperator(
    task_id='pud_identity_done',
    trigger_rule='all_done',
    dag=dag)
task_pud_identity_done.set_upstream(profile_target_load_tasks.values())


#task_idb_yodlee_transactions_extract = NWBashScriptOperator(
#    bash_script='/data/etl/Common/idb_nerdlake_stg_table_load.sh',
#    script_args=["yodlee_transactions"],
#    task_id='task_idb_yodlee_transactions_extract',
#    pool='identity_replica_extract',
#    dag=dag)
#task_idb_yodlee_transactions_extract.set_upstream(task_start_dag)
#
#task_idb_yodlee_transactions_f_load = NWBashScriptOperator(
#    bash_script='/data/etl/Common/idb_nerdlake_tgt_table_load.sh',
#    script_args=["yodlee_transactions"],
#    task_id='task_idb_yodlee_transactions_f',
#    dag=dag)
#task_idb_yodlee_transactions_f_load.set_upstream(task_idb_yodlee_transactions_extract)


#
#task_yodlee_fact_stage = DummyOperator(
#    task_id='task_yodlee_fact_stage',
#    dag=dag)
#
#task_yodlee_dim_stage = DummyOperator(
#    task_id='task_yodlee_dim_stage',
#    dag=dag)
#
#task_ipx_fact_dependency = DummyOperator(
#    task_id='Task_ipx_fact_dependency',
#    dag=dag)
#
#task_all_event_s_dependency = ExternalTaskSensor(
#    task_id='waiting_for_all_event_s_job',
#    external_dag_id='dag_hourly_nerdlake_events_p0',
#    external_task_id='all_events_s_nerdlake_load',
#    dag=dag)
#
#task_aflt_tran_dependency = ExternalTaskSensor(
#    task_id='waiting_for_aflt_tran_job',
#    external_dag_id='dag_hourly_nerdlake_aflt_tran',
#    external_task_id='aflt_tran_load_nerdlake',
#    dag=dag)
#
#task_user_agent_d_depedency = ExternalTaskSensor(
#    task_id='waiting_for_user_agent_job',
#    external_dag_id='dag_hourly_nerdlake_core_p0',
#    external_task_id='user_agent_d_nerdlake_load',
#    dag=dag)
#
#task_idb_registration_tracking_profiles_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_registration_tracking_profiles"],
#    task_id='task_idb_registration_tracking_profiles_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_registration_tracking_profiles_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_registration_tracking_profiles"],
#    task_id='task_idb_registration_tracking_profiles_d',
#    dag=dag)
#
#task_idb_financial_profile_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_financial_profile"],
#    task_id='task_idb_financial_profile_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_financial_profile_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_financial_profile"],
#    task_id='task_idb_financial_profile_d',
#    dag=dag)
#
##task_idb_feed_recommendations_s= NWBashScriptOperator (
##    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
##    script_args=["idb_feed_recommendations","feed_recommendations_dwh"],
##    task_id='task_idb_feed_recommendations_s',
##    dag=dag)
##
##task_idb_feed_recommendations_d= NWBashScriptOperator (
##    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
##    script_args=["idb_feed_recommendations"],
##    task_id='task_idb_feed_recommendations_d',
##    dag=dag)
##
##task_idb_feed_recommendations_d.set_upstream(task_idb_feed_recommendations_s)
#
#task_idb_goals_credit_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_goals_credit"],
#    task_id='task_idb_goals_credit_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_goals_credit_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_goals_credit"],
#    task_id='task_idb_goals_credit_d',
#    dag=dag)
#
#task_idb_yodlee_credit_accounts_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_yodlee_credit_accounts custom"],
#    task_id='task_idb_yodlee_credit_accounts_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_yodlee_credit_accounts_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_yodlee_credit_accounts"],
#    task_id='task_idb_yodlee_credit_accounts_d',
#    dag=dag)
#
#task_idb_goals_debt_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_goals_debt"],
#    task_id='task_idb_goals_debt_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_goals_debt_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_goals_debt"],
#    task_id='task_idb_goals_debt_d',
#    dag=dag)
#
#task_idb_goals_savings_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_goals_savings"],
#    task_id='task_idb_goals_savings_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_goals_savings_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_goals_savings"],
#    task_id='task_idb_goals_savings_d',
#    dag=dag)
#
#task_idb_tu_authentication_status_profile_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_tu_authentication_status_profile"],
#    task_id='task_idb_tu_authentication_status_profile_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_tu_authentication_status_profile_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_tu_authentication_status_profile"],
#    task_id='task_idb_tu_authentication_status_profile_d',
#    dag=dag)
#
##task_idb_tu_tradeline_s= NWBashScriptOperator (
##    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
##    script_args=["idb_tu_tradeline","tradelines_dwh"],
##    task_id='task_idb_tu_tradeline_s',
##    dag=dag)
##
##task_idb_tu_tradeline_d= NWBashScriptOperator (
##    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
##    script_args=["idb_tu_tradeline"],
##    task_id='task_idb_tu_tradeline_d',
##    dag=dag)
##
##task_idb_tu_tradeline_d.set_upstream(task_idb_tu_tradeline_s)
#
#task_idb_yodlee_bank_accounts_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_yodlee_bank_accounts"],
#    task_id='task_idb_yodlee_bank_accounts_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_yodlee_bank_accounts_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_yodlee_bank_accounts"],
#    task_id='task_idb_yodlee_bank_accounts_d',
#    dag=dag)
#
#task_idb_yodlee_transactions_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_yodlee_transactions custom"],
#    task_id='task_idb_yodlee_transactions_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_yodlee_transactions_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_yodlee_transactions"],
#    task_id='task_idb_yodlee_transactions_f',
#    dag=dag)
#
#task_idb_terms_of_service_profile_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_terms_of_service_profile"],
#    task_id='task_idb_terms_of_service_profile_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_terms_of_service_profile_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_terms_of_service_profile"],
#    task_id='task_idb_terms_of_service_profile_d',
#    dag=dag)
#
#task_idb_yodlee_loan_accounts_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_yodlee_loan_accounts"],
#    task_id='task_idb_yodlee_loan_accounts_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_yodlee_loan_accounts_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_yodlee_loan_accounts"],
#    task_id='task_idb_yodlee_loan_accounts_d',
#    dag=dag)
#
#task_idb_global_profile_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_global_profile"],
#    task_id='task_idb_global_profile_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_global_profile_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_global_profile"],
#    task_id='task_idb_global_profile_d',
#    dag=dag)
#
#task_idb_subscription_profile_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_subscription_profile"],
#    task_id='task_idb_subscription_profile_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_subscription_profile_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_subscription_profile"],
#    task_id='task_idb_subscription_profile_d',
#    dag=dag)
#
#task_idb_tu_credit_report_profile_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_tu_credit_report_profile custom"],
#    task_id='task_idb_tu_credit_report_profile_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_tu_credit_report_profile_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_tu_credit_report_profile"],
#    task_id='task_idb_tu_credit_report_profile_d',
#    dag=dag)
#
#task_idb_addresses_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_addresses"],
#    task_id='task_idb_addresses_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_addresses_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_addresses"],
#    task_id='task_idb_addresses_d',
#    dag=dag)
#
#task_idb_terms_of_service_acknowledgement_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_terms_of_service_acknowledgement"],
#    task_id='task_idb_terms_of_service_acknowledgement_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_terms_of_service_acknowledgement_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_terms_of_service_acknowledgement"],
#    task_id='task_idb_terms_of_service_acknowledgement_d',
#    dag=dag)
#
#
#task_idb_yodlee_bill_accounts_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_yodlee_bill_accounts custom"],
#    task_id='task_idb_yodlee_bill_accounts_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_yodlee_bill_accounts_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_yodlee_bill_accounts"],
#    task_id='task_idb_yodlee_bill_accounts_d',
#    dag=dag)
#
#task_idb_goals_retirement_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_goals_retirement"],
#    task_id='task_idb_goals_retirement_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_goals_retirement_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_goals_retirement"],
#    task_id='task_idb_goals_retirement_d',
#    dag=dag)
#
#task_idb_yodlee_accounts_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_yodlee_accounts"],
#    task_id='task_idb_yodlee_accounts_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_yodlee_accounts_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_yodlee_accounts"],
#    task_id='task_idb_yodlee_accounts_d',
#    dag=dag)
#
#task_idb_yodlee_investment_accounts_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_yodlee_investment_accounts"],
#    task_id='task_idb_yodlee_investment_accounts_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_yodlee_investment_accounts_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_yodlee_investment_accounts"],
#    task_id='task_idb_yodlee_investment_accounts_d',
#    dag=dag)
#
#task_idb_identities_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_identities"],
#    task_id='task_idb_identities_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_identities_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_identities"],
#    task_id='task_idb_identities_d',
#    dag=dag)
#
#task_idb_goals_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_goals"],
#    task_id='task_idb_goals_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_goals_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_goals"],
#    task_id='task_idb_goals_d',
#    dag=dag)
#
#task_idb_feed_items_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_feed_items"],
#    task_id='task_idb_feed_items_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_feed_items_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_feed_items"],
#    task_id='task_idb_feed_items_d',
#    dag=dag)
#
#task_idb_goals_profiles_s= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_stage_table_load.sh',
#    script_args=["idb_goals_profiles"],
#    task_id='task_idb_goals_profiles_s',
#    pool='identity_replica_extract',
#    priority_weight=10,
#    dag=dag)
#
#task_idb_goals_profiles_d= NWBashScriptOperator (
#    bash_script='/data/etl/Common/identity_nerdlake_dim_table_load.sh',
#    script_args=["idb_goals_profiles"],
#    task_id='task_idb_goals_profiles_d',
#    dag=dag)
#
#task_dw_yd_acct_bal_f = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_yd_acct_bal_f_nerdlake/shellscripts/dw_yd_acct_bal_f.sh",
#    task_id='task_dw_yd_acct_bal_f',
#    dag=dag
#    )
#
#task_dw_identity_tu_credit_rprt_profile_d = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_identity_tu_credit_rprt_profile_d_nerdlake/shellscripts/dw_identity_tu_credit_rprt_profile_d.sh",
#    task_id='task_dw_identity_tu_credit_rprt_profile_d',
#    dag=dag
#    )
#
#task_dw_user_yd_actvy_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_yd_actvy_s_nerdlake/shellscripts/dw_user_yd_actvy_s.sh",
#    task_id='task_dw_user_yd_actvy_s',
#    dag=dag
#    )
#
#task_dw_user_ipx_actvy_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_ipx_actvy_s_nerdlake/shellscripts/dw_user_ipx_actvy_s.sh",
#    task_id='task_dw_user_ipx_actvy_s',
#    dag=dag
#    )
#
#task_dw_user_actvy_status_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_actvy_status_s_nerdlake/shellscripts/dw_user_actvy_status_s.sh",
#    task_id='task_dw_user_actvy_status_s',
#    dag=dag
#    )
#
#task_dw_user_monetization_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_monetization_s_nerdlake/shellscripts/dw_user_monetization_s.sh",
#    task_id='task_dw_user_monetization_s',
#    dag=dag
#    )
#
#task_dw_user_contact_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_contact_s_nerdlake/shellscripts/dw_user_contact_s.sh",
#    task_id='task_dw_user_contact_s',
#    dag=dag
#    )
#
#task_dw_user_engagement_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_engagement_s_nerdlake/shellscripts/dw_user_engagement_s.sh",
#    task_id='task_dw_user_engagement_s',
#    dag=dag
#    )
#
#task_dw_user_tu_credit_profile_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_tu_credit_profile_s_nerdlake/shellscripts/dw_user_tu_credit_profile_s.sh",
#    task_id='task_dw_user_tu_credit_profile_s',
#    dag=dag
#    )
#
#task_dw_user_reg_profile_s = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_reg_profile_s_nerdlake/shellscripts/dw_user_reg_profile_s.sh",
#    task_id='task_dw_user_reg_profile_s',
#    dag=dag
#    )
#
#task_dw_user_actvy_smry_f = NWBashScriptOperator(
#    bash_script="/data/etl/Scripts/dw_user_actvy_smry_f_nerdlake/shellscripts/dw_user_actvy_smry_f.sh",
#    task_id='task_dw_user_actvy_smry_f',
#    dag=dag
#    )
#
#task_idb_global_profile_s.set_upstream(task_start_dag)
#task_idb_global_profile_d.set_upstream(task_idb_global_profile_s)
#
#task_idb_terms_of_service_profile_s.set_upstream(task_start_dag)
#task_idb_terms_of_service_profile_d.set_upstream(task_idb_terms_of_service_profile_s)
#
#task_idb_terms_of_service_acknowledgement_s.set_upstream(task_start_dag)
#task_idb_terms_of_service_acknowledgement_d.set_upstream(task_idb_terms_of_service_acknowledgement_s)
#
#task_idb_financial_profile_s.set_upstream(task_start_dag)
#task_idb_financial_profile_d.set_upstream(task_idb_financial_profile_s)
#
#task_idb_addresses_s.set_upstream(task_start_dag)
#task_idb_addresses_d.set_upstream(task_idb_addresses_s)
#
#task_idb_subscription_profile_s.set_upstream(task_start_dag)
#task_idb_subscription_profile_d.set_upstream(task_idb_subscription_profile_s)
#
#task_idb_yodlee_transactions_s.set_upstream(task_start_dag)
#task_idb_yodlee_transactions_d.set_upstream(task_idb_yodlee_transactions_s)
#
#task_idb_tu_authentication_status_profile_s.set_upstream(task_start_dag)
#task_idb_tu_authentication_status_profile_d.set_upstream(task_idb_tu_authentication_status_profile_s)
#
#task_idb_tu_credit_report_profile_s.set_upstream(task_start_dag)
#task_idb_tu_credit_report_profile_d.set_upstream(task_idb_tu_credit_report_profile_s)
#
#task_idb_goals_credit_s.set_upstream(task_start_dag)
#task_idb_goals_credit_d.set_upstream(task_idb_goals_credit_s)
#
#task_idb_goals_s.set_upstream(task_start_dag)
#task_idb_goals_d.set_upstream(task_idb_goals_s)
#
#task_idb_feed_items_s.set_upstream(task_start_dag)
#task_idb_feed_items_d.set_upstream(task_idb_feed_items_s)
#
#task_idb_goals_debt_s.set_upstream(task_start_dag)
#task_idb_goals_debt_d.set_upstream(task_idb_goals_debt_s)
#
#task_idb_goals_retirement_s.set_upstream(task_start_dag)
#task_idb_goals_retirement_d.set_upstream(task_idb_goals_retirement_s)
#
#task_idb_goals_savings_s.set_upstream(task_start_dag)
#task_idb_goals_savings_d.set_upstream(task_idb_goals_savings_s)
#
#task_idb_goals_profiles_s.set_upstream(task_start_dag)
#task_idb_goals_profiles_d.set_upstream(task_idb_goals_profiles_s)
#
#task_idb_identities_s.set_upstream(task_start_dag)
#task_idb_identities_d.set_upstream(task_idb_identities_s)
#
#task_idb_registration_tracking_profiles_s.set_upstream(task_start_dag)
#task_idb_registration_tracking_profiles_d.set_upstream(task_idb_registration_tracking_profiles_s)
#
#task_idb_yodlee_credit_accounts_d.set_upstream(task_idb_yodlee_credit_accounts_s)
#
#task_idb_yodlee_loan_accounts_d.set_upstream(task_idb_yodlee_loan_accounts_s)
#
#task_idb_yodlee_bill_accounts_d.set_upstream(task_idb_yodlee_bill_accounts_s)
#
#task_idb_yodlee_accounts_d.set_upstream(task_idb_yodlee_accounts_s)
#
#task_idb_yodlee_bank_accounts_d.set_upstream(task_idb_yodlee_bank_accounts_s)
#
#task_yodlee_fact_stage.set_upstream(task_idb_yodlee_transactions_d)
#
#task_idb_yodlee_accounts_s.set_upstream(task_yodlee_fact_stage)
#task_idb_yodlee_bank_accounts_s.set_upstream(task_yodlee_fact_stage)
#task_idb_yodlee_bill_accounts_s.set_upstream(task_yodlee_fact_stage)
#task_idb_yodlee_investment_accounts_s.set_upstream(task_yodlee_fact_stage)
#task_idb_yodlee_credit_accounts_s.set_upstream(task_yodlee_fact_stage)
#task_idb_yodlee_loan_accounts_s.set_upstream(task_yodlee_fact_stage)
#
#task_yodlee_dim_stage.set_upstream(task_idb_yodlee_accounts_d)
#task_yodlee_dim_stage.set_upstream(task_idb_yodlee_bank_accounts_d)
#task_yodlee_dim_stage.set_upstream(task_idb_yodlee_bill_accounts_d)
#task_yodlee_dim_stage.set_upstream(task_idb_yodlee_investment_accounts_d)
#task_yodlee_dim_stage.set_upstream(task_idb_yodlee_credit_accounts_d)
#task_yodlee_dim_stage.set_upstream(task_idb_yodlee_loan_accounts_d)
#
#task_dw_yd_acct_bal_f.set_upstream(task_yodlee_dim_stage)
#
#task_dw_identity_tu_credit_rprt_profile_d.set_upstream(task_idb_tu_credit_report_profile_d)
#
#task_dw_user_yd_actvy_s.set_upstream(task_yodlee_dim_stage)
#task_dw_user_yd_actvy_s.set_upstream(task_dw_yd_acct_bal_f)
#
#task_ipx_fact_dependency.set_upstream(task_idb_identities_d)
#task_ipx_fact_dependency.set_upstream(task_idb_goals_d)
#task_ipx_fact_dependency.set_upstream(task_idb_goals_profiles_d)
#task_ipx_fact_dependency.set_upstream(task_idb_goals_credit_d)
#task_ipx_fact_dependency.set_upstream(task_idb_goals_savings_d)
#task_ipx_fact_dependency.set_upstream(task_idb_goals_debt_d)
#task_ipx_fact_dependency.set_upstream(task_idb_goals_retirement_d)
##task_ipx_fact_dependency.set_upstream(task_bshrk_billers_d)
##task_ipx_fact_dependency.set_upstream(task_bshrk_bills_d)
#task_ipx_fact_dependency.set_upstream(task_idb_feed_items_d)
#task_ipx_fact_dependency.set_upstream(task_all_event_s_dependency)
#
#task_dw_user_ipx_actvy_s.set_upstream(task_ipx_fact_dependency)
#
#task_dw_user_reg_profile_s.set_upstream(task_idb_identities_d)
#task_dw_user_reg_profile_s.set_upstream(task_all_event_s_dependency)
#task_dw_user_reg_profile_s.set_upstream(task_idb_registration_tracking_profiles_d)
#task_dw_user_reg_profile_s.set_upstream(task_user_agent_d_depedency)
#
#task_dw_user_actvy_status_s.set_upstream(task_all_event_s_dependency)
#task_dw_user_actvy_status_s.set_upstream(task_dw_user_reg_profile_s)
#
#task_dw_user_monetization_s.set_upstream(task_aflt_tran_dependency)
#task_dw_user_monetization_s.set_upstream(task_dw_user_reg_profile_s)
#
#task_dw_user_contact_s.set_upstream(task_all_event_s_dependency)
#
#task_dw_user_engagement_s.set_upstream(task_all_event_s_dependency)
##task_dw_user_engagement_s.set_upstream(task_identity_site_visitor_xref_d_load)
#
#task_dw_user_tu_credit_profile_s.set_upstream(task_idb_tu_authentication_status_profile_d)
#task_dw_user_tu_credit_profile_s.set_upstream(task_dw_identity_tu_credit_rprt_profile_d)
#task_dw_user_tu_credit_profile_s.set_upstream(task_idb_tu_credit_report_profile_d)
##task_dw_user_tu_credit_profile_s.set_upstream(task_idb_tu_tradeline_d)
#
#
#
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_contact_s)
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_monetization_s)
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_engagement_s)
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_tu_credit_profile_s)
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_reg_profile_s)
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_actvy_status_s)
#task_dw_user_actvy_smry_f.set_upstream(task_idb_global_profile_d)
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_yd_actvy_s)
#task_dw_user_actvy_smry_f.set_upstream(task_dw_user_ipx_actvy_s)
#
