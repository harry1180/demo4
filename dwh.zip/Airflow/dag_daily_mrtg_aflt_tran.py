import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_mrtg_aflt_tran'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 9, 16),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_job = TimeSensor(
    target_time=time(0,30),
    task_id='Initiating_start_time',
    dag=dag)

Task_ClickEvent_dependency = ExternalTaskSensor(
    task_id='waiting_for_ClickEvent_fact_load',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

task_dw_aflt_tran_hasoffers_f = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.dw_aflt_tran_hasoffers_f',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='dw_aflt_tran_hasoffers_f',
    dag=dag)

Task_dag_daily_twilio_dependency = ExternalTaskSensor(
task_id='waiting_for_twilio',
    external_dag_id='dag_daily_non_core_dwh',
    external_task_id='twilio_call_logs',
    dag=dag)

task2_script="/data/etl/Scripts/dw_aflt_tran_mortgages_lenda_f/shellscripts/dw_aflt_tran_mortgages_lenda_f.sh"
task2_aflt_tran_lenda_fact = NWBashScriptOperator(
    bash_script=task2_script,
    script_args=[],
    task_id='aflt_tran_lenda_fact',
    pool='redshift_etl',
    dag=dag)

task4_script="/data/etl/Scripts/dw_aflt_tran_mortgages_loandepot_f/shellscripts/dw_aflt_tran_mortgages_loandepot_f.sh"
task4_aflt_tran_loandepot_fact = NWBashScriptOperator(
    bash_script=task4_script,
    script_args=[],
    task_id='aflt_tran_loandepot_fact',
    pool='redshift_etl',
    dag=dag)

task5_script="/data/etl/Scripts/dw_aflt_tran_mortgages_f/shellscripts/consolidate_confirmed_files.sh"
task5_aflt_tran_confirmed_fact = NWBashScriptOperator(
    bash_script=task5_script,
    script_args=[],
    task_id='aflt_tran_confirmed_fact',
    dag=dag)

task6_script="/data/etl/Scripts/dw_aflt_tran_mortgages_f/shellscripts/consolidate.sh"
task6_aflt_tran_mrtg_consolidate_fact = NWBashScriptOperator(
    bash_script=task6_script,
    script_args=[],
    task_id='aflt_tran_mrtg_consolidate_fact',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task7_script="/data/etl/Scripts/aflt_process_email_attachments/shellscripts/aflt_process_email_attachments.sh"
task7_email_download = NWBashScriptOperator(
    bash_script=task7_script,
    script_args=[],
    task_id='aflt_email_download',
    dag=dag)

task8_script="/data/etl/Scripts/dw_aflt_tran_mortgages_f/shellscripts/consolidate_confirmed_stage_old.sh"
task8_aflt_tran_mrtg_stage_old = NWBashScriptOperator(
    bash_script=task8_script,
    script_args=[],
    task_id='aflt_tran_mrtg_stage_old',
    pool='redshift_etl',
    dag=dag)

task9_script="/data/etl/Scripts/dw_aflt_tran_mortgages_f/shellscripts/consolidate_confirmed_stage.sh"
task9_aflt_tran_mrtg_stage = NWBashScriptOperator(
    bash_script=task9_script,
    script_args=[],
    task_id='aflt_tran_mrtg_stage',
    dag=dag)

task10_script="/data/etl/Scripts/dw_aflt_tran_mortgages_f/shellscripts/consolidate_confirmed_stage_dwh.sh"
task10_aflt_tran_mrtg_stage_dwh = NWBashScriptOperator(
    bash_script=task10_script,
    script_args=[],
    task_id='aflt_tran_mrtg_stage_dwh',
    pool='redshift_etl',
    dag=dag)

task11_script="/data/etl/Scripts/dw_aflt_tran_mortgages_f/shellscripts/consolidate_confirmed_calls.sh"
task11_aflt_tran_mrtg_consolidate_calls_fact = NWBashScriptOperator(
    bash_script=task11_script,
    script_args=[],
    task_id='aflt_tran_mrtg_consolidate_calls_fact',
    pool='redshift_etl',
    dag=dag)

task7_email_download.set_upstream(task_start_job)
task7_email_download.set_upstream(Task_ClickEvent_dependency)
task2_aflt_tran_lenda_fact.set_upstream(task7_email_download)
task4_aflt_tran_loandepot_fact.set_upstream(task7_email_download)
task5_aflt_tran_confirmed_fact.set_upstream(task7_email_download)
task8_aflt_tran_mrtg_stage_old.set_upstream(task2_aflt_tran_lenda_fact)
task8_aflt_tran_mrtg_stage_old.set_upstream(task4_aflt_tran_loandepot_fact)
task9_aflt_tran_mrtg_stage.set_upstream(task5_aflt_tran_confirmed_fact)
task9_aflt_tran_mrtg_stage.set_upstream(task8_aflt_tran_mrtg_stage_old)
task10_aflt_tran_mrtg_stage_dwh.set_upstream(task9_aflt_tran_mrtg_stage)
task10_aflt_tran_mrtg_stage_dwh.set_upstream(task_dw_aflt_tran_hasoffers_f)
task6_aflt_tran_mrtg_consolidate_fact.set_upstream(task10_aflt_tran_mrtg_stage_dwh)
task11_aflt_tran_mrtg_consolidate_calls_fact.set_upstream(task6_aflt_tran_mrtg_consolidate_fact)
task11_aflt_tran_mrtg_consolidate_calls_fact.set_upstream(Task_dag_daily_twilio_dependency)
