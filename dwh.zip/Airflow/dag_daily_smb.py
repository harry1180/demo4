import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_smb"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017,02,01),
    'email': ['dwh@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(5,15),
    task_id='Initiating_start_time',
    dag=dag)

Task_ClickEvent_dependency = ExternalTaskSensor(
    task_id='waiting_for_ClickEvent_fact_load',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

task000_script="/data/etl/Scripts/aflt_tran_process_google_spreadsheet/shellscripts/aflt_tran_process_google_spreadsheet.sh"
task000_aflt_tran_process_google_spreadsheet_bondstreet = NWBashScriptOperator(
    bash_script=task000_script,
    script_args=["smb","bondstreet","https://docs.google.com/spreadsheets/d/1aoC_APY4RXSzyxq8P8K0Qk865Dceqk1TwigFSamBaOE","Summary","smb.airdrop@nerdwallet.awsapps.com"],
    task_id='aflt_tran_process_google_spreadsheet_bondstreet',
    trigger_rule='all_done',
    dag=dag)

task001_script="/data/etl/Scripts/aflt_tran_process_google_spreadsheet/shellscripts/aflt_tran_process_google_spreadsheet.sh"
task001_aflt_tran_process_google_spreadsheet_ablelending = NWBashScriptOperator(
    bash_script=task001_script,
    script_args=["smb","ablelending","https://docs.google.com/spreadsheets/d/11G8Csgu1GBhKug2tSyhukBKh4B4W9YlY7_59NAkIWZI","Sheet1","smb.airdrop@nerdwallet.awsapps.com"],
    task_id='aflt_tran_process_google_spreadsheet_ablelending',
    trigger_rule='all_done',
    dag=dag)


task1_script="/data/etl/Scripts/aflt_tran_process_smb_loans/shellscripts/aflt_tran_process_smb_loans.sh"
task1_aflt_tran_process_smb_loans = NWBashScriptOperator(
    bash_script=task1_script,
    script_args=[],
    task_id='aflt_tran_process_smb_loans',
    trigger_rule='all_done',
    dag=dag)

task2_script="/data/etl/Scripts/aflt_tran_smb_loans_s/shellscripts/aflt_tran_smb_loans_s.sh"
task2_aflt_tran_smb_loans_s = NWBashScriptOperator(
    bash_script=task2_script,
    script_args=[],
    task_id='aflt_tran_smb_loans_s',
    trigger_rule='all_done',
    dag=dag)

task3_script="/data/etl/Scripts/dw_aflt_tran_smb_loans_f/shellscripts/dw_aflt_tran_smb_loans_f.sh"
task3_dw_aflt_tran_smb_loans_f = NWBashScriptOperator(
    bash_script=task3_script,
    script_args=[],
    task_id='dw_aflt_tran_smb_loans_f',
    trigger_rule='all_done',
    dag=dag)

task000_aflt_tran_process_google_spreadsheet_bondstreet.set_upstream(task_start_job)
task001_aflt_tran_process_google_spreadsheet_ablelending.set_upstream(task_start_job)
task1_aflt_tran_process_smb_loans.set_upstream(Task_ClickEvent_dependency)
task1_aflt_tran_process_smb_loans.set_upstream(task000_aflt_tran_process_google_spreadsheet_bondstreet)
task1_aflt_tran_process_smb_loans.set_upstream(task001_aflt_tran_process_google_spreadsheet_ablelending)
task2_aflt_tran_smb_loans_s.set_upstream(task1_aflt_tran_process_smb_loans)
task3_dw_aflt_tran_smb_loans_f.set_upstream(task2_aflt_tran_smb_loans_s)
