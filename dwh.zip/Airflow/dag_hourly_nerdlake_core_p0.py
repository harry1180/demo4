from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators import NWBashScriptOperator, ExternalTaskSensor, DummyOperator


job_name = "dag_hourly_nerdlake_core_p0"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018, 5, 17),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=10),
    'depends_on_past': True
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@hourly')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_click_events_s_nerdlake_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.click_events_s_nerdlake_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='click_events_s_nerdlake_load',
    dag=dag)
task_click_events_s_nerdlake_load.set_upstream(task_start_dag)

task_identity_events_s_nerdlake_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.identity_events_s_nerdlake_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='identity_events_s_nerdlake_load',
    dag=dag)
task_identity_events_s_nerdlake_load.set_upstream(task_start_dag)

task_AppsFlyerWebhookEvent_deser = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.AppsFlyerWebhookEvent_nerdlake_deserialization_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='AppsFlyerWebhookEvent_nerdlake_deserialization_load',
    dag=dag)
task_AppsFlyerWebhookEvent_deser.set_upstream(task_start_dag)

task_PageViewEvent_nerdlake_deserialization_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.PageViewEvent_nerdlake_deserialization_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='PageViewEvent_nerdlake_deserialization_load',
    dag=dag)
task_PageViewEvent_nerdlake_deserialization_load.set_upstream(task_start_dag)

task_RegisterIdentityEvent_nerdlake_deserialization_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.RegisterIdentityEvent_nerdlake_deserialization_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='RegisterIdentityEvent_nerdlake_deserialization_load',
    dag=dag)
task_RegisterIdentityEvent_nerdlake_deserialization_load.set_upstream(task_start_dag)

task_ProductInteractionEvent_nerdlake_deserialization_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.ProductInteractionEvent_nerdlake_deserialization_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='ProductInteractionEvent_nerdlake_deserialization_load',
    dag=dag)
task_ProductInteractionEvent_nerdlake_deserialization_load.set_upstream(task_start_dag)

task_FormInputChangedEvent_nerdlake_deserialization_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.FormInputChangedEvent_nerdlake_deserialization_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='FormInputChangedEvent_nerdlake_deserialization_load',
    depends_on_past=False,
    dag=dag)
task_FormInputChangedEvent_nerdlake_deserialization_load.set_upstream(task_start_dag)

#task_idb_identities_d = ExternalTaskSensor(
#    task_id='dag_hourly_nerdlake_pud_identity.task_idb_identities_d',
#    external_dag_id='dag_hourly_nerdlake_pud_identity',
#    external_task_id='task_idb_identities_d',
#    dag=dag)
#task_idb_identities_d.set_upstream(task_start_dag)

task_idb_identities_d = DummyOperator(
    task_id='dag_hourly_nerdlake_pud_identity.task_idb_identities_d',
    dag=dag)
task_idb_identities_d.set_upstream(task_start_dag)

#task_aflt_tran_load_nerdlake = ExternalTaskSensor(
#    task_id='dag_hourly_nerdlake_aflt_tran.aflt_tran_load_nerdlake',
#    external_dag_id='dag_hourly_nerdlake_aflt_tran',
#    external_task_id='aflt_tran_load_nerdlake',
#    allowed_states=['success', 'failure'],
#    dag=dag)

task_impression_events_s_nerdlake_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.impression_events_s_nerdlake_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='impression_events_s_nerdlake_load',
    dag=dag)
task_impression_events_s_nerdlake_load.set_upstream(task_start_dag)

###########################################################################
# Command tasks
###########################################################################

task_dw_pv_xref_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_view_xref_f_nerdlake/shellscripts/dw_page_view_xref_f.sh',
    script_args=[],
    task_id='dw_page_view_xref_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_dw_pv_xref_f_nerdlake_load.set_upstream(task_PageViewEvent_nerdlake_deserialization_load)

task_mktg_vendor_d_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_vendor_d_nerdlake/shellscripts/mktg_vendor_d.sh',
    script_args=[],
    task_id='mktg_vendor_d_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_mktg_vendor_d_nerdlake_load.set_upstream(task_PageViewEvent_nerdlake_deserialization_load)

task_dw_referral_d_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_referral_d_nerdlake/shellscripts/dw_referral_d.sh',
    script_args=[],
    task_id='dw_referral_d_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_dw_referral_d_nerdlake_load.set_upstream(task_PageViewEvent_nerdlake_deserialization_load)

task_user_agent_d_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/user_agent_d_nerdlake/shellscripts/user_agent_d.sh',
    script_args=[],
    task_id='user_agent_d_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_user_agent_d_nerdlake_load.set_upstream(task_click_events_s_nerdlake_load)
task_user_agent_d_nerdlake_load.set_upstream(task_PageViewEvent_nerdlake_deserialization_load)

task_pv_suspected_bot_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_view_suspected_bot_f_nerdlake/shellscripts/dw_page_view_suspected_bot_f.sh',
    script_args=[],
    task_id='dw_page_view_suspected_bot_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_pv_suspected_bot_nerdlake.set_upstream(task_PageViewEvent_nerdlake_deserialization_load)
task_pv_suspected_bot_nerdlake.set_upstream(task_idb_identities_d)
task_pv_suspected_bot_nerdlake.set_upstream(task_user_agent_d_nerdlake_load)

task_page_view_event_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_view_event_f_nerdlake/shellscripts/dw_page_view_event_f.sh',
    script_args=[],
    task_id='dw_page_view_event_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_page_view_event_f_nerdlake_load.set_upstream(task_PageViewEvent_nerdlake_deserialization_load)
task_page_view_event_f_nerdlake_load.set_upstream(task_pv_suspected_bot_nerdlake)
task_page_view_event_f_nerdlake_load.set_upstream(task_dw_referral_d_nerdlake_load)
task_page_view_event_f_nerdlake_load.set_upstream(task_mktg_vendor_d_nerdlake_load)
task_page_view_event_f_nerdlake_load.set_upstream(task_dw_pv_xref_f_nerdlake_load)
task_page_view_event_f_nerdlake_load.set_upstream(task_user_agent_d_nerdlake_load)

task_identity_event_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_identity_event_f_nerdlake/shellscripts/dw_identity_event_f.sh',
    script_args=[],
    task_id='identity_event_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_identity_event_f_nerdlake_load.set_upstream(task_identity_events_s_nerdlake_load)
task_identity_event_f_nerdlake_load.set_upstream(task_page_view_event_f_nerdlake_load)

task_clicks_event_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_clicks_event_f_nerdlake/shellscripts/dw_clicks_event_f.sh',
    script_args=[],
    task_id='dw_clicks_event_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_clicks_event_f_nerdlake_load.set_upstream(task_page_view_event_f_nerdlake_load)
task_clicks_event_f_nerdlake_load.set_upstream(task_click_events_s_nerdlake_load)
task_clicks_event_f_nerdlake_load.set_upstream(task_dw_pv_xref_f_nerdlake_load)

task_prod_intactn_event_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_intactn_event_f_nerdlake/shellscripts/dw_prod_intactn_event_f.sh',
    script_args=[],
    task_id='prod_intactn_event_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_prod_intactn_event_f_nerdlake_load.set_upstream(task_ProductInteractionEvent_nerdlake_deserialization_load)
task_prod_intactn_event_f_nerdlake_load.set_upstream(task_dw_pv_xref_f_nerdlake_load)

task_session_event_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_session_event_f_nerdlake/shellscripts/dw_session_event_f.sh',
    script_args=[],
    task_id='dw_session_event_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_session_event_f_nerdlake_load.set_upstream(task_page_view_event_f_nerdlake_load)

task_pv_form_input_chg_event_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_pv_form_input_chg_event_f_nerdlake/shellscripts/dw_pv_form_input_chg_event_f.sh',
    script_args=[],
    task_id='pv_form_input_chg_event_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_pv_form_input_chg_event_f_nerdlake_load.set_upstream(task_FormInputChangedEvent_nerdlake_deserialization_load)
task_pv_form_input_chg_event_f_nerdlake_load.set_upstream(task_dw_pv_xref_f_nerdlake_load)
task_pv_form_input_chg_event_f_nerdlake_load.set_upstream(task_pv_suspected_bot_nerdlake)

task_dw_imprsns_event_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_imprsns_event_f_nerdlake/shellscripts/dw_imprsns_event_f.sh',
    script_args=[],
    task_id='dw_imprsns_event_f_nerdlake_load',
    pool='presto_etl',
    dag=dag)
task_dw_imprsns_event_f_nerdlake_load.set_upstream(task_impression_events_s_nerdlake_load)
task_dw_imprsns_event_f_nerdlake_load.set_upstream(task_page_view_event_f_nerdlake_load)

task_dw_actvy_f_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_actvy_f_nerdlake/shellscripts/dw_actvy_f.sh',
    script_args=[],
    task_id='dw_actvy_f_nerdlake_load',
    dag=dag)
task_dw_actvy_f_nerdlake_load.set_upstream(task_clicks_event_f_nerdlake_load)
task_dw_actvy_f_nerdlake_load.set_upstream(task_dw_imprsns_event_f_nerdlake_load)
task_dw_actvy_f_nerdlake_load.set_upstream(task_prod_intactn_event_f_nerdlake_load)
task_dw_actvy_f_nerdlake_load.set_upstream(task_pv_form_input_chg_event_f_nerdlake_load)
#task_dw_actvy_f_nerdlake_load.set_upstream(task_aflt_tran_load_nerdlake)

task_dw_appsflyer_event_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_appsflyer_event_f_nerdlake/shellscripts/dw_appsflyer_event_f_nerdlake.sh',
    script_args=[],
    task_id='dw_appsflyer_event_f',
    dag=dag)
task_dw_appsflyer_event_f.set_upstream(task_AppsFlyerWebhookEvent_deser)
