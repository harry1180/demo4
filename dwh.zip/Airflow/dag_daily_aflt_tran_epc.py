from airflow import DAG
from datetime import datetime, timedelta

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_aflt_tran_epc"

default_args = {
    'owner': 'dwh',
    'depends_on_past': False, #TODO: change to True once fully productionalized
    'wait_for_downstream': True,
    'start_date': datetime(2018, 7, 02),
    'email': ['airflowalerts@nerdwallet.com'], #TODO: add pagerduty once fully productionalized
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@daily')


###########################################################################
# External task sensors
###########################################################################
task_clicks_event_fact = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.clicks_event_fact',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

task_aflt_tran_consolidated_fact = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.aflt_tran_consolidated_fact',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_consolidated_fact',
    dag=dag)

###########################################################################
# Command tasks
###########################################################################
task_dw_aflt_tran_epc_d = NWBashScriptOperator(
    bash_script='/data/etl/Common/gs_to_table.sh',
    script_args=['https://docs.google.com/spreadsheets/d/1xsR5wMDsq5UruZ3Kpl3f1jb7R4P9V8W-_jfBK_fXQy4/',
                 'dw_aflt_tran_epc_d', 'dw_report', 'dw_aflt_tran_epc_d'],
    task_id='dw_aflt_tran_epc_d',
    dag=dag)

task_dw_aflt_tran_epc_daily_agg = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_epc_daily_agg/shellscripts/dw_aflt_tran_epc_daily_agg.sh',
    script_args=[],
    task_id='dw_aflt_tran_epc_daily_agg',
    dag=dag)
task_dw_aflt_tran_epc_daily_agg.set_upstream(task_dw_aflt_tran_epc_d)
task_dw_aflt_tran_epc_daily_agg.set_upstream(task_clicks_event_fact)

task_dw_aflt_tran_epc_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_epc_f/shellscripts/dw_aflt_tran_epc_f.sh',
    script_args=[],
    task_id='dw_aflt_tran_epc_f',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_epc_f.set_upstream(task_dw_aflt_tran_epc_daily_agg)
task_dw_aflt_tran_epc_f.set_upstream(task_aflt_tran_consolidated_fact)
