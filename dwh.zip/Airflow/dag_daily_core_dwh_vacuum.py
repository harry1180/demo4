from datetime import datetime, timedelta, time
import os
import sys

from airflow import DAG
import airflow.operators
from airflow.operators import DummyOperator
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_core_dwh_vacuum'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=2),
    'email': ['airflowalerts@nerdwallet.com','dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

task_dag_daily_core_dwh_dependency = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.status_update',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    poke_interval=300,
    dag=dag)

task_change_ownership = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/ctl_change_tbl_ownr_nm/shellscripts/ctl_change_tbl_owner_nm.sh',
    script_args=[],
    task_id='change_table_ownership',
    dag=dag)
task_change_ownership.set_upstream(task_dag_daily_core_dwh_dependency)

task1_vacuum_core_dwh = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dwh_complete_vacuum/shellscripts/dwh_core_vacuum.sh',
    script_args=[],
    task_id='vacuum_core_dwh',
    pool='redshift_vacuum',
    priority_weight=5,
    dag=dag)
task1_vacuum_core_dwh.set_upstream(task_change_ownership)

task2_status_update = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_sql_function.sh',
    script_args=['/data/etl/Airflow/post_updates/dag_daily_core_dwh_vacuum_status_update.sql'],
    task_id='status_update',
    dag=dag)
task2_status_update.set_upstream(task1_vacuum_core_dwh)
