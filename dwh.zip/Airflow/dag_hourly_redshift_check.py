import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator, PythonOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_hourly_redshift_check"

default_args = {
    'owner': 'dwh',
    'depends_on_past': False,
#    'wait_for_downstream': True,
    'start_date': datetime(2016, 8, 2),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=15),
    'queue': 'dwh',
    'dagrun_timeout': timedelta(minutes=10), #timeout after 10 minutes
    'execution_timeout': timedelta(minutes=10),
    'max_active_runs': 2 , # dont run more than 1 instance
    'concurrency' : 1 #the number of task instances allowed to run concurrently
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@hourly')

task_run_redshift_check_script="/data/etl/Scripts/datadog_sql_checks/shellscripts/log_redshift_health.sh"
task_dw_wp_instance_d = NWBashScriptOperator(
    bash_script=task_run_redshift_check_script,
    script_args=[],
    task_id='log_redshift_health',
    dag=dag)
