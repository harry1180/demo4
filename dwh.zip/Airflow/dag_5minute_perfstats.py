import sys
from datetime import *
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_perf_stats_monitor"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2016, 12, 13),
    'email': ['dataops@nerdwallet.com','dataops@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='*/10 * * * *')


task_perf_stats_monitor="/data/etl/Scripts/dw_perf_stats_monitor/shellscripts/dw_perf_stats_monitor.sh"
task_test_hourly_template = NWBashScriptOperator(
    bash_script=task_perf_stats_monitor,
    script_args=[],
    task_id='task_perf_stats_monitor',
    dag=dag)

