from airflow import DAG
from datetime import datetime, timedelta, time

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_aflt_tran_banking"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=2),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(00, 05),
    task_id='Initiating_start_time',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_clicks_event_fact = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.clicks_event_fact',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

task_aflt_tran_click_meter = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.aflt_tran_click_meter',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_click_meter',
    dag=dag)

task_aflt_tran_commission_junction = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.aflt_tran_commission_junction',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_commission_junction',
    dag=dag)

task_aflt_tran_link_share_coupons = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.aflt_tran_link_share_coupons',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_link_share_coupons',
    dag=dag)

task_aflt_tran_impact_radius = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.aflt_tran_impact_radius',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_impact_radius',
    dag=dag)

###########################################################################
# Command tasks
###########################################################################
task_dw_aflt_tran_commission_d = NWBashScriptOperator(
    bash_script='/data/etl/Common/gs_to_table.sh',
    script_args=['https://docs.google.com/spreadsheets/d/1g5Z4qe4C_a06zH1dG2bGDb6yz6A5Dil2m8aj3749Os4/',
                 'Budget', 'dw_report', 'dw_aflt_tran_commission_d'],
    task_id='dw_aflt_tran_commission_d',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_commission_d.set_upstream(task_start_job)

task_dw_aflt_tran_banking_product_mapping = NWBashScriptOperator(
    bash_script='/data/etl/Common/gs_to_table.sh',
    script_args=['https://docs.google.com/spreadsheets/d/1g5Z4qe4C_a06zH1dG2bGDb6yz6A5Dil2m8aj3749Os4/',
                 'ProductMappingTable', 'dw_report', 'dw_aflt_tran_banking_product_mapping'],
    task_id='dw_aflt_tran_banking_product_mapping',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_banking_product_mapping.set_upstream(task_start_job)

task_email_download = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_process_email_attachments/shellscripts/aflt_process_email_attachments.sh',
    script_args=[],
    task_id='aflt_email_download',
    dag=dag)
task_email_download.set_upstream(task_start_job)

task_aflt_tran_process_banking = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_process_banking/shellscripts/aflt_tran_process_banking.sh',
    script_args=[],
    task_id='aflt_tran_process_banking',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_process_banking.set_upstream(task_email_download)

task_dw_aflt_tran_banking_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_banking_s/shellscripts/dw_aflt_tran_banking_s.sh',
    script_args=[],
    task_id='dw_aflt_tran_banking_s',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_banking_s.set_upstream(task_aflt_tran_process_banking)

task_dw_aflt_tran_banking_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_banking_f/shellscripts/dw_aflt_tran_banking_f.sh',
    script_args=[],
    task_id='dw_aflt_tran_banking_f',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_banking_f.set_upstream(task_dw_aflt_tran_banking_s)
task_dw_aflt_tran_banking_f.set_upstream(task_dw_aflt_tran_commission_d)
task_dw_aflt_tran_banking_f.set_upstream(task_dw_aflt_tran_banking_product_mapping)
task_dw_aflt_tran_banking_f.set_upstream(task_clicks_event_fact)
task_dw_aflt_tran_banking_f.set_upstream(task_aflt_tran_click_meter)
task_dw_aflt_tran_banking_f.set_upstream(task_aflt_tran_commission_junction)
task_dw_aflt_tran_banking_f.set_upstream(task_aflt_tran_link_share_coupons)
task_dw_aflt_tran_banking_f.set_upstream(task_aflt_tran_impact_radius)
