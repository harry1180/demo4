import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_aflt_tran_cc_new_LT"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 04, 27),
    'email': ['dwh@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(5,15),
    task_id='Initiating_start_time',
    dag=dag)

task_dag_daily_aflt_tran_personal_loans_dependency = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran_personal_loans.dw_aflt_tran_personal_loans_f',
    external_dag_id='dag_daily_aflt_tran_personal_loans',
    external_task_id='dw_aflt_tran_personal_loans_f',
    allowed_states=['success', 'failed'],
    dag=dag)

# This sensor times out after 1 hour. It's waiting on an hourly task and if that
# task hasn't gone to success or failure after 1 hour, something is wrong and we
# want to fail this sensor so alert the on-call person.
task_dag_hourly_nerdlake_aflt_tran_dependency = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_aflt_tran.aflt_tran_load_nerdlake',
    external_dag_id='dag_hourly_nerdlake_aflt_tran',
    external_task_id='aflt_tran_load_nerdlake',
    allowed_states=['success', 'failed'],
    execution_delta=timedelta(hours=-23),
    execution_timeout=timedelta(hours=1),
    retries=0,
    dag=dag)

task_aflt_tran_stage_load_script="/data/etl/Scripts/aflt_tran_cc_s/shellscripts/aflt_tran_cc_s.sh"
task_aflt_tran_cc_s = NWBashScriptOperator(
    bash_script=task_aflt_tran_stage_load_script,
    script_args=[],
    task_id='aflt_tran_cc_s',
    trigger_rule='all_done',
    dag=dag)

task_aflt_tran_fact_load_script="/data/etl/Scripts/dw_aflt_tran_cc_f/shellscripts/dw_aflt_tran_cc_f.sh"
task_dw_aflt_tran_cc_f = NWBashScriptOperator(
    bash_script=task_aflt_tran_fact_load_script,
    script_args=[],
    task_id='dw_aflt_tran_cc_f',
    trigger_rule='all_done',
    dag=dag)

task_aflt_tran_cc_s.set_upstream(task_start_job)
task_dw_aflt_tran_cc_f.set_upstream(task_aflt_tran_cc_s)
task_aflt_tran_cc_s.set_upstream(task_dag_hourly_nerdlake_aflt_tran_dependency)
task_dw_aflt_tran_cc_f.set_upstream(task_dag_daily_aflt_tran_personal_loans_dependency)
